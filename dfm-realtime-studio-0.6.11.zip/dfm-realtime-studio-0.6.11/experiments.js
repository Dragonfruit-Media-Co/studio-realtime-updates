// YouTube "Test & compare" (A/B tests of thumbnails / titles), pure. `videoCreatorExperiment` as
// returned by creator/get_creator_videos (fixtures/get_creator_videos.experiment.json, a RUNNING
// title test) and by the analytics card (fixtures/get_cards.experiment.json, a FINISHED thumbnail test):
//   { armCount, experimentArmData[{ thumbnail?{thumbnails[]}, title?{textSegments[{text}]} }],
//     state: CREATOR_EXPERIMENT_STATE_STARTED | _FINISHED, finishedReason, selectedArm,
//     experimentStartTime{seconds}, experimentFinishTime?{seconds}, result{resultState, winnerArm},
//     resultsDisplayed, experimentConfiguration{hasThumbnails, hasTitles} }
// Per-arm watch-time shares (the "40 % · Watch time share" of Studio's test report) come as
// result.armResults[{ arm: CREATOR_EXPERIMENT_ARM_n, watchtimeFraction: 0.3995 }] (captured 2026-09-06
// on a stopped thumbnail test); they are absent while YouTube has too little data. shareOf() stays as a
// fallback for a share field sitting on the arm itself.

const ARM = /_ARM_(\d+)$/;
const armIndex = (v) => { const m = ARM.exec(v ?? ''); return m ? Number(m[1]) - 1 : null; };   // CREATOR_EXPERIMENT_ARM_3 → 2
const toMs = (t) => (t?.seconds !== undefined ? Number(t.seconds) * 1000 + Math.round((t.nanos ?? 0) / 1e6) : null);
const pick = (thumbs, minWidth = 320) => {
  const list = (thumbs ?? []).filter((t) => t?.url);
  if (!list.length) return null;
  return (list.filter((t) => (t.width ?? 0) >= minWidth).sort((a, b) => a.width - b.width)[0] ?? list.at(-1)).url;
};
// Arm titles arrive as { textSegments: [{ text }] }; tolerate a plain string too.
const titleOf = (t) => (typeof t === 'string' ? t : Array.isArray(t?.textSegments) ? t.textSegments.map((seg) => seg?.text ?? '').join('') || null : null);
// Best-effort share: the first numeric field on the arm whose name suggests a share.
function shareOf(arm) {
  const walk = (o, depth = 0) => {
    if (!o || typeof o !== 'object' || depth > 3) return null;
    for (const [k, v] of Object.entries(o)) {
      if (/share|percent|ratio|fraction/i.test(k)) { const n = Number(typeof v === 'object' ? v?.value ?? v?.percent : v); if (Number.isFinite(n)) return n; }
      const inner = walk(v, depth + 1); if (inner !== null) return inner;
    }
    return null;
  };
  const raw = walk(arm);
  if (raw === null) return null;
  return raw <= 1 ? Math.round(raw * 1000) / 10 : Math.round(raw * 10) / 10;   // fractions → percent
}

// A video object carrying videoCreatorExperiment → normalised experiment, or null without a test.
export function normalizeExperiment(video) {
  const x = video?.videoCreatorExperiment;
  if (!x) return null;
  // YouTube keeps a stub for a test that was deleted before it ran (STATE_DELETED, no start time, no
  // arms) — that is "no test" for us. Same for an unspecified state with nothing to show.
  if (/DELETED|CANCELLED|UNSPECIFIED/.test(x.state ?? '')) return null;
  const state = /STARTED|RUNNING|ACTIVE|IN_PROGRESS/.test(x.state ?? '') ? 'running' : /FINISHED|COMPLETE|ENDED|STOPPED/.test(x.state ?? '') ? 'finished' : 'other';
  if (state === 'other' && !x.experimentStartTime && !(x.experimentArmData ?? []).length) return null;
  const pct = (f) => (Number.isFinite(Number(f)) ? Math.round(Number(f) * 1000) / 10 : null);   // 0.3995 → 40 (one decimal)
  const results = new Map((x.result?.armResults ?? []).map((r) => [armIndex(r?.arm), pct(r?.watchtimeFraction)]));
  const arms = (x.experimentArmData ?? []).map((a, i) => ({
    index: i,
    label: String.fromCharCode(65 + i),
    thumbnail: pick(a?.thumbnail?.thumbnails),
    title: titleOf(a?.title),
    share: results.get(i) ?? shareOf(a),
  }));
  return {
    videoId: video.videoId ?? null,
    state, rawState: x.state ?? null,
    hasTitles: Boolean(x.experimentConfiguration?.hasTitles),
    hasThumbnails: Boolean(x.experimentConfiguration?.hasThumbnails),
    startedAt: toMs(x.experimentStartTime), finishedAt: toMs(x.experimentFinishTime),
    finishedReason: x.finishedReason ?? null,
    selectedArm: armIndex(x.selectedArm), winnerArm: armIndex(x.result?.winnerArm),
    resultState: x.result?.resultState ?? null,
    arms,
  };
}

// creator/get_creator_videos response → { [videoId]: experiment | null } for every video returned.
export function parseExperiments(json) {
  const out = {};
  for (const v of json?.videos ?? []) if (v?.videoId) out[v.videoId] = normalizeExperiment(v);
  return out;
}
// yta_web/get_cards response (the analytics card) → one experiment or null.
export function parseExperiment(json) {
  const card = (json?.cards ?? []).find((c) => c?.thumbnailExperimentCardData);
  return normalizeExperiment(card?.thumbnailExperimentCardData?.video);
}

// Compare the last known experiment per video with the fresh ones. events: TestStarted | TestFinished.
// known/current = { [videoId]: experiment | null }. Returns { events, known: current }.
export function diffExperiments(known, current, now = Date.now()) {
  const events = [];
  for (const [videoId, x] of Object.entries(current ?? {})) {
    const prev = known?.[videoId] ?? null;
    if (!x) continue;
    const sameTest = prev && prev.startedAt === x.startedAt;
    // `at` = when WE first saw it (the popup marks that hour); YouTube's own start is `startedAt`.
    if (x.state === 'running' && (!sameTest || prev.state !== 'running')) events.push({ type: 'TestStarted', videoId, at: now, startedAt: x.startedAt ?? null, experiment: x });
    if (x.state === 'finished' && sameTest && prev.state === 'running') events.push({ type: 'TestFinished', videoId, at: x.finishedAt ?? now, startedAt: x.startedAt ?? null, experiment: x });
  }
  return { events, known: current };
}
