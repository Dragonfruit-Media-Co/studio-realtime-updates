export class NotSignedIn extends Error {
  // detail: what the cookie lookup found, so the popup can say why (cookies are per Chrome profile).
  constructor(detail = '') { super(detail ? `Not signed in — ${detail}` : 'Not signed in'); this.name = 'NotSignedIn'; this.detail = detail; }
}
export class HttpError extends Error {
  // body: response text, kept so a rejection can be diagnosed from the popup ("Copy raw response").
  constructor(status, body = '') { super(`HTTP ${status}`); this.name = 'HttpError'; this.status = status; this.body = body; }
}
export class ShapeError extends Error {
  constructor(path) {
    super(`Captured shape no longer matches (${path})`); this.name = 'ShapeError'; this.path = path;
  }
}
// Studio answered, but its analytics backend failed to build the realtime card for this channel
// (card { isFailed: true, isHidden: true, statusCode: 13 }, seen 2026-09-07). Transient: not our shape.
export class CardFailed extends Error {
  constructor(statusCode = null) {
    super(`Studio could not load the realtime card${statusCode !== null ? ` (status ${statusCode})` : ''}`); this.name = 'CardFailed'; this.statusCode = statusCode;
  }
}
export function classify(err) {
  if (err instanceof NotSignedIn) return { kind: 'not_signed_in', message: err.message };
  if (err instanceof HttpError) return { kind: 'http', status: err.status, message: err.message };
  if (err instanceof CardFailed) return { kind: 'card_failed', statusCode: err.statusCode, message: err.message };
  if (err instanceof ShapeError) return { kind: 'shape', path: err.path, message: err.message };
  return { kind: 'network', message: err?.message ?? String(err) };
}
