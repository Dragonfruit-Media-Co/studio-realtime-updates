import { classify, NotSignedIn, HttpError, ShapeError, CardFailed } from './errors.js';
import { joinRealtime } from './videos.js';

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const SERIAL_GAP_MS = 500;

const is429 = (err) => err?.kind === 'http' && err.status === 429;

// The upload list is optional in two senses: deps may omit it (realtime-only, as before), and a
// failed list call degrades the row to the card's own videos with `listError` set, never fails it.
async function fetchList(ch, authHeader, { listVideos, parseVideoList }) {
  if (!listVideos) return null;
  try { return { list: parseVideoList(await listVideos({ channel: ch, authHeader })) }; }
  catch (e) { return { error: classify(e) }; }
}

// One channel → one Result. Never rejects. The card and the list go out in parallel.
const CARD_RETRY_MS = 1500;
async function one(ch, authHeader, deps) {
  const { getCards, parseRealtime, delay = sleep } = deps;
  let json;
  const listP = fetchList(ch, authHeader, deps);
  try {
    json = await getCards({ channel: ch, authHeader });
    let data;
    try { data = parseRealtime(json); }
    catch (e) {
      if (!(e instanceof CardFailed)) throw e;
      await delay(CARD_RETRY_MS);                       // Studio's card backend hiccups; one quick retry
      json = await getCards({ channel: ch, authHeader });
      data = parseRealtime(json);
    }
    const listed = await listP;
    if (listed?.list) Object.assign(data, joinRealtime(listed.list, data));
    else if (listed?.error) data.listError = listed.error;
    // raw kept on success too (popup memory only) so a channel can be diagnosed without re-capturing.
    return { label: ch.label, channelId: ch.channelId, ok: true, data, raw: JSON.stringify(json) };
  } catch (e) {
    await listP; // never leave it dangling
    const out = { label: ch.label, channelId: ch.channelId, ok: false, error: classify(e) };
    if ((e instanceof ShapeError || e instanceof CardFailed) && json !== undefined) out.raw = JSON.stringify(json);
    else if (e instanceof HttpError && e.body) out.raw = e.body;
    return out;
  }
}

const throttled = (r) => (!r.ok && is429(r.error)) || (r.ok && is429(r.data.listError));
const incomplete = (r) => !r.ok || r.data.listError !== undefined;

// Pure orchestrator. All I/O arrives through deps so this is unit-testable.
// channels = [{ label, channelId, pageId?, authUser? }]
// deps = { getAuthHeader, getCards, parseRealtime, listVideos?, parseVideoList?, delay? }
export async function fetchAll(channels, deps) {
  const { getAuthHeader, delay = sleep } = deps;
  let authHeader;
  try { authHeader = await getAuthHeader(); }
  catch (e) { if (e instanceof NotSignedIn) return { signedIn: false, results: [], reason: e.detail || null }; throw e; }

  // First pass: all channels in parallel.
  const results = (await Promise.allSettled(channels.map((ch) => one(ch, authHeader, deps)))).map((s) => s.value);

  // If anything was throttled, retry the other incomplete channels serially with a gap. The first
  // 429 is kept as-is so the throttling stays visible in the UI.
  const firstThrottled = results.findIndex(throttled);
  if (firstThrottled !== -1) {
    for (let i = 0; i < channels.length; i++) {
      if (!incomplete(results[i]) || i === firstThrottled) continue;
      await delay(SERIAL_GAP_MS);
      results[i] = await one(channels[i], authHeader, deps);
    }
  }
  return { signedIn: true, results };
}

// Account indexes to try when linking a channel without a page id: the ones that already link other
// channels first (the team's channels sit on a couple of Google accounts), then the rest in order.
export const PROBE_ACCOUNTS = ['0', '1', '2', '3'];
export function probeOrder(links, accounts = PROBE_ACCOUNTS) {
  const wins = {};
  for (const l of links) if (l.authUser !== undefined && !l.pageId) wins[l.authUser] = (wins[l.authUser] ?? 0) + 1;
  return [...accounts].sort((a, b) => (wins[b] ?? 0) - (wins[a] ?? 0));
}
