import { ShapeError } from './errors.js';

// TOTAL = Studio's own "views since published", pure apart from the injected fetch. The upload list's
// public counter (videos.js lifetimeViews) lags Studio's analytics by hours, so each followed video gets one
// yta_web/get_cards call scoped to it (innertube.buildLifetimeRequest, fixtures/get_cards.lifetime.json) and
// the key-metric total replaces the list figure. Totals are cached in chrome.storage.local.lifetimeTotals =
// { [videoId]: { total, at } }, refreshed when older than LIFETIME_TTL_MS, forgotten after 30 days unseen.
export const LIFETIME_TTL_MS = 10 * 60_000;      // every check in practice (checks are 15 min apart)
const FORGET_MS = 30 * 86_400_000;

const need = (v, path) => { if (v === undefined || v === null) throw new ShapeError(path); return v; };

// get_cards response → the EXTERNAL_VIEWS total (integer).
export function parseLifetime(json) {
  const cards = need(json?.cards, 'cards');
  const tabs = cards.flatMap((c) => c?.keyMetricCardData?.keyMetricTabs ?? []);
  const views = tabs.find((t) => t?.primaryContent?.metric === 'EXTERNAL_VIEWS');
  const total = need(views?.primaryContent?.total, 'keyMetricTabs[EXTERNAL_VIEWS].primaryContent.total');
  return Math.round(Number(total));
}

// results (fetchAll) + totals → results with `lifetimeViews` (and `lifetimeAt`) from the analytics where known.
export function applyLifetime(results, totals = {}) {
  return (results ?? []).map((r) => (r.ok ? { ...r, data: { ...r.data, videos: (r.data.videos ?? []).map((v) => {
    const t = totals[v.videoId];
    return t ? { ...v, lifetimeViews: t.total, lifetimeAt: t.at } : v;
  }) } } : r));
}

// Refresh the stale totals of every followed video. followed = { [channelId]: { [videoId]: … } } (followedMap);
// channels = [{ channelId, pageId?, authUser? }]; fetchOne({ channel, videoId }) → total (throws on failure,
// which keeps the old value). A few calls in flight at a time. Returns the new totals map.
export async function refreshLifetime({ followed, channels, totals = {}, fetchOne, now = Date.now(), concurrency = 4 }) {
  const next = {};
  for (const [id, t] of Object.entries(totals)) if (now - (t.at ?? 0) < FORGET_MS) next[id] = t;
  const jobs = [];
  for (const [channelId, videos] of Object.entries(followed ?? {})) {
    const channel = channels.find((c) => c.channelId === channelId) ?? { channelId };
    for (const videoId of Object.keys(videos)) {
      const have = next[videoId];
      if (have && now - have.at < LIFETIME_TTL_MS) continue;
      jobs.push(async () => { try { next[videoId] = { total: await fetchOne({ channel, videoId }), at: now }; } catch { /* keep the old total */ } });
    }
  }
  for (let i = 0; i < jobs.length; i += concurrency) await Promise.all(jobs.slice(i, i + concurrency).map((j) => j()));
  return next;
}
