import { extractChannelId } from './channel-id.js';
import { projectHour, HOUR_MS } from './projection.js';
import { trendOf, isNightHour, countDown, inGrace, GRACE_MS, MIN_HOURLY_VIEWS } from './trend.js';
import { nameFor } from './tracked.js';
import { rowsFor, AUTO_MIN_VIEWS } from './followed.js';

const $ = (sel, root = document) => root.querySelector(sel);
const fmt = new Intl.NumberFormat('en');
const PAGE = 10;         // tracked videos shown per channel before "show older"
const PICK_LIMIT = 20;   // excluded videos offered for restoring

// ---- storage -------------------------------------------------------------------------------
// channels (storage.sync): this install's LINKS — [{ channelId, pageId?, authUser? }] — learned from Studio tabs
// tracked:<channelId>: { videoId: { id (DFM ID), title, publishedAt, thumbnail, addedAt } }  (tracked.js)

async function saveChannels(channels) { await chrome.storage.sync.set({ channels }); }

// Normalise on load too, so an entry saved as a full URL heals itself on the next refresh.
async function loadChannels() {
  const channels = (await chrome.storage.sync.get('channels')).channels ?? [];
  let dirty = false;
  for (const c of channels) {
    const id = extractChannelId(c.channelId);
    if (id && id !== c.channelId) { c.channelId = id; dirty = true; }
  }
  if (dirty) await saveChannels(channels);
  return channels;
}

// Tracking goes through the worker: it updates the shared Notion list (queued if unreachable) and hands
// back the whole map, which the popup renders from.
// Following is per person; the DFM ID / batch link are team data (shared registry `tracked`).
async function trackVideo(channelId, videoId, entry) {
  const r = await chrome.runtime.sendMessage({ type: 'TRACK', channelId, videoId, entry });
  if (r?.tracked) tracked = r.tracked;
  if (r?.excludes && channelsById[channelId]) channelsById[channelId].excludes = r.excludes;
}
async function untrackVideo(channelId, videoId) {
  const r = await chrome.runtime.sendMessage({ type: 'UNTRACK', channelId, videoId });
  if (r?.excludes && channelsById[channelId]) channelsById[channelId].excludes = r.excludes;
}
async function setRegistry(channelId, videoId, entry) {
  const r = await chrome.runtime.sendMessage({ type: 'REGISTRY', channelId, videoId, entry });
  if (r?.tracked) tracked = r.tracked;
}
const excludesOf = (channelId) => channelsById[channelId]?.excludes ?? [];

// ---- active Studio tab → channel + page id + account index ------------------------------------

// Runs inside the Studio page (MAIN world). Reads the brand-account user id Studio sends as
// onBehalfOfUser / X-Goog-PageId (403 without) and SESSION_INDEX — which of the Google accounts
// signed into this Chrome profile the tab acts as, sent as X-Goog-AuthUser (401 if wrong).
function readSessionInPage() {
  const out = { pageId: null, authUser: null };
  try {
    const cfg = window.ytcfg;
    const get = (k) => cfg?.get?.(k) ?? cfg?.data_?.[k] ?? null;
    const ctx = get('INNERTUBE_CONTEXT');
    const html = () => document.documentElement.innerHTML;

    const direct = get('DELEGATED_SESSION_ID');
    const viaCtx = ctx?.user?.onBehalfOfUser;
    const viaHtml = html().match(/"DELEGATED_SESSION_ID"\s*:\s*"(\d+)"/)?.[1] ?? html().match(/"onBehalfOfUser"\s*:\s*"(\d+)"/)?.[1];
    const pageId = direct ?? viaCtx ?? viaHtml ?? null;
    if (pageId) out.pageId = String(pageId);

    const idx = get('SESSION_INDEX') ?? html().match(/"SESSION_INDEX"\s*:\s*"?(\d+)"?/)?.[1];
    if (idx !== null && idx !== undefined && idx !== '') out.authUser = String(idx);
  } catch { /* fall through with whatever we got */ }
  return out;
}

async function sessionFromTab(tab) {
  if (!chrome.scripting?.executeScript || tab?.id === undefined) return { pageId: null, authUser: null };
  try {
    const [r] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, world: 'MAIN', func: readSessionInPage });
    return r?.result ?? { pageId: null, authUser: null };
  } catch { return { pageId: null, authUser: null }; }
}

// The active Studio tab: if it is on a ClickUp channel, record this install's page id / account index
// for it (the link Studio needs for brand accounts); otherwise say the channel is not in ClickUp.
// Returns true when a link was added or changed.
async function linkFromActiveTab(links) {
  const note = $('#note'); note.hidden = true;
  if (!chrome.tabs?.query) return false;
  let tab;
  try { [tab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true }); } catch { return false; }
  const url = tab?.url ?? '';
  if (!/^https:\/\/studio\.youtube\.com\//.test(url)) return false;
  const channelId = extractChannelId(url);
  if (!channelId) return false;
  const known = channelInfo.find((c) => c.channelId === channelId);
  if (!known) { note.hidden = false; note.textContent = `This Studio tab is on ${channelId}, which is not a client channel in the ClickUp Client Database.`; return false; }
  const { pageId, authUser } = await sessionFromTab(tab);
  let entry = links.find((c) => c.channelId === channelId);
  if (!entry) { entry = { channelId }; links.push(entry); }
  let changed = false;
  if (pageId && entry.pageId !== pageId) { entry.pageId = pageId; changed = true; }
  if (authUser !== null && entry.authUser !== authUser) { entry.authUser = authUser; changed = true; }
  if (changed) { await saveChannels(links); note.hidden = false; note.textContent = `Linked ${known.label} to your Google account (account ${authUser ?? '?'}${pageId ? `, page ${pageId}` : ''}).`; }
  return changed;
}

// ---- rendering ------------------------------------------------------------------------------

let lastReply = null;               // kept so untrack/show-older re-render without refetching
let linkDiag = null;                // worker's last account-switcher discovery (why a channel is still "link needed")
let lastOpen = null;                // worker's last "open in Studio": which account / page id it switched to, and whether the switch completed
let marks = [];                     // [{ videoId, type, at }] — changes the worker logged (chrome.storage.local.changeMarks)
let thumbs = {};                    // { videoId: { dataUrl } } — thumbnail snapshots (chrome.storage.local.thumbs)
let tracked = {};                   // { channelId: { videoId: { id, title, publishedAt, thumbnail } } } (chrome.storage.sync "tracked:<channelId>")
let experiments = {};               // { videoId: experiment | null } — Test & compare state per tracked video (chrome.storage.local.experiments)
let testMarks = [];                 // [{ type: 'TestStarted'|'TestFinished', videoId, at, startedAt }] — `at` = when the worker first saw it
const shown = new Map();            // channelId → how many videos requested to show
const pickerOpen = new Set();       // channels whose picker is expanded
let lastUntracked = null;           // { channelId, videoId, entry } — offers Undo until the next action

const SVG = 'http://www.w3.org/2000/svg';
const hourLabel = (ms) => new Date(ms).toLocaleString([], { weekday: 'short', hour: '2-digit', minute: '2-digit' });
// Studio links: the href is the plain edit page (for copy / middle-click), but a normal click asks the
// worker to open it — it first switches YouTube to the channel's Google account / brand channel
// (Studio ignores `authuser`), then sends the tab on to the edit page. See background.js openVideo.
let channelsById = {};              // channelId → { label, channelId, pageId?, authUser? }
const editUrl = (videoId) => `https://studio.youtube.com/video/${videoId}/edit?theme=dark`;
function openInStudio(a, videoId, channelId) {
  a.href = editUrl(videoId);
  a.onclick = (e) => {
    if (e.metaKey || e.ctrlKey || e.shiftKey || e.button !== 0) return;      // let the browser handle modified clicks
    e.preventDefault();
    chrome.runtime.sendMessage({ type: 'OPEN_VIDEO', videoId, channelId }).catch(() => window.open(a.href, '_blank'));
  };
}

// Draws the 48 bars. The in-progress hour (if the last bar is it) is drawn muted, with a dashed
// ghost to its projected end-of-hour height. Night hours are greyed; the six completed hours the
// trend chip judges sit on a band tinted by the verdict; logged changes get a * over their hour.
// marks = [{ type: 'Title'|'Thumbnail', at }]. Returns the projection.
// A dragonfruit seed: a teardrop (round body, one pointed end), about 9 × 7 user units, centred on the origin.
const SEED_PATH = 'M-4.5,0 C-2.5,-1.4 0.5,-3.6 2.4,-3.2 C4.4,-2.8 4.6,1 3,2.6 C1.4,4.2 -1.6,3.6 -3.4,1.6 Z';
function sparkline(svg, bars, height, trend = null, marks = []) {
  svg.replaceChildren();
  const last = bars[bars.length - 1];
  const proj = last ? projectHour(last, Date.now()) : null;
  const max = Math.max(1, ...bars.map((b) => b.views), proj?.projected ?? 0);
  const w = 480 / Math.max(1, bars.length), gap = Math.min(2, w * 0.25);
  const rect = (i, views, cls) => {
    const h = (views / max) * (height - 2);
    const r = document.createElementNS(SVG, 'rect');
    r.setAttribute('x', (i * w + gap / 2).toFixed(2));
    r.setAttribute('y', (height - h).toFixed(2));
    r.setAttribute('width', Math.max(0.5, w - gap).toFixed(2));
    r.setAttribute('height', h.toFixed(2));
    if (cls) r.setAttribute('class', cls);
    return r;
  };
  const slotOf = (ms) => bars.findIndex((b) => ms >= b.startTime && ms < b.startTime + HOUR_MS);
  if (trend?.window?.length) {
    const first = slotOf(trend.window[0].startTime), lastSlot = slotOf(trend.window[trend.window.length - 1].startTime);
    if (first !== -1 && lastSlot !== -1) {
      const band = document.createElementNS(SVG, 'rect');
      const grace = marks.some((m) => Date.now() - m.at >= 0 && Date.now() - m.at < GRACE_MS);
      band.setAttribute('class', `window ${trend.direction ?? 'none'}${trend.night ? ' night' : ''}${grace ? ' grace' : ''}`);
      band.setAttribute('x', (first * w).toFixed(2));
      band.setAttribute('y', '0'); band.setAttribute('width', ((lastSlot - first + 1) * w).toFixed(2)); band.setAttribute('height', String(height));
      svg.append(band);
    }
  }
  bars.forEach((b, i) => {
    const isCurrent = proj && b === last;
    const night = isNightHour(b.startTime) ? ' night' : '';
    if (isCurrent && proj.projected !== null) {
      const ghost = rect(i, proj.projected, 'ghost' + night);
      const gt = document.createElementNS(SVG, 'title');
      gt.textContent = `Projected by end of hour: ~${fmt.format(proj.projected)} (${Math.round(proj.fraction * 100)}% elapsed)`;
      ghost.append(gt);
      svg.append(ghost);
    }
    const r = rect(i, b.views, ((isCurrent ? 'current' : '') + night).trim() || null);
    const t = document.createElementNS(SVG, 'title');
    t.textContent = isCurrent
      ? `${hourLabel(b.startTime)} — ${fmt.format(b.views)} so far (${proj.elapsedMinutes} min in)${proj.projected !== null ? ` → ~${fmt.format(proj.projected)} projected` : ''}`
      : `${hourLabel(b.startTime)} — ${fmt.format(b.views)} views`;
    r.append(t);
    svg.append(r);
  });
  // Hovering the hour's bar (or its ghost) under a seed shows the same card — the seed itself is small.
  const bySlot = new Map();
  svg.onmouseover = (e) => {
    const t = e.target;
    if (!(t instanceof SVGRectElement) || t.classList.contains('window')) return;
    const i = Math.floor(parseFloat(t.getAttribute('x')) / w);
    const m = bySlot.get(i);
    if (m) showPopover(m, e);
  };
  svg.onmouseout = (e) => { if (e.target instanceof SVGRectElement && bySlot.has(Math.floor(parseFloat(e.target.getAttribute('x')) / w))) hidePopover(); };
  for (const m of marks) {
    let i = slotOf(m.at);
    if (i === -1 && m.type === 'Test' && bars.length && m.at < bars[0].startTime) i = 0;   // a test older than the window pins to the left edge
    if (i === -1) continue;
    // The mark is the seed from the logo: red for a title/thumbnail change, orange for a running
    // Test & compare, light orange once it has finished. Hover for the before/after card.
    const star = document.createElementNS(SVG, 'g');
    star.setAttribute('class', `mark ${m.type}${m.type === 'Test' ? ` ${m.experiment.state}` : ''}`);
    star.setAttribute('transform', `translate(${(i * w + w / 2).toFixed(2)} 6) rotate(-90) scale(0.8)`);   // tip pointing down, 20% smaller
    const hit = document.createElementNS(SVG, 'circle'); hit.setAttribute('class', 'hit'); hit.setAttribute('r', '10');   // generous hover target (scaled 0.8 → 8)
    const seed = document.createElementNS(SVG, 'path'); seed.setAttribute('class', 'seed'); seed.setAttribute('d', SEED_PATH);
    star.append(hit, seed);
    star.onmouseenter = (e) => showPopover(m, e);
    star.onmousemove = (e) => placePopover(e);
    star.onmouseleave = hidePopover;
    star.onclick = (e) => { e.stopPropagation(); showPopover(m, e); };
    // Invisible full-height column under the seed: hovering anywhere in that hour opens the card.
    const col = document.createElementNS(SVG, 'rect');
    col.setAttribute('class', 'colhit'); col.setAttribute('x', (i * w).toFixed(2)); col.setAttribute('y', '0'); col.setAttribute('width', w.toFixed(2)); col.setAttribute('height', String(height));
    col.onmouseenter = (e) => showPopover(m, e); col.onmousemove = (e) => placePopover(e); col.onmouseleave = hidePopover;
    svg.append(col, star);
    bySlot.set(i, m);
  }
  return proj;
}

// Before/after card for a * marker. Positioned by the pointer, clamped to the viewport.
const when = (ms) => (ms ? new Date(ms).toLocaleString([], { weekday: 'short', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' }) : '?');
// Hover debug (Developer block): the last few things that happened around the card, so a "nothing happens"
// report can say what the pointer actually hit and whether the card was shown and where.
const hoverLog = [];
function logHover(msg) {
  hoverLog.push(`${new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })} ${msg}`);
  if (hoverLog.length > 8) hoverLog.shift();
  const out = document.querySelector('#hover-debug'); if (out) out.textContent = hoverLog.join('\n');
}
document.addEventListener('mouseover', (e) => {
  const t = e.target;
  if (t instanceof SVGElement && t.closest('.spark')) logHover(`over ${t.tagName}.${t.getAttribute('class') ?? ''}`);
}, true);
function showPopover(m, e) {
  try { showPopoverInner(m, e); const r = $('#popover').getBoundingClientRect(); logHover(`show ${m.type} at ${Math.round(r.x)},${Math.round(r.y)} ${Math.round(r.width)}×${Math.round(r.height)} hidden=${$('#popover').hidden} win=${window.innerWidth}×${window.innerHeight}`); }
  catch (err) { const pop = $('#popover'); pop.className = ''; $('.pop-head', pop).textContent = `Could not render this card: ${err?.message ?? err}`; $('.pop-grid', pop).replaceChildren(); pop.hidden = false; placePopover(e); }
}
function showPopoverInner(m, e) {
  const pop = $('#popover');
  pop.className = m.type;
  const head = $('.pop-head', pop); head.replaceChildren();
  const grid = $('.pop-grid', pop); grid.replaceChildren();
  const b = document.createElement('b');
  if (m.type === 'Test') {
    const x = m.experiment;
    const kind = [x.hasThumbnails ? 'thumbnail' : null, x.hasTitles ? 'title' : null].filter(Boolean).join(' + ') || 'A/B';
    const winner = x.winnerArm !== null ? x.arms[x.winnerArm] : null;
    b.textContent = x.state === 'running' ? `${kind} test running` : x.state === 'finished' ? `${kind} test finished` : `${kind} test (${x.rawState ?? 'unknown state'})`;
    const seenMark = testMarks.find((k) => k.type === 'TestStarted' && k.videoId === m.videoId && (k.startedAt ?? null) === (x.startedAt ?? null));
    const tail = x.state === 'running'
      ? ` · started ${when(x.startedAt)}${seenMark ? ` · detected ${when(seenMark.at)}` : ''} · ${x.arms.length} variations`
      : ` · ${when(x.startedAt)} → ${x.finishedAt ? when(x.finishedAt) : '?'}${winner ? ` · winner ${winner.label}` : x.resultState?.includes('NOT_ENOUGH_DATA') ? ' · not enough data' : ''}${x.selectedArm !== null && !winner ? ` · kept ${x.arms[x.selectedArm]?.label ?? '?'}` : ''}`;
    head.append(b, document.createTextNode(tail));
    grid.style.gridTemplateColumns = `repeat(${Math.max(2, x.arms.length)}, 1fr)`;
    for (const a of x.arms) {
      const col = document.createElement('div'); col.className = 'pop-col' + (a.index === x.winnerArm ? ' winner' : '') + (a.index === x.selectedArm && x.state === 'finished' ? ' selected' : '');
      const lab = document.createElement('div'); lab.className = 'lab';
      lab.textContent = `${a.label}${a.index === x.winnerArm ? ' · winner' : a.index === x.selectedArm && x.state === 'finished' ? ' · kept' : ''}`;
      const img = document.createElement('img'); img.alt = ''; const src = a.thumbnail ?? m.fallbackThumb; if (src) img.src = src;
      const share = document.createElement('div'); share.className = 'share'; share.textContent = a.share !== null ? `${a.share}%` : (x.state === 'running' ? '…' : '—');
      share.title = a.share !== null ? 'watch-time share' : 'share not reported by Studio for this test';
      col.append(lab, img, share);
      if (a.title) { const t = document.createElement('div'); t.className = 't'; t.textContent = a.title; col.append(t); }
      grid.append(col);
    }
  } else {
    b.textContent = m.type === 'Thumbnail' ? 'Thumbnail changed' : 'Title changed';
    head.append(b, document.createTextNode(` · ${when(m.at)}${m.dfmId ? ` · ${m.dfmId}` : ''}`));
    if (m.type === 'Thumbnail' && (m.oldId || m.newId)) {            // what the detector compared
      const ids = document.createElement('div'); ids.className = 'pop-ids';
      ids.textContent = `image id ${m.oldId ?? '?'} → ${m.newId ?? '?'}`;
      head.append(ids);
    }
    grid.style.gridTemplateColumns = '1fr 1fr';
    for (const [lab, src, txt] of [['Before', m.oldImage, m.oldTitle], ['After', m.newImage, m.newTitle]]) {
      const col = document.createElement('div'); col.className = 'pop-col';
      const l = document.createElement('div'); l.className = 'lab'; l.textContent = lab;
      const img = document.createElement('img'); img.alt = ''; img.className = lab.toLowerCase(); if (src) img.src = src;
      const t = document.createElement('div'); t.className = `t ${lab.toLowerCase()}`; t.textContent = txt ?? '';
      col.append(l, img, t); grid.append(col);
    }
  }
  pop.hidden = false;
  placePopover(e);
}
function placePopover(e) {
  const pop = $('#popover');
  if (pop.hidden) return;
  // The popup window is as tall as its content (600 px at most) and cannot grow for a fixed card, so the
  // card must always fit inside it: below the pointer, else above, else clamped — and capped in height.
  const pad = 12, W = window.innerWidth, H = window.innerHeight;
  pop.style.maxHeight = `${Math.max(120, H - 2 * pad)}px`;
  const w = pop.offsetWidth, h = pop.offsetHeight;
  let x = e.clientX + pad, y = e.clientY + pad;
  if (x + w > W - pad) x = e.clientX - w - pad;
  x = Math.min(Math.max(pad, x), Math.max(pad, W - w - pad));
  if (y + h > H - pad) y = e.clientY - h - pad;
  y = Math.min(Math.max(pad, y), Math.max(pad, H - h - pad));
  pop.style.left = `${x}px`; pop.style.top = `${y}px`;
}
function hidePopover() { if (!$('#popover').hidden) logHover('hide'); $('#popover').hidden = true; }

function errorText(error, info, attempts) {
  const used = info ? ` (tried account ${info.authUser ?? '?'}${info.pageId ? `, page ${info.pageId}` : ', no page id'}${linkDiag ? `; switcher: ${linkDiag.accounts?.length ?? 0} accounts, ${linkDiag.identities} identities, ${linkDiag.matched} matched, ${linkDiag.rejected?.length ?? 0} rejected${linkDiag.errors?.length ? `, errors: ${linkDiag.errors.join('; ')}` : ''}` : ''})` : '';
  const tried = attempts?.length ? ` Tried: ${attempts.join(' · ')}.` : '';
  if (error.kind === 'http' && error.status === 401) return `Not authorised${used}.${tried} Open this channel in Studio once and click the icon.`;
  if (error.kind === 'http' && error.status === 403) return `Permission denied${used}.${tried} Open this channel in Studio once and click the icon.`;
  if (error.kind === 'shape') return error.message;
  return `Request failed (${error.message})`;
}

// "↓ 23%" / "↑ 12%" / "→ flat" / "·" — last 3 completed hours vs the 3 before. Tooltip lists both
// groups. During night hours the chip is greyed (a dip then is normal).
const ARROW = { down: '↓', up: '↑', flat: '→' };
const clock = (ms) => new Date(ms).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
function renderTrend(el, t, graceAt = null) {
  el.textContent = t.direction === null ? '·' : t.direction === 'flat' ? '→ flat' : `${ARROW[t.direction]} ${Math.abs(t.pct)}%`;
  el.className = `vtrend ${t.direction ?? 'none'}${t.night ? ' night' : ''}${graceAt !== null ? ' grace' : ''}${t.weak ? ' weak' : ''}`;
  const group = (recent) => t.window.filter((h) => h.recent === recent).map((h) => `${clock(h.startTime)} ${fmt.format(h.views)}`).join(' · ');
  const lines = t.window.length ? [`previous 3 h: ${group(false)} = ${fmt.format(t.prior)}`, `last 3 h: ${group(true)} = ${fmt.format(t.recent)}`] : [];
  const notes = [
    t.direction === null ? (t.window.length ? 'no views in the previous 3 h — nothing to compare' : 'not enough completed hours yet') : `last 3 h vs previous 3 h: ${t.pct > 0 ? '+' : ''}${t.pct}%`,
    t.weak && t.direction !== null ? `low volume (under ${MIN_HOURLY_VIEWS} views/h before) — shown for information, not counted in the badge` : null,
    'the hour in progress is not counted',
    t.night ? 'night hours (00–05 UTC / Eastern) — a dip is normal' : null,
    graceAt !== null ? `changed ${ago(Date.now() - graceAt)} — not counted as going down for ${Math.ceil((graceAt + GRACE_MS - Date.now()) / 60_000)} more min` : null,
  ].filter(Boolean);
  el.title = [...lines, ...notes].join('\n');
}

// The DFM ID cell: text, with hover actions "notion" (the DFM batch page) and "edit" (inline editor for
// id + link). Saving re-checks uniqueness within the channel and renames the video's Notion rows if
// the id changed.
// A cell with a menu that opens on hover and closes 700 ms after the pointer leaves the cell AND the menu —
// enough time to move onto it. Used by the DFM ID (notion · clickup · edit) and the title (youtube · yt studio).
function hoverMenu(cell) {
  let closeTimer = null;
  const open = () => { clearTimeout(closeTimer); cell.classList.add('open'); };
  const close = () => { clearTimeout(closeTimer); closeTimer = setTimeout(() => cell.classList.remove('open'), 700); };
  cell.onmouseenter = open; cell.onmouseleave = close;
}
function renderDfm(li, v, channelId) {
  const entry = tracked[channelId]?.[v.videoId] ?? {};
  const cell = $('.vdfm', li), notion = $('.vnotion', cell), cu = $('.vclickup', cell), editor = $('.veditor', li);
  $('.vid', cell).textContent = dfmLabel(channelId, entry.id);
  cell.title = [entry.notionUrl ? `Notion (batch ideation${entry.batchName ? `, ${entry.batchName}` : ''}): ${entry.notionUrl}` : null, entry.clickupUrl ? `ClickUp video task: ${entry.clickupUrl}` : null].filter(Boolean).join('\n') || 'no DFM links yet — hover → edit (pick the ClickUp task)';
  if (entry.notionUrl) { notion.href = entry.notionUrl; notion.classList.remove('none'); notion.title = entry.notionUrl; }
  else { notion.removeAttribute('href'); notion.classList.add('none'); notion.title = 'no Notion link — pick the ClickUp task (its 🧠 Ideation Link) or type one'; }
  if (cu) { if (entry.clickupUrl) { cu.href = entry.clickupUrl; cu.classList.remove('none'); cu.title = entry.clickupUrl; } else { cu.removeAttribute('href'); cu.classList.add('none'); cu.title = 'no ClickUp task linked — use edit'; } }
  hoverMenu(cell);
  $('.vedit', cell).onclick = () => {
    cell.classList.remove('open');
    editor.hidden = !editor.hidden;
    if (!editor.hidden) { fillTaskPicker(editor.elements.task, channelId, v, entry).then(() => editor.elements.task.focus()); }
  };
  $('.cancel', editor).onclick = () => { editor.hidden = true; };
  editor.elements.task.onchange = () => editor.elements.task.setCustomValidity('');
  // Save = link the picked ClickUp task: the worker writes the video's YouTube URL into the task and fills
  // the DFM ID and links from it. That is the only way to set them — no typing.
  editor.onsubmit = async (e) => {
    e.preventDefault();
    const taskSel = editor.elements.task;
    if (!taskSel.value) { taskSel.setCustomValidity('Pick the ClickUp task for this video'); taskSel.reportValidity(); return; }
    const r = await chrome.runtime.sendMessage({ type: 'CLICKUP_LINK', channelId, videoId: v.videoId, taskId: taskSel.value, title: v.title ?? null, publishedAt: v.publishedAt ?? null, thumbnail: v.thumbnail ?? null }).catch((err) => ({ error: err?.message ?? String(err) }));
    if (r?.error) { taskSel.setCustomValidity(`ClickUp: ${r.error}`); taskSel.reportValidity(); return; }
    if (r?.tracked) tracked = r.tracked;
    editor.hidden = true; render();
    if (r?.task?.dfmId && r.task.dfmId !== entry.id) chrome.runtime.sendMessage({ type: 'RENAME', videoId: v.videoId, name: nameFor(r.task.dfmId, v.videoId) }).catch(() => {});
  };
}
// The editor's ClickUp task list: the client's long-form video tasks not yet linked to a video (newest
// first), the title match preselected. Tasks come from the worker's hourly ClickUp pull.
const cuCache = new Map();   // channelId → CLICKUP_TASKS reply, for one render pass (cleared in render())
async function clickupTasks(channelId) {
  if (!cuCache.has(channelId)) cuCache.set(channelId, chrome.runtime.sendMessage({ type: 'CLICKUP_TASKS', channelId, title: '' }).catch(() => null));
  return cuCache.get(channelId);
}
const normT = (x) => String(x ?? '').toLowerCase().replace(/[^a-z0-9]+/g, ' ').trim();
function suggestFor(videos, title) {
  const t = normT(title); if (t.length < 4) return null;
  const free = videos.filter((x) => !x.videoId);
  const exact = free.find((x) => normT(x.title) === t); if (exact) return exact.taskId;
  const near = free.find((x) => { const n = normT(x.title); return n.length >= 12 && t.length >= 12 && (n.includes(t) || t.includes(n)); });
  return near?.taskId ?? null;
}
async function fillTaskPicker(sel, channelId, v, entry = {}) {
  if (!sel) return;
  sel.replaceChildren(new Option('ClickUp task…', ''));
  const r = await clickupTasks(channelId);
  if (!r) { sel.replaceChildren(new Option('ClickUp: worker unavailable', '')); return; }
  const own = r.videos.find((t) => t.videoId === v.videoId);
  const candidates = r.videos.filter((t) => !t.videoId || t.videoId === v.videoId);
  if (!candidates.length) { sel.replaceChildren(new Option(r.error ? `ClickUp: ${r.error}` : (r.at ? 'ClickUp: no unlinked video task' : 'ClickUp: not loaded yet — press ↻'), '')); return; }
  sel.replaceChildren(new Option(own ? `linked: ${own.name}` : 'ClickUp task…', ''));
  const suggested = suggestFor(r.videos, v.title);
  for (const t of candidates) sel.append(new Option(`${t.dfmId} · ${t.title}${t.batchName ? ` (${t.batchName})` : ''}${t.taskId === suggested ? '  ← title match' : ''}`, t.taskId));
  if (!entry.id && suggested) sel.value = suggested;
}
// Tooltip for "link needed": what the worker found in the account switcher on its last pass.
function linkHelp() {
  const base = 'Not linked to one of your signed-in Google accounts yet.';
  if (!linkDiag) return `${base} Press ↻ — the extension reads your account switcher to find the channel's page id.`;
  const when = `checked ${ago(Date.now() - linkDiag.at)}`;
  const acc = linkDiag.accounts?.length ? `${linkDiag.accounts.length} account${linkDiag.accounts.length === 1 ? '' : 's'} (${linkDiag.accounts.join(', ')})` : 'no signed-in account found';
  const err = linkDiag.errors?.length ? ` Errors: ${linkDiag.errors.join('; ')}.` : '';
  return `${base} Account switcher ${when}: ${acc}, ${linkDiag.identities} channel identities, ${linkDiag.matched} matched to ClickUp handles.${err} This channel's handle is not among them — is the channel on one of these accounts and is its ClickUp "YouTube Channel" URL a handle URL? Fallback: open it in Studio and click the icon.`;
}
// "BD LF 049": client initials + LF + the episode number from ClickUp; any other id is shown as is.
function dfmLabel(channelId, id) {
  if (!id) return '';
  const initials = channelsById[channelId]?.initials;
  return /^\d{1,4}$/.test(id) && initials ? `${initials} LF ${id}` : id;
}
const titleOf = (channelId, videoId) => {
  const t = tracked[channelId]?.[videoId]?.title ?? lastReply?.results.find((x) => x.channelId === channelId)?.data?.videos?.find((x) => x.videoId === videoId)?.title;
  return t ? `“${t}”` : videoId;
};

function renderVideo(v, channelId) {
  const li = $('#video-tpl').content.firstElementChild.cloneNode(true);
  const thumb = $('.vthumb', li); openInStudio(thumb, v.videoId, channelId);
  const src = thumbs[v.videoId]?.dataUrl ?? v.thumbnail;
  if (src) $('img', thumb).src = src;
  const title = $('.vtitle', li);
  title.textContent = v.title ?? v.videoId;
  title.title = `${v.title ?? v.videoId}${v.publishedAt ? ` · published ${new Date(v.publishedAt).toLocaleDateString()}` : ''} — hover for youtube · yt studio`;
  // Hover the title: "youtube" (the public watch page) and "yt studio" (the editor, under the right account).
  const tbox = $('.vtbox', li);
  $('.tyt', tbox).href = `https://www.youtube.com/watch?v=${v.videoId}`;
  openInStudio($('.tstudio', tbox), v.videoId, channelId);
  hoverMenu(tbox);
  renderDfm(li, v, channelId);
  $('.vviews', li).textContent = fmt.format(v.views48h);
  $('.vtotal', li).textContent = v.lifetimeViews != null ? fmt.format(v.lifetimeViews) : '—';
  $('.vtotal', li).title = v.lifetimeViews != null ? `${fmt.format(v.lifetimeViews)} views since publication` : 'total views unknown (upload list unavailable)';
  $('.vviews', li).title = `${fmt.format(v.views48h)} views in the last 48 hours`;
  li.classList.toggle('quiet', !v.inRealtime);
  $('.hide', li).title = 'Stop following this video — the next upload takes its slot; restore it from “Excluded videos”';
  $('.hide', li).onclick = async () => {
    lastUntracked = { channelId, videoId: v.videoId };
    await untrackVideo(channelId, v.videoId);
    render();
  };
  const trend = trendOf(v.bars, Date.now());
  const own = marks.filter((m) => m.videoId === v.videoId);
  renderTrend($('.vtrend', li), trend, inGrace(own, v.videoId, Date.now()));
  // A Test & compare run shows as ~ above the hour the worker FIRST SAW it (left edge once that is
  // older than the window); once finished it moves to the finish hour and the hover card names the winner.
  const x = experiments[v.videoId];
  const seen = x && testMarks.find((m) => m.type === 'TestStarted' && m.videoId === v.videoId && (m.startedAt ?? null) === (x.startedAt ?? null));
  // No detection mark yet (first check after an upgrade) → the current hour, never the left edge.
  const testAt = !x ? null : x.state === 'finished' && x.finishedAt ? x.finishedAt : (seen?.at ?? Date.now());
  const fallbackThumb = thumbs[v.videoId]?.dataUrl ?? v.thumbnail ?? null;   // title-only tests show the video's own thumbnail per arm
  sparkline($('.spark', li), v.bars, 28, trend, [...own, ...(x ? [{ type: 'Test', videoId: v.videoId, at: testAt, experiment: x, fallbackThumb }] : [])]);
  return li;
}

// One row per FOLLOWED video (this person's choice per channel: auto = latest 10, manual = picks), joined
// with the live list and the shared registry (DFM ID, batch link). See followed.js.
function trackedRows(result) {
  return rowsFor({ videos: result.data.videos ?? [], excludes: excludesOf(result.channelId), registry: tracked[result.channelId] ?? {}, bars: result.data.bars ?? [] });
}

// The picker: excluded videos, to restore.
function renderPicker(node, result) {
  const box = $('.picker', node), grid = $('.grid', box);
  // The picker only offers the videos this person excluded (× on a row), to restore them.
  const excluded = new Set(excludesOf(result.channelId));
  const candidates = (result.data.videos ?? []).filter((v) => !v.isShort && excluded.has(v.videoId)).slice(0, PICK_LIMIT);
  if (!candidates.length) { box.hidden = true; $('.track', node).hidden = true; return; }
  const open = pickerOpen.has(result.channelId);
  box.hidden = !open;
  const btn = $('.track', node); btn.hidden = false;
  btn.textContent = open ? 'Hide excluded' : `Excluded videos (${candidates.length})`;
  btn.onclick = () => { if (open) pickerOpen.delete(result.channelId); else pickerOpen.add(result.channelId); render(); };
  if (!open) return;
  grid.replaceChildren();
  if (!candidates.length) {
    const p = document.createElement('p'); p.className = 'empty hint';
    p.textContent = result.data.listError ? 'Upload list unavailable — nothing to pick from.' : 'Nothing excluded.';
    grid.append(p);
    return;
  }
  for (const v of candidates) {
    const card = $('#pick-tpl').content.firstElementChild.cloneNode(true);
    const src = thumbs[v.videoId]?.dataUrl ?? v.thumbnail;
    if (src) $('img', card).src = src;
    $('.ptitle', card).textContent = v.title ?? v.videoId;
    card.title = v.title ?? v.videoId;
    $('.pdate', card).textContent = v.publishedAt ? new Date(v.publishedAt).toLocaleDateString([], { month: 'short', day: 'numeric' }) : '';
    const form = $('.pform', card);
    const pick = () => { if (card.classList.contains('picked')) return; grid.querySelectorAll('.pick.picked').forEach((c) => c.classList.remove('picked')); card.classList.add('picked'); };
    card.onclick = (e) => { if (!form.contains(e.target)) pick(); };
    card.onkeydown = (e) => { if ((e.key === 'Enter' || e.key === ' ') && e.target === card) { e.preventDefault(); pick(); } };
    form.onsubmit = async (e) => {           // Add back: the video leaves this person's exclude list
      e.preventDefault();
      await trackVideo(result.channelId, v.videoId, null);
      pickerOpen.add(result.channelId);
      render();
      chrome.runtime.sendMessage({ type: 'FETCH_ALL' }).catch(() => {});
    };
    grid.append(card);
  }
}

function renderChannel(result) {
  const node = $('#channel-tpl').content.firstElementChild.cloneNode(true);
  $('.label', node).textContent = result.label;
  const info = channelsById[result.channelId];
  // Hover the name: how this install reaches the channel in Studio (account index / page id) and how the last open went.
  $('.label', node).title = [
    info ? `Studio access: ${info.pageId ? `page ${info.pageId}` : 'no page id'}, account ${info.authUser ?? '?'}${info.verified ? ' (verified)' : ''}` : null,
    lastOpen && lastOpen.channelId === result.channelId ? `last open ${ago(Date.now() - lastOpen.at)} — ${lastOpen.mode ? `worked with “${lastOpen.mode}”` : 'nothing worked'}; tried: ${(lastOpen.attempts ?? []).join(' · ')}` : null,
  ].filter(Boolean).join('\n');
  if (info?.avatar) $('.avatar', node).src = info.avatar;
  if (info && !info.pageId && info.authUser === undefined) { const t = tag('link needed', 'unlinked'); t.title = linkHelp(); $('.label', node).append(t); }
  const rm = $('.remove-channel', node); rm.onclick = () => setChannelActive(result.channelId, false);
  if (!result.ok) {
    const err = $('.err', node); err.hidden = false; err.textContent = errorText(result.error, info, result.attempts);
    if (result.raw) {
      const btn = $('.copy-raw', node); btn.hidden = false;
      btn.onclick = async () => { await navigator.clipboard.writeText(result.raw); btn.textContent = 'Copied'; };
    }
    return node;
  }

  const rows = trackedRows(result);
  const requested = shown.get(result.channelId) ?? PAGE;
  const count = Math.min(rows.length, requested);
  $('.meta', node).textContent = `latest ${rows.length} above ${AUTO_MIN_VIEWS} views in the last 48h`;
  $('.meta', node).title = 'The latest 10 long-form uploads with at least 50 views in the last 48 h, minus the ones you excluded with × — a video that picks up again comes back by itself';
  if (result.data.listError !== undefined) {
    const err = $('.err', node); err.hidden = false;
    err.textContent = `Upload list unavailable (${result.data.listError.message}) — titles and thumbnails may be stale`;
  }

  const ol = $('.videos', node);
  rows.slice(0, count).forEach((v) => ol.append(renderVideo(v, result.channelId)));
  if (!rows.length) ol.remove();

  const remaining = rows.length - count;
  if (remaining > 0) {
    const b = $('.older', node); b.hidden = false;
    b.textContent = `Show ${Math.min(PAGE, remaining)} older (${remaining} more)`;
    b.onclick = () => { shown.set(result.channelId, requested + PAGE); render(); };
  }
  // One-shot Undo for the most recent untrack in this channel — the × is easy to hit by accident.
  if (lastUntracked && lastUntracked.channelId === result.channelId) {
    const u = $('.undo', node); u.hidden = false;
    const t = tracked[result.channelId]?.[lastUntracked.videoId]?.title ?? lastReply?.results.find((x) => x.channelId === result.channelId)?.data?.videos?.find((x) => x.videoId === lastUntracked.videoId)?.title ?? lastUntracked.videoId; const short = t.length > 40 ? t.slice(0, 39) + '…' : t;
    u.textContent = `Stopped tracking “${short}” — Undo`;
    u.onclick = async () => { const { channelId, videoId } = lastUntracked; lastUntracked = null; await trackVideo(channelId, videoId, null); render(); };
  }
  renderPicker(node, result);
  return node;
}

let loading = false;                // a FETCH_ALL is in flight: added channels without data yet show a skeleton
function render() {
  cuCache.clear();
  const rows = $('#rows'); rows.replaceChildren();
  const results = lastReply?.results ?? [];
  results.filter((r) => channelsById[r.channelId]?.active).forEach((r) => rows.append(renderChannel(r)));
  // Skeletons: active channels the current data does not cover yet (just added, or first load).
  if (loading) {
    const have = new Set(results.map((r) => r.channelId));
    for (const c of channelInfo) if (c.active && !have.has(c.channelId)) rows.append(renderSkeleton(c));
  }
  if (lastReply) setStatus(lastUpdatedAt);
}
// Placeholder section for a channel whose data is loading: real avatar and label, three grey rows.
function renderSkeleton(c) {
  const node = $('#channel-tpl').content.firstElementChild.cloneNode(true);
  node.classList.add('skel'); node.setAttribute('aria-busy', 'true');
  if (c.avatar) $('.avatar', node).src = c.avatar;
  $('.label', node).textContent = c.label;
  $('.meta', node).textContent = 'loading…';
  $('.remove-channel', node).onclick = () => setChannelActive(c.channelId, false);
  const list = $('.videos', node);
  for (let i = 0; i < 3; i++) {
    const li = document.createElement('li'); li.className = 'video skrow';
    li.innerHTML = '<span class="sk sk-thumb"></span><div><span class="sk sk-title" style="width:' + (55 + i * 12) + '%"></span><span class="sk sk-spark"></span></div>';
    list.append(li);
  }
  $('.picker', node).hidden = true; $('.track', node).hidden = true;
  return node;
}

let channelInfo = [];               // from the worker: ClickUp clients + this install's link + `hidden` (removed from this popup)
const tag = (text, cls = '') => { const t = document.createElement('span'); t.className = `tag ${cls}`.trim(); t.textContent = text; return t; };
// Add / remove a channel in THIS popup (storage.sync `activeChannels`, opt-in). Shared tracking is untouched.
async function setChannelActive(channelId, active) {
  const { activeChannels = [] } = await chrome.storage.sync.get('activeChannels');
  const next = active ? [...new Set([...activeChannels, channelId])] : activeChannels.filter((id) => id !== channelId);
  await chrome.storage.sync.set({ activeChannels: next });
  if (active) pickerOpen.add(channelId);      // a newly added channel opens on its upload picker
  await refresh();
}
// The directory: every ClickUp client with a channel, profile picture first. Added channels are dimmed;
// the rest have Add. Shown in full when nothing is added yet, otherwise collapsed behind a toggle.
let dirOpen = false;
function renderDirectory() {
  const box = $('#directory'), ul = $('.dir', box);
  ul.replaceChildren();
  const added = channelInfo.filter((c) => c.active).length;
  const toggle = $('#dir-toggle');
  const showAll = dirOpen || added === 0;
  toggle.hidden = added === 0 || channelInfo.length === 0;
  toggle.textContent = showAll ? 'Hide channel list' : `Add a channel (${channelInfo.length - added} more)`;
  toggle.onclick = () => { dirOpen = !dirOpen; renderDirectory(); };
  box.hidden = !showAll || channelInfo.length === 0;
  if (box.hidden) return;
  for (const c of channelInfo) {
    const li = document.createElement('li'); if (c.active) li.className = 'active';
    const img = document.createElement('img'); img.alt = ''; if (c.avatar) img.src = c.avatar;
    const name = document.createElement('span'); name.className = 'dname'; name.title = [c.pod, c.tier ? `Tier ${c.tier}` : null, c.status, c.channelId].filter(Boolean).join(' · ');
    const initials = document.createElement('span'); initials.className = 'initials'; initials.textContent = c.initials ?? '';
    const cname = document.createElement('span'); cname.className = 'cname'; cname.textContent = c.clientName ?? c.label; cname.title = c.clientName ?? c.label;
    const tags = document.createElement('span'); tags.className = 'tags';
    if (c.status && c.status !== 'active') tags.append(tag(c.status));
    if (!c.pageId && c.authUser === undefined) { const t = tag('link needed', 'unlinked'); t.title = linkHelp(); tags.append(t); }
    name.append(initials, cname, tags);
    const btn = document.createElement('button'); btn.textContent = c.active ? 'Remove' : 'Add'; btn.className = c.active ? 'remove' : '';
    btn.title = c.active ? 'Stop showing this channel in your popup (tracking data is untouched)' : 'Show this channel in your popup';
    btn.onclick = () => setChannelActive(c.channelId, !c.active);
    li.append(img, name, btn);
    ul.append(li);
  }
}
async function renderChannelList() { renderDirectory(); }

// ---- status line: "3 going down · updated 4 min ago" -------------------------------------------
let lastUpdatedAt = null;
const ago = (ms) => { const m = Math.round(ms / 60_000); return m < 1 ? 'just now' : m === 1 ? '1 min ago' : m < 60 ? `${m} min ago` : `${Math.round(m / 60)} h ago`; };
function downText() {
  const now = Date.now();
  if (isNightHour(now)) return 'night hours';
  const n = countDown(lastReply?.results ?? [], { tracked, marks, now });
  return n ? `${n} going down` : 'nothing going down';
}
function setStatus(updatedAt, extra = []) {
  lastUpdatedAt = updatedAt;
  const parts = [lastReply ? downText() : null, updatedAt === null ? null : `updated ${ago(Date.now() - updatedAt)}`, ...extra].filter(Boolean);
  $('#status').textContent = parts.join(' · ');
}

async function refresh() {
  const rows = $('#rows'); rows.replaceChildren();
  const banner = $('#banner'); banner.hidden = true;
  lastReply = null;
  ({ changeMarks: marks = [], thumbs = {}, experiments = {}, testMarks = [], tracked = {} } = await chrome.storage.local.get(['changeMarks', 'thumbs', 'experiments', 'testMarks', 'tracked']));
  const links = await loadChannels();
  const chResp = await chrome.runtime.sendMessage({ type: 'CHANNELS' }).catch(() => null);
  channelInfo = chResp?.channels ?? []; linkDiag = chResp?.linkDiag ?? null; lastOpen = chResp?.lastOpen ?? null;
  if (await linkFromActiveTab(links)) channelInfo = (await chrome.runtime.sendMessage({ type: 'CHANNELS' }).catch(() => null))?.channels ?? channelInfo;   // re-read with the new link
  channelsById = Object.fromEntries(channelInfo.map((c) => [c.channelId, c]));
  for (const c of channelInfo) tracked[c.channelId] ??= {};
  await renderChannelList();
  if (!channelInfo.some((c) => c.active)) {
    $('#status').textContent = channelInfo.length ? 'add a channel to see its videos' : '';
    await refreshSetupStatus();
    return;
  }

  // Cached-first: the worker's 15-minute poll (or the last manual refresh) left a snapshot behind.
  // Render it now, then refresh behind it. Snapshot rows carry no raw JSON, so "Copy raw" waits.
  const { snapshot } = await chrome.storage.local.get('snapshot');
  if (snapshot?.reply?.signedIn && snapshot.reply.results?.length) {
    lastReply = snapshot.reply;
    render();
    setStatus(snapshot.at, ['updating…', snapshot.error ? `last background check failed (${snapshot.error})` : null]);
  } else {
    $('#status').textContent = 'updating…';
  }
  loading = true; render();                              // skeletons for channels the snapshot does not cover
  const reply = await chrome.runtime.sendMessage({ type: 'FETCH_ALL' });
  loading = false;
  if (!reply?.signedIn) {
    rows.replaceChildren();
    banner.hidden = false;
    banner.innerHTML = 'No YouTube session in this Chrome profile — <a href="https://studio.youtube.com" target="_blank" rel="noopener">open Studio</a> signed in to the Google account that manages the channels, then refresh. Cookies are per Chrome profile.'
      + (reply?.reason ? ` <small>(${reply.reason})</small>` : '');
    $('#status').textContent = '';
    return;
  }
  if (reply.fatal) { banner.hidden = false; banner.textContent = `Worker error: ${reply.fatal}`; setStatus(snapshot?.at ?? null); return; }
  lastReply = reply;
  render();
  setStatus(Date.now());
  await refreshSetupStatus();
}

// ---- setup: two tokens, one button ---------------------------------------------------------------
// Save stores whatever was typed (tokens live in the worker's storage.local), then pulls ClickUp and
// re-renders. Once both tokens exist the button reads Refresh and does the pull without saving.
const setupForm = $('#setup-form');
let setupState = { clickup: false, notion: false };
async function refreshSetupStatus() {
  const [cu, no] = await Promise.all([
    chrome.runtime.sendMessage({ type: 'CLICKUP_STATUS' }).catch(() => null),
    chrome.runtime.sendMessage({ type: 'CHANGES_STATUS' }).catch(() => null),
  ]);
  setupState = { clickup: Boolean(cu?.configured), notion: Boolean(no?.configured) };
  setupForm.elements.clickup.placeholder = setupState.clickup ? 'ClickUp token saved' : 'ClickUp API token';
  setupForm.elements.notion.placeholder = setupState.notion ? 'Notion token saved' : 'Notion token';
  $('#setup-save').textContent = setupState.clickup && setupState.notion ? 'Refresh' : 'Save';
  // Both tokens saved → the token form is housekeeping: it lives under Advanced. Otherwise it stays up front.
  const setup = $('#setup'), advanced = $('#advanced');
  if (setupState.clickup && setupState.notion) { if (setup.parentElement !== advanced) advanced.insertBefore(setup, advanced.querySelector('.panel')); }
  else if (setup.parentElement === advanced) advanced.before(setup);
  setup.hidden = false;                          // placed first, shown second: never up front while both tokens are saved
  const parts = [];
  if (!setupState.clickup) parts.push('ClickUp token needed for the channels');
  else if (cu?.error) parts.push(`ClickUp: ${cu.error}`);
  else if (cu?.unresolved) parts.push(`${cu.unresolved} channel${cu.unresolved === 1 ? '' : 's'} unresolved${cu.resolveErrors?.[0] ? ` — ${cu.resolveErrors[0]}` : ''}`);
  if (!setupState.notion) parts.push('Notion token needed for the change log');
  else if (no?.lastError) parts.push(`Notion: ${no.lastError}`);
  else if (no?.pendingShared) {
    const why = no.sharedError ? (/database not set/i.test(no.sharedError) ? 'the Tracked videos database id is not set — Advanced → Save ids' : no.sharedError) : 'retrying on the next check';
    parts.push(`${no.pendingShared} tracking change${no.pendingShared === 1 ? '' : 's'} not yet in the shared Notion list (${why})`);
  }
  $('#setup-status').textContent = parts.join(' · ');
  // Advanced panel details
  const ids = $('#ids-form');
  if (!ids.elements.databaseId.value) ids.elements.databaseId.value = no?.databaseId ?? '';
  if (!ids.elements.trackedDatabaseId.value) ids.elements.trackedDatabaseId.value = no?.trackedDatabaseId ?? '';
  if (!ids.elements.listId.value) ids.elements.listId.value = cu?.listId ?? '';
  ids.elements.databaseId.disabled = Boolean(no?.managed?.changes); ids.elements.trackedDatabaseId.disabled = Boolean(no?.managed?.tracked); ids.elements.listId.disabled = Boolean(cu?.managed);
  $('#notion-resync').disabled = !setupState.notion; $('#notion-test').disabled = !setupState.notion; $('#notion-test-row').disabled = !setupState.notion; $('#notion-purge').disabled = !setupState.notion;
  $('#notion-status').textContent = no && !no.error ? [
    `v${chrome.runtime?.getManifest?.().version ?? '?'}`,
    `${no.tracked} video${no.tracked === 1 ? '' : 's'} tracked${no.trackedDatabaseId ? (no.trackedPulledAt ? ` · shared list pulled ${ago(Date.now() - no.trackedPulledAt)}` : ' · shared list not pulled yet') : ' · no shared list'}`,
    `${no.logged ?? 0} change${no.logged === 1 ? '' : 's'} logged`, no.renamed ? `${no.renamed} row${no.renamed === 1 ? '' : 's'} renamed` : null, no.queued ? `${no.queued} queued` : null,
    no.lastResync ? `re-sync ${ago(Date.now() - no.lastResync.at)}: ${no.lastResync.rows} rows, ${no.lastResync.restored} restored${no.lastResync.linked ? `, ${no.lastResync.linked} linked to videos` : ''}` : null,
    no.lastWarning ? `warning: ${no.lastWarning}` : null, no.lastAt ? `last sync ${ago(Date.now() - no.lastAt)}` : null,
  ].filter(Boolean).join(' · ') : '';
  $('#clickup-status').textContent = cu?.lastPull ? [`${cu.total} clients`, `${cu.withChannel} with a channel`, `${cu.resolved} resolved`, cu.unresolved ? `${cu.unresolved} unresolved (${(cu.unresolvedNames ?? []).join(', ')})` : null, `${cu.skippedArchived} archived skipped`, `pulled ${ago(Date.now() - cu.lastPull)}`, ...(cu.resolveErrors ?? []).map((e) => `resolve: ${e}`)].filter(Boolean).join(' · ') : '';
}
setupForm.onsubmit = async (e) => {
  e.preventDefault();
  const btn = $('#setup-save'); btn.disabled = true;
  const clickup = setupForm.elements.clickup.value.trim(), notion = setupForm.elements.notion.value.trim();
  if (clickup) await chrome.runtime.sendMessage({ type: 'CLICKUP_SAVE', token: clickup }).catch(() => {});
  if (notion) await chrome.runtime.sendMessage({ type: 'NOTION_SAVE', token: notion }).catch(() => {});
  setupForm.reset();
  $('#setup-status').textContent = 'Refreshing…';
  await chrome.runtime.sendMessage({ type: 'CLICKUP_TEST' }).catch(() => {});
  if (notion) await chrome.runtime.sendMessage({ type: 'NOTION_TEST' }).catch(() => {});
  await refresh();
  btn.disabled = false;
};

// ---- advanced -----------------------------------------------------------------------------------
$('#ids-form').onsubmit = async (e) => {
  e.preventDefault();
  const f = e.target.elements;
  await chrome.runtime.sendMessage({ type: 'NOTION_SAVE', databaseId: f.databaseId.value.trim(), trackedDatabaseId: f.trackedDatabaseId.value.trim() }).catch(() => {});
  await chrome.runtime.sendMessage({ type: 'CLICKUP_SAVE', listId: f.listId.value.trim() }).catch(() => {});
  await refreshSetupStatus();
};
for (const b of document.querySelectorAll('.details-toggle')) {
  const d = document.getElementById(b.dataset.details);
  const sync = () => b.classList.toggle('on', d.open);
  b.onclick = () => { d.open = !d.open; sync(); };
  d.addEventListener('toggle', sync); sync();
}
$('#notion-create-tracked').onclick = async () => {
  const out = $('#notion-status'); out.textContent = 'Creating the Tracked videos database…';
  const r = await chrome.runtime.sendMessage({ type: 'NOTION_CREATE_TRACKED' }).catch((e) => ({ ok: false, error: e.message }));
  await refreshSetupStatus();
  out.textContent = r?.ok ? `Created “Tracked videos” (${r.databaseId}) — queued tracking changes are syncing` : `Could not create it: ${r?.error ?? 'unknown'}`;
};
$('#notion-test').onclick = async () => {
  const out = $('#notion-status'); out.textContent = 'Testing…';
  const r = await chrome.runtime.sendMessage({ type: 'NOTION_TEST' }).catch((e) => ({ ok: false, error: e.message }));
  out.textContent = r?.ok
    ? `Connected to “${r.title}”${r.added?.length ? ` · created ${r.added.length} column${r.added.length === 1 ? '' : 's'}` : ' · columns in place'}` + (r.legacy?.length ? ` · safe to delete: ${r.legacy.join(', ')}` : '')
    : `Connection failed: ${r?.error ?? 'unknown'}`;
};
$('#notion-test-row').onclick = async () => {
  const out = $('#notion-status'); out.textContent = 'Writing a test row…';
  const r = await chrome.runtime.sendMessage({ type: 'NOTION_TEST_ROW' }).catch((e) => ({ ok: false, error: e.message }));
  out.textContent = r?.ok ? `Test row written${r.warning ? ` · ${r.warning}` : ''}` : `Write failed: ${r?.error ?? 'unknown'}`;
};
$('#notion-purge').onclick = async () => {
  const out = $('#notion-status'); out.textContent = 'Purging…';
  const r = await chrome.runtime.sendMessage({ type: 'PURGE_FALSE' }).catch((e) => ({ error: e.message }));
  out.textContent = r?.error ? `Purge failed: ${r.error}` : `Purged ${r.events} false thumbnail change${r.events === 1 ? '' : 's'}, archived ${r.archived} Notion row${r.archived === 1 ? '' : 's'}${r.archiveError ? ` · Notion: ${r.archiveError}` : ''}`;
  ({ changeMarks: marks = [] } = await chrome.storage.local.get('changeMarks'));
  render();
};
$('#notion-resync').onclick = async () => {
  const out = $('#notion-status'); out.textContent = 'Re-syncing…';
  const r = await chrome.runtime.sendMessage({ type: 'NOTION_RESYNC' }).catch((e) => ({ error: e.message }));
  if (r?.error) { out.textContent = `Re-sync failed: ${r.error}`; return; }
  await refreshSetupStatus();
};
$('#advanced').ontoggle = () => { if ($('#advanced').open) refreshSetupStatus(); };

// ---- developer: capture mode ----------------------------------------------------------------
async function refreshCaptureStatus() {
  const s = await chrome.runtime.sendMessage({ type: 'CAPTURE_STATUS' }).catch(() => null);
  if (!s || s.error) { $('#capture-status').textContent = ''; return; }
  $('#capture-toggle').checked = !!s.enabled;
  $('#capture-status').textContent = s.count ? `${s.count} capture${s.count === 1 ? '' : 's'}` : '';
  for (const id of ['capture-download', 'capture-copy', 'capture-clear']) $(`#${id}`).disabled = !s.count;
}
async function captureBundle() {
  const { captures = [] } = await chrome.storage.local.get('captures');
  return JSON.stringify({ capturedAt: new Date().toISOString(), captures }, null, 0);
}
$('#capture-toggle').onchange = async (e) => {
  await chrome.runtime.sendMessage({ type: 'CAPTURE_MODE', enabled: e.target.checked });
  await refreshCaptureStatus();
};
$('#capture-download').onclick = async () => {
  const a = document.createElement('a');
  a.href = URL.createObjectURL(new Blob([await captureBundle()], { type: 'application/json' }));
  a.download = `studio-captures-${new Date().toISOString().slice(0, 19).replace(/[:T]/g, '-')}.json`;
  a.click();
  setTimeout(() => URL.revokeObjectURL(a.href), 5000);
};
$('#capture-copy').onclick = async (e) => { await navigator.clipboard.writeText(await captureBundle()); e.target.textContent = 'Copied'; };
$('#capture-clear').onclick = async () => { await chrome.runtime.sendMessage({ type: 'CAPTURE_CLEAR' }); await refreshCaptureStatus(); };
$('#dev').ontoggle = () => { if ($('#dev').open) refreshCaptureStatus(); };

$('#refresh').onclick = refresh;
refresh();
