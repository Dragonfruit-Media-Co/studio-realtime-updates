import { HttpError } from './errors.js';
import { trendOf } from './trend.js';

// Notion REST client for the change log, pure apart from fetch. One page per change event, in the
// "Studio realtime DB" database (columns = SCHEMA below; ensureSchema() creates the missing ones).
//
// API version 2025-09-03: a database is a container of data sources and pages are created under a
// DATA SOURCE id, not the database id. The popup takes the database id from the URL; we resolve its
// first data source once (GET /v1/databases/:id → data_sources[0].id) and cache it. Works with both
// internal-integration tokens (secret_…) and personal access tokens (ntn_…, act as the user — no
// "connect to database" step). The token lives in chrome.storage.local only, never logged.
export const NOTION_API = 'https://api.notion.com/v1';
export const NOTION_VERSION = '2025-09-03';
export const DEFAULT_DATABASE_ID = '3d215859033b80c3bc42ffcd0f98ee56';           // change log
export const DEFAULT_TRACKED_DATABASE_ID = '3d315859033b80839729cd1fd0cb2b64';   // shared "Tracked videos" registry (created 2026-09-06)
const MAX_TEXT = 2000;                                  // Notion's rich_text / title limit per block

export const text = (s) => ({ rich_text: [{ text: { content: String(s).slice(0, MAX_TEXT) } }] });
export const title = (s) => ({ title: [{ text: { content: String(s).slice(0, MAX_TEXT) } }] });
const select = (name) => ({ select: { name } });
export const url = (u) => ({ url: u });
export const date = (ms) => ({ date: { start: new Date(ms).toISOString() } });
export const number = (n) => ({ number: n });
export const checkbox = (b) => ({ checkbox: Boolean(b) });
const TREND = { up: 'Up', flat: 'Flat', down: 'Down' };

// types = the data source's `properties` map (from resolve/ensureSchema), or null when unknown.
// uploads = { old?: fileUploadId, new?: fileUploadId } for a Thumbnail event's before/after images.
// With `types` known, values are shaped to the column's real type (url ↔ files) and columns the
// database lacks are dropped instead of failing the write.
// The video's Studio edit page. Studio ignores Google's `authuser` parameter: it opens under whatever
// account it last used. Switching accounts is done by YouTube's own switcher URL (switchUrl) followed
// by a second navigation — see background.js openVideo.
export const studioEditUrl = (videoId) => `https://studio.youtube.com/video/${videoId}/edit?theme=dark`;
// YouTube's account/brand-channel switcher (the URL its own "Switch account" menu uses). Lands on
// youtube.com signed in as that channel; Studio then follows the switch. Verified 2026-09-06.
export function switchUrl({ pageId, authUser } = {}) {
  const u = new URL('https://www.youtube.com/signin');
  u.searchParams.set('action_handle_signin', 'true');
  u.searchParams.set('app', 'desktop');
  u.searchParams.set('next', '/');
  if (pageId) u.searchParams.set('pageid', String(pageId));
  if (authUser !== undefined && authUser !== null && authUser !== '') u.searchParams.set('authuser', String(authUser));
  return u.toString();
}
const externalFile = (url, name) => ({ type: 'external', name, external: { url } });
const uploadedFile = (id, name) => ({ type: 'file_upload', name, file_upload: { id } });

export function notionPage(e, dataSourceId, { types = null, uploads = {} } = {}) {
  // Name = the video's DFM ID (tracked.js), else the video id — one short key per video.
  // "Video ID" is what renameRows() looks rows up by when the DFM ID changes.
  const p = {
    Name: title(e.dfmId ? String(e.dfmId) : e.videoId),
    Change: select(e.type),
    Channel: text(e.channelLabel ?? e.channelId),
    ...(e.clientInitials ? { Client: text(e.clientInitials) } : {}),
    'Video ID': text(e.videoId),
    'Change key': text(changeKeyOf(e)),
    'Video title': text(e.title ?? ''),
    'Video URL': url(`https://www.youtube.com/watch?v=${e.videoId}`),
    'Studio URL': url(studioEditUrl(e.videoId)),
    ...(e.notionUrl ? { 'DFM batch': url(e.notionUrl) } : {}),
    'Detected at': date(e.detectedAt),
    ...(e.loggedBy ? { 'Logged by': text(e.loggedBy) } : {}),
    'Trend at change': select(TREND[e.trend?.direction] ?? 'None'),
  };
  if (typeof e.views48h === 'number') p['Views 48h at change'] = number(e.views48h);
  if (typeof e.lifetimeViews === 'number') p['Lifetime views at change'] = number(e.lifetimeViews);
  if (typeof e.trend?.pct === 'number') p['Trend % at change'] = number(e.trend.pct);
  if (e.type === 'Title') { p.Before = text(e.old ?? ''); p.After = text(e.new ?? ''); }
  if (e.type === 'Thumbnail') {
    // The image pair carries the change: the captured pictures, falling back to the thumbnail URL as
    // an external file when no capture exists. Before/After text stays empty — Studio's image ids
    // are only meaningful to the detector (changes.js), not to a reader.
    const files = (upload, link, name) => (upload ? [uploadedFile(upload, name)] : link ? [externalFile(link, name)] : []);
    const before = files(uploads.old, e.old, 'before'), after = files(uploads.new, e.new, 'after');
    if (before.length) p['Before image'] = { files: before };
    if (after.length) p['After image'] = { files: after };
  }
  if (e.publishedAt) p['Published at'] = date(e.publishedAt);
  if (e.trackedPageId) p[RELATION_COLUMN] = { relation: [{ id: e.trackedPageId }] };   // → the video's row in the registry

  if (types) {
    for (const name of Object.keys(p)) {
      const t = types[name]?.type ?? null;
      if (t === null) { delete p[name]; continue; }                                   // column missing → skip
      const have = Object.keys(p[name])[0];
      if (have === t) continue;
      if (have === 'url' && t === 'files') p[name] = { files: [externalFile(p[name].url, name)] };
      else if (have === 'files' && t === 'url') { const f = p[name].files.find((x) => x.external); if (f) p[name] = url(f.external.url); else delete p[name]; }
      else if (have === 'rich_text' && t === 'title') p[name] = title(p[name].rich_text[0].text.content);
      else if (have === 'select' && t === 'rich_text') p[name] = text(p[name].select.name);
      else delete p[name];                                                            // incompatible → skip rather than fail
    }
  }
  return { parent: { type: 'data_source_id', data_source_id: dataSourceId }, properties: p };
}

// Notion answers errors with { code, message } — surface that instead of a bare status.
export function describeError(e) {
  if (e instanceof HttpError) {
    try { const j = JSON.parse(e.body); if (j?.message) return `HTTP ${e.status} ${j.code ?? ''}: ${j.message}`.replace('  ', ' '); } catch { /* not JSON */ }
    return `HTTP ${e.status}${e.body ? `: ${String(e.body).slice(0, 200)}` : ''}`;
  }
  return e?.message ?? String(e);
}

export const headers = (token) => ({ 'Authorization': `Bearer ${token}`, 'Notion-Version': NOTION_VERSION, 'Content-Type': 'application/json' });

export async function send(url, init, fetchImpl) {
  const res = await fetchImpl(url, init);
  if (!res.ok) throw new HttpError(res.status, await res.text().catch(() => ''));
  return res.json();
}

// The columns notionPage() writes, in Notion's property-schema format. ensureSchema() adds any that
// the data source lacks, so a fresh database needs nothing but its id. Kept deliberately small:
// one Before/After pair for text (titles) and one for images (thumbnails).
const opt = (name, color) => ({ name, color });
export const SCHEMA = {
  'Change': { select: { options: [opt('Title', 'blue'), opt('Thumbnail', 'purple')] } },
  'Channel': { rich_text: {} },
  'Client': { rich_text: {} },           // ClickUp initials — joins with the Tracked videos database
  'Video ID': { rich_text: {} },
  'Change key': { rich_text: {} },       // `${type}:${videoId}:${new identity}` — dedupe across installs
  'Video title': { rich_text: {} },
  'Video URL': { url: {} },
  'Studio URL': { url: {} },
  'DFM batch': { url: {} },
  'Detected at': { date: {} },
  'Published at': { date: {} },
  'Before': { rich_text: {} },
  'After': { rich_text: {} },
  'Before image': { files: {} },
  'After image': { files: {} },
  'Views 48h at change': { number: { format: 'number' } },
  'Lifetime views at change': { number: { format: 'number' } },
  'Trend at change': { select: { options: [opt('Up', 'green'), opt('Flat', 'gray'), opt('Down', 'red'), opt('None', 'default')] } },
  'Trend % at change': { number: { format: 'number' } },
  'Logged by': { rich_text: {} },        // who logged it: the part before "@" of the Chrome profile e-mail
  // Impact (impact.js): re-scored every 3 h after the change until the next change on the video.
  'Hours after': { number: { format: 'number' } },          // completed hours scored (multiple of 3)
  'Views before': { number: { format: 'number' } },         // same number of hours before the change
  'Views after': { number: { format: 'number' } },
  'Impact %': { number: { format: 'number' } },             // views per hour, after vs before
  'Impact flags': { multi_select: { options: [opt('low volume', 'gray'), opt('partial before', 'yellow'), opt('final', 'green'), opt('not measurable', 'red')] } },
  'Scored at': { date: {} },
};
// The impact columns for one score (PATCH pages/:id body). imp: scoreImpact() output.
export function impactProperties(imp, now = Date.now()) {
  const flags = [];
  if (imp.hours === 0) flags.push('not measurable');
  else { if (imp.weak) flags.push('low volume'); if (imp.partial) flags.push('partial before'); }
  if (imp.final) flags.push('final');
  return {
    'Hours after': number(imp.hours),
    'Views before': number(imp.before ?? null), 'Views after': number(imp.after ?? null), 'Impact %': number(imp.deltaPct ?? null),
    'Impact flags': { multi_select: flags.map((name) => ({ name })) },
    'Scored at': date(now),
  };
}
export async function writeImpact({ token, pageId, imp, now = Date.now(), fetchImpl = fetch }) {
  return send(`${NOTION_API}/pages/${pageId}`, { method: 'PATCH', headers: headers(token), body: JSON.stringify({ properties: impactProperties(imp, now) }) }, fetchImpl);
}
// The score a row already carries (written by whichever install measured it), or null.
export function impactFromRow(pr) {
  const hours = pr['Hours after']?.number;
  if (typeof hours !== 'number') return null;
  const flags = new Set((pr['Impact flags']?.multi_select ?? []).map((o) => o.name));
  const before = pr['Views before']?.number ?? null, after = pr['Views after']?.number ?? null;
  return {
    hours, pending: hours === 0 && !flags.has('final') && !flags.has('not measurable'), hoursSoFar: hours, final: flags.has('final'),
    before, after, beforeHours: hours, afterHours: hours, perHourBefore: hours && before !== null ? before / hours : null, perHourAfter: hours && after !== null ? after / hours : null,
    deltaPct: pr['Impact %']?.number ?? null, partial: flags.has('partial before'), weak: flags.has('low volume'),
    scoredAt: pr['Scored at']?.date?.start ? Date.parse(pr['Scored at'].date.start) : null,
  };
}
// The link between the two databases: each change row relates to its video's row in the Tracked videos
// registry (dual property, so the video page lists its changes). Needs the registry's data source id, so it
// is added to the schema at runtime (background.js ensureRelation).
export const RELATION_COLUMN = 'Video';
export const relationSchema = (trackedDataSourceId) => ({ [RELATION_COLUMN]: { relation: { data_source_id: trackedDataSourceId, type: 'dual_property', dual_property: {} } } });
// Columns earlier versions created and no longer write; listed so the popup can name them for deletion.
export const LEGACY_COLUMNS = ['Old title', 'New title', 'Old thumbnail', 'New thumbnail', 'Old thumbnail ID', 'New thumbnail ID',
  'Old thumbnail image', 'New thumbnail image'];

export async function ensureSchema({ token, dataSourceId, schema = SCHEMA, fetchImpl = fetch }) {
  const ds = await send(`${NOTION_API}/data_sources/${dataSourceId}`, { method: 'GET', headers: headers(token) }, fetchImpl);
  const have = ds.properties ?? {};
  const missing = Object.fromEntries(Object.entries(schema).filter(([name]) => !(name in have)));
  const added = Object.keys(missing);
  let types = have;
  if (added.length) {
    const patched = await send(`${NOTION_API}/data_sources/${dataSourceId}`, { method: 'PATCH', headers: headers(token), body: JSON.stringify({ properties: missing }) }, fetchImpl);
    types = patched.properties ?? { ...have, ...Object.fromEntries(added.map((n) => [n, { type: Object.keys(schema[n])[0] }])) };
  }
  const legacy = LEGACY_COLUMNS.filter((n) => n in have);
  return { added, types, legacy };
}

export const plain = (rich) => (rich ?? []).map((t) => t.plain_text ?? t.text?.content ?? '').join('');

// database id → { title, dataSourceId, dataSourceName }. Also the connection test.
export async function resolveDatabase({ token, databaseId = DEFAULT_DATABASE_ID, fetchImpl = fetch }) {
  const db = await send(`${NOTION_API}/databases/${databaseId}`, { method: 'GET', headers: headers(token) }, fetchImpl);
  const ds = db.data_sources?.[0];
  if (!ds?.id) throw new Error('database has no data source (API version mismatch?)');
  return { ok: true, title: plain(db.title), dataSourceId: ds.id, dataSourceName: ds.name ?? '' };
}
export const testNotion = resolveDatabase;

// Notion File Upload API: create an upload object, send the bytes (multipart), reference it from a
// `files` property. dataUrl = "data:<mime>;base64,…" as stored by thumbs.js. Returns the upload id.
export async function uploadImage({ token, dataUrl, filename, fetchImpl = fetch }) {
  const m = /^data:([^;,]+);base64,(.+)$/.exec(dataUrl ?? '');
  if (!m) throw new Error('not a base64 data URL');
  const [, mime, b64] = m;
  const bytes = Uint8Array.from(atob(b64), (c) => c.charCodeAt(0));
  const created = await send(`${NOTION_API}/file_uploads`, { method: 'POST', headers: headers(token), body: JSON.stringify({ mode: 'single_part', filename, content_type: mime }) }, fetchImpl);
  const form = new FormData();
  form.append('file', new Blob([bytes], { type: mime }), filename);
  // No Content-Type header: the browser sets multipart/form-data with the boundary.
  await send(created.upload_url ?? `${NOTION_API}/file_uploads/${created.id}/send`, { method: 'POST', headers: { 'Authorization': `Bearer ${token}`, 'Notion-Version': NOTION_VERSION }, body: form }, fetchImpl);
  return created.id;
}
const ext = (dataUrl) => (/^data:image\/webp/.test(dataUrl) ? 'webp' : /^data:image\/png/.test(dataUrl) ? 'png' : 'jpg');

// dataSourceId is required; the worker resolves and caches it (see background.js notionConfig).
// types = the data source's properties (cached by the worker) — null means "assume our schema".
// Thumbnail events may carry oldImage/newImage data URLs (thumbs.js); each is uploaded when the
// image column will take it, then attached. An upload failure fails the whole event (see postChangeSafely).
const IMAGE_COL = { old: 'Before image', new: 'After image' };
const takesImage = (types, side) => types === null || types[IMAGE_COL[side]]?.type === 'files';
export async function postChange({ token, dataSourceId, event, types = null, fetchImpl = fetch }) {
  if (!dataSourceId) throw new Error('data source not resolved — run Test connection');
  const uploads = {};
  for (const side of ['old', 'new']) {
    const img = event[`${side}Image`];
    if (img && takesImage(types, side)) uploads[side] = await uploadImage({ token, dataUrl: img, filename: `${event.videoId}-${side === 'old' ? 'before' : 'after'}.${ext(img)}`, fetchImpl });
  }
  const body = notionPage(event, dataSourceId, { types, uploads });
  return send(`${NOTION_API}/pages`, { method: 'POST', headers: headers(token), body: JSON.stringify(body) }, fetchImpl);
}

// Rename every row about one video (matched on the "Video ID" column) — used when the operator gives
// a video a DFM ID, or changes it. Pages through the data source query. Returns the row count.
export async function renameRows({ token, dataSourceId, videoId, name, fetchImpl = fetch }) {
  if (!dataSourceId) throw new Error('data source not resolved — run Test connection');
  const ids = [];
  let cursor;
  do {
    const body = { filter: { property: 'Video ID', rich_text: { equals: videoId } }, page_size: 100, ...(cursor ? { start_cursor: cursor } : {}) };
    const page = await send(`${NOTION_API}/data_sources/${dataSourceId}/query`, { method: 'POST', headers: headers(token), body: JSON.stringify(body) }, fetchImpl);
    for (const r of page.results ?? []) ids.push(r.id);
    cursor = page.has_more ? page.next_cursor : null;
  } while (cursor);
  for (const id of ids) {
    await send(`${NOTION_API}/pages/${id}`, { method: 'PATCH', headers: headers(token), body: JSON.stringify({ properties: { Name: title(name) } }) }, fetchImpl);
  }
  return ids.length;
}

// Every row Notion holds, reduced to what identifies a change: video id, type, detection time.
// Used by Re-sync to find recorded changes whose rows were deleted. Pages through the query.
export async function listRows({ token, dataSourceId, fetchImpl = fetch }) {
  if (!dataSourceId) throw new Error('data source not resolved — run Test connection');
  const rows = [];
  let cursor;
  do {
    const body = { page_size: 100, ...(cursor ? { start_cursor: cursor } : {}) };
    const page = await send(`${NOTION_API}/data_sources/${dataSourceId}/query`, { method: 'POST', headers: headers(token), body: JSON.stringify(body) }, fetchImpl);
    for (const r of page.results ?? []) {
      const pr = r.properties ?? {};
      rows.push({
        id: r.id,
        videoId: plain(pr['Video ID']?.rich_text),
        type: pr.Change?.select?.name ?? null,
        detectedAt: pr['Detected at']?.date?.start ? Date.parse(pr['Detected at'].date.start) : null,
        key: plain(pr['Change key']?.rich_text) || null,
        linked: (pr[RELATION_COLUMN]?.relation?.length ?? 0) > 0,
      });
    }
    cursor = page.has_more ? page.next_cursor : null;
  } while (cursor);
  return rows;
}

// The change itself, independent of who saw it or when: type + video + the NEW identity (title text,
// or image id / version). Two installs detecting the same change minutes apart produce the same key.
export const changeKeyOf = (e) => `${e.type}:${e.videoId}:${e.type === 'Title' ? (e.new ?? '') : (e.newId ?? '')}`;
// One existing row with this key, or null.
export async function findByKey({ token, dataSourceId, key, fetchImpl = fetch }) {
  const body = { page_size: 1, filter: { property: 'Change key', rich_text: { equals: key } } };
  const page = await send(`${NOTION_API}/data_sources/${dataSourceId}/query`, { method: 'POST', headers: headers(token), body: JSON.stringify(body) }, fetchImpl);
  return page.results?.[0]?.id ?? null;
}

// A change is identified by video, type and detection minute (Notion may drop the milliseconds).
export const changeKey = (videoId, type, at) => `${videoId}|${type}|${Math.floor(at / 60_000)}`;
export function missingEvents(history, rows) {
  const byMinute = new Set(rows.filter((r) => r.videoId && r.type && r.detectedAt).map((r) => changeKey(r.videoId, r.type, r.detectedAt)));
  const byKey = new Set(rows.map((r) => r.key).filter(Boolean));
  return (history ?? []).filter((e) => !byKey.has(changeKeyOf(e)) && !byMinute.has(changeKey(e.videoId, e.type, e.detectedAt)));
}

// Rebuild a change event from a hover-card mark (marks predate the history store and carry the
// before/after title and images). Channel and publish date come from the tracked entry. The trend at
// that moment is re-derived from the video's current 48 h series when it still covers the six hours
// before the change (`bars`); the view counts at that moment are unknown and left out.
// tracked = { channelId: { videoId: { id, publishedAt, … } } }, channels = [{ channelId, label, authUser }],
// bars = { videoId: [{ startTime, views }] }
export function eventFromMark(m, { tracked = {}, channels = [], bars = {} } = {}) {
  const channelId = Object.keys(tracked).find((c) => m.videoId in tracked[c]) ?? null;
  const ch = channels.find((c) => c.channelId === channelId);
  const entry = channelId ? tracked[channelId][m.videoId] : null;
  const isTitle = m.type === 'Title';
  return {
    type: m.type, videoId: m.videoId, detectedAt: m.at, dfmId: m.dfmId ?? entry?.id ?? null, notionUrl: entry?.notionUrl ?? null,
    channelId, channelLabel: ch?.label ?? null, authUser: ch?.authUser ?? null,
    title: m.newTitle ?? m.oldTitle ?? entry?.title ?? null, publishedAt: entry?.publishedAt ?? null,
    old: isTitle ? (m.oldTitle ?? null) : null, new: isTitle ? (m.newTitle ?? null) : null,
    oldImage: isTitle ? null : (m.oldImage ?? null), newImage: isTitle ? null : (m.newImage ?? null),
    views48h: null, lifetimeViews: null, trend: trendAt(bars[m.videoId], m.at), restored: true,
  };
}
function trendAt(series, at) {
  if (!series?.length) return { direction: null, pct: null };
  const t = trendOf(series, at);
  return { direction: t.direction, pct: t.pct };
}

// Archive (soft-delete) the rows about one change: same Video ID, Detected at within a minute of `at`.
// Used by the popup's purge of false detections. Returns the number archived.
export async function archiveRows({ token, dataSourceId, videoId, at, fetchImpl = fetch }) {
  if (!dataSourceId) throw new Error('data source not resolved — run Test connection');
  const iso = (ms) => new Date(ms).toISOString();
  const body = { page_size: 100, filter: { and: [
    { property: 'Video ID', rich_text: { equals: videoId } },
    { property: 'Detected at', date: { on_or_after: iso(at - 60_000) } },
    { property: 'Detected at', date: { before: iso(at + 60_000) } },
  ] } };
  const page = await send(`${NOTION_API}/data_sources/${dataSourceId}/query`, { method: 'POST', headers: headers(token), body: JSON.stringify(body) }, fetchImpl);
  let n = 0;
  for (const r of page.results ?? []) { await send(`${NOTION_API}/pages/${r.id}`, { method: 'PATCH', headers: headers(token), body: JSON.stringify({ archived: true }) }, fetchImpl); n++; }
  return n;
}

// postChange with two safety nets, so a change is never lost because of the extras around it:
//   1. a 400 naming a property (a column the database lacks) → create the missing columns, retry;
//   2. a failure on an event carrying images (file-upload API, unsupported type, size…) → log the
//      row WITHOUT the images and report a warning; the event still leaves the queue.
// Anything else throws, and the caller keeps the event queued for the next attempt.
const isSchemaError = (e) => e instanceof HttpError && e.status === 400 && /propert|schema|does not exist|not a property/i.test(e.body ?? '');
export async function postChangeSafely({ token, dataSourceId, event, types = null, fetchImpl = fetch }) {
  let current = types;
  // Another install may have logged this change already (same key) — then there is nothing to write.
  // Only when the database has the column; a lookup failure just falls through to writing.
  if (!current || current['Change key']) {
    try { const existing = await findByKey({ token, dataSourceId, key: changeKeyOf(event), fetchImpl }); if (existing) return { page: { id: existing }, types: current, deduped: true }; }
    catch { /* fall through */ }
  }
  const attempt = (ev) => postChange({ token, dataSourceId, event: ev, types: current, fetchImpl });
  let err;
  try { return { page: await attempt(event), types: current }; } catch (e) { err = e; }
  if (isSchemaError(err)) {
    ({ types: current } = await ensureSchema({ token, dataSourceId, fetchImpl }));   // re-read the real column types
    try { return { page: await attempt(event), types: current, warning: 're-read the database columns' }; } catch (e) { err = e; }
  }
  if (event.oldImage || event.newImage) {
    const { oldImage, newImage, ...bare } = event;
    const page = await attempt(bare);                 // throws → stays queued
    return { page, types: current, warning: `${event.type} row logged without images: ${describeError(err)}` };
  }
  throw err;
}

// A synthetic event for the popup's "Log test row" button — proves the write path end to end.
export function testEvent(now = Date.now()) {
  return { type: 'Title', channelLabel: 'Studio Realtime — connection test', channelId: 'test', videoId: 'dQw4w9WgXcQ', title: 'Connection test (safe to delete)',
    publishedAt: null, old: 'before', new: `after ${now}`, views48h: 0, lifetimeViews: null, trend: { direction: null, pct: null }, detectedAt: now };
}

// Backfill: point existing change rows at their video's registry row. links = [{ id: pageId, trackedPageId }].
export async function linkRows({ token, links, fetchImpl = fetch }) {
  let n = 0;
  for (const l of links) {
    await send(`${NOTION_API}/pages/${l.id}`, { method: 'PATCH', headers: headers(token), body: JSON.stringify({ properties: { [RELATION_COLUMN]: { relation: [{ id: l.trackedPageId }] } } }) }, fetchImpl);
    n++;
  }
  return n;
}

// Block children of a page or block (toggle headings keep their content as children), paginated.
export async function blockChildren({ token, blockId, fetchImpl = fetch }) {
  const out = [];
  let cursor;
  do {
    const q = new URLSearchParams({ page_size: '100', ...(cursor ? { start_cursor: cursor } : {}) });
    const page = await send(`${NOTION_API}/blocks/${blockId}/children?${q}`, { method: 'GET', headers: headers(token) }, fetchImpl);
    out.push(...(page.results ?? []));
    cursor = page.has_more ? page.next_cursor : null;
  } while (cursor);
  return out;
}

// A change-log row → a mark the popup draws (seed + hover card), so changes logged by ANY install show up
// everywhere. Image URLs are Notion's signed file links (about an hour) — refreshed on every pull.
const fileUrl = (files) => { const f = files?.[0]; return f?.file?.url ?? f?.external?.url ?? null; };
export function markFromRow(row) {
  const pr = row?.properties ?? {};
  const type = pr.Change?.select?.name ?? null, videoId = plain(pr['Video ID']?.rich_text), at = pr['Detected at']?.date?.start ? Date.parse(pr['Detected at'].date.start) : null;
  if (!videoId || !at || (type !== 'Title' && type !== 'Thumbnail')) return null;
  const before = plain(pr.Before?.rich_text) || null, after = plain(pr.After?.rich_text) || null, title = plain(pr['Video title']?.rich_text) || null;
  return {
    videoId, type, at, shared: true, pageId: row.id, dfmId: plain(pr.Name?.title) || null, by: plain(pr['Logged by']?.rich_text) || null,
    oldTitle: type === 'Title' ? before : title, newTitle: type === 'Title' ? after : title,
    oldImage: fileUrl(pr['Before image']?.files), newImage: fileUrl(pr['After image']?.files),
    impact: impactFromRow(pr),
  };
}
// Rows detected since `since` (ms), newest first, paged.
export async function listRecentChanges({ token, dataSourceId, since, fetchImpl = fetch }) {
  if (!dataSourceId) throw new Error('data source not resolved — run Test connection');
  const out = [];
  let cursor;
  do {
    const body = { page_size: 100, filter: { property: 'Detected at', date: { on_or_after: new Date(since).toISOString() } }, sorts: [{ property: 'Detected at', direction: 'descending' }], ...(cursor ? { start_cursor: cursor } : {}) };
    const page = await send(`${NOTION_API}/data_sources/${dataSourceId}/query`, { method: 'POST', headers: headers(token), body: JSON.stringify(body) }, fetchImpl);
    for (const r of page.results ?? []) { const m = markFromRow(r); if (m) out.push(m); }
    cursor = page.has_more ? page.next_cursor : null;
  } while (cursor);
  return out;
}
