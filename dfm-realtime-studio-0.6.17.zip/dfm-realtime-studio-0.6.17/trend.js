import { HOUR_MS } from './projection.js';

// Per-video trend, pure. Shared by the popup (chip per row, status line) and the worker (badge).
//
// Verdict: the last 3 COMPLETED hours against the 3 completed hours before them (sums). The hour in
// progress is ignored entirely — it is partial and Studio's realtime data lags. `window` returns the
// six hours judged, oldest first, `recent: true` on the last three, for the tooltip and the band.
export const FLAT_PCT = 10;            // |change| below this is "flat"
export const MIN_HOURLY_VIEWS = 10;    // prior 3 h averaging below this → the % is still shown, flagged `weak` (2 → 6 is "+200%" but
                                       // means little): drawn muted, never counted as "going down" for the badge
export const TREND_HOURS = 3;

// Night: 00:00–04:59 in UTC or in US Eastern (EST/EDT handled by the time zone). Together that is
// 20:00–05:00 Eastern. A drop then is the audience going to bed, so the UI greys it and the badge
// does not count it.
const hourFmt = (timeZone) => new Intl.DateTimeFormat('en-US', { timeZone, hour: 'numeric', hourCycle: 'h23' });
const UTC = hourFmt('UTC'), EASTERN = hourFmt('America/New_York');
const hourIn = (fmt, ms) => Number(fmt.formatToParts(new Date(ms)).find((p) => p.type === 'hour').value) % 24;
export const isNightHour = (ms) => hourIn(UTC, ms) < 5 || hourIn(EASTERN, ms) < 5;

const sum = (bars) => bars.reduce((s, b) => s + b.views, 0);

// bars = [{ startTime, views }] (any order). Returns
// { direction: 'up'|'down'|'flat'|null, pct, recent, prior, window: [...≤6], night, weak }.
export function trendOf(bars, now = Date.now()) {
  const night = isNightHour(now);
  const none = { direction: null, pct: null, recent: null, prior: null, window: [], night, weak: false };
  if (!bars?.length) return none;

  const done = [...bars].filter((b) => now >= b.startTime + HOUR_MS).sort((a, b) => a.startTime - b.startTime);
  if (done.length < 2 * TREND_HOURS) return none;
  const recentBars = done.slice(-TREND_HOURS), priorBars = done.slice(-2 * TREND_HOURS, -TREND_HOURS);
  const window = [
    ...priorBars.map((b) => ({ startTime: b.startTime, views: b.views, recent: false })),
    ...recentBars.map((b) => ({ startTime: b.startTime, views: b.views, recent: true })),
  ];
  const recent = sum(recentBars), prior = sum(priorBars);
  if (prior === 0) return { ...none, recent, prior, window, weak: true };   // nothing to compare against
  const pct = Math.round(((recent - prior) / prior) * 100);
  const direction = Math.abs(pct) < FLAT_PCT ? 'flat' : pct < 0 ? 'down' : 'up';
  return { direction, pct, recent, prior, window, night, weak: prior / TREND_HOURS < MIN_HOURLY_VIEWS };
}

// Grace period: a video whose title or thumbnail was changed in the last GRACE_MS is not counted as
// "going down" — the operator just acted on it; give the change time to land before alarming.
// marks = [{ videoId, at }] (the worker's changeMarks). Returns the most recent change time inside
// the grace window, or null.
export const GRACE_MS = 3 * HOUR_MS;
export function inGrace(marks, videoId, now = Date.now()) {
  let latest = null;
  for (const m of marks ?? []) if (m.videoId === videoId && now - m.at >= 0 && now - m.at < GRACE_MS && (latest === null || m.at > latest)) latest = m.at;
  return latest;
}

// How many tracked long-form videos are going down right now — the badge and the status line.
// tracked = { [channelId]: { [videoId]: … } } (tracked.js); when omitted every listed video counts.
// Videos inside their grace period are skipped. Zero during night hours by design.
// marks may mix change marks and test marks (TestStarted / TestFinished): a test starting or ending is
// treated like a change. experiments = { [videoId]: { state } }: a video under a RUNNING Test & compare
// is never counted — YouTube is rotating its packaging, the trend is the test's, not the video's.
export function countDown(results, { tracked, marks = [], experiments = {}, now = Date.now() } = {}) {
  if (isNightHour(now)) return 0;
  let n = 0;
  for (const r of results ?? []) {
    if (!r.ok) continue;
    const set = tracked ? tracked[r.channelId] ?? {} : null;
    for (const v of r.data.videos ?? []) {
      if (v.isShort || (set && !(v.videoId in set))) continue;
      if (experiments?.[v.videoId]?.state === 'running') continue;
      if (inGrace(marks, v.videoId, now) !== null) continue;
      const t = trendOf(v.bars, now);
      if (t.direction === 'down' && !t.weak) n++;
    }
  }
  return n;
}
