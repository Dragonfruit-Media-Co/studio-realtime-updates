// "Final Packaging" from the batch's Notion ideation page, pure. The page (the ClickUp task's 🧠 Ideation
// Link, registry `notionUrl`) holds, under a toggle heading "Final Packaging", one toggle heading per video
// ("LF 093 - **Title**") with three toggle sub-headings: Thumbnails (image blocks), Titles (paragraph
// group labels ending with ":", bulleted items, "⭐ " prefix = top pick) and Description (paragraphs).
// Fetching lives in notion.js (blockChildren) / background.js; everything here takes block arrays.
import { plain } from './notion.js';

// …/Long-form-Ideation-Batch-23-32d15859033b81e99d16c6685fb5ce05?x → "32d15859033b81e99d16c6685fb5ce05"
export function notionPageIdFromUrl(url) {
  if (!url) return null;
  let path;
  try { const u = new URL(url); path = u.pathname + (u.searchParams.get('p') ? `/${u.searchParams.get('p')}` : ''); } catch { path = String(url); }
  const runs = path.replace(/-/g, '').match(/[0-9a-f]{32,}/gi);           // a slug may glue digits in front ("Batch-23-32d1…")
  return runs ? runs[runs.length - 1].slice(-32).toLowerCase() : null;
}

export const blockText = (b) => plain(b?.[b?.type]?.rich_text ?? []);
// Notion's headings 1–3, plus the newer heading 4 (the API may hand it out as heading_4 or as `unsupported`).
export const headingLevel = (b) => (/^heading_([1-6])$/.exec(b?.type ?? '') ?? [])[1] ?? null;
// A block whose children are worth fetching for the packaging: anything that has some, except pages and
// databases embedded in the page (their content is not this page's). Block types this code does not know
// (`unsupported`, new ones) are included — a heading 4 may come through that way, its content intact.
export const holdsBlocks = (b) => Boolean(b?.has_children) && b?.type !== 'child_page' && b?.type !== 'child_database';

// "LF 091 - …" → 91, "ND LF [093]: …" → 93, "LF093" → 93; null when no episode number.
export function episodeOf(text) {
  const m = /\bLF\s*\[?\s*0*(\d{1,4})\b/i.exec(String(text ?? ''));
  return m ? Number(m[1]) : null;
}

const norm = (s) => String(s ?? '').toLowerCase().replace(/[^a-z0-9]+/g, ' ').trim();

// The heading_2 for this video: by episode number (DFM ID) first, then by title containment.
export function findVideoHeading(headings, { dfmId = null, title = null } = {}) {
  const want = dfmId !== null && dfmId !== undefined && /^\d+$/.test(String(dfmId)) ? Number(dfmId) : null;
  if (want !== null) { const hit = headings.find((h) => episodeOf(blockText(h)) === want); if (hit) return hit; }
  const t = norm(title);
  if (t.length >= 12) {
    const hit = headings.find((h) => { const n = norm(blockText(h).replace(/^.*?-\s*/, '')); return n.length >= 12 && (n.includes(t) || t.includes(n)); });
    if (hit) return hit;
  }
  return null;
}

// Children of the "Titles" heading → [{ text, star, group, rejected }], Notion order kept. Blocks may carry a
// `children` array (the worker attaches nested blocks). Structure seen in the batches:
//   - paragraph labels ending with ":" ("Aspirational:") name the options that follow;
//   - a list item ending with ":" or holding children ("Best title:") names its children;
//   - a toggle or sub-heading ("Accepted", "rejected") is a section: its name prefixes the labels inside
//     ("Accepted · Aspirational"), and a section or label containing "reject" marks its options rejected;
//   - any other block holding children (columns, callouts, a block type the API calls `unsupported`) is
//     walked into too — named after its text when it has some, else transparent.
// "Best…" groups and the ⭐ prefix mark top picks.
export function parseTitles(blocks, group = null, out = [], section = null) {
  const joined = (label) => (section && label ? `${section} · ${label}` : label || section);
  for (const b of blocks ?? []) {
    const text = blockText(b).replace(/\*\*/g, '').trim();   // plain text; markdown bold markers tolerated
    const isList = b.type === 'bulleted_list_item' || b.type === 'numbered_list_item';
    const isSection = b.type === 'toggle' || headingLevel(b) !== null || (!isList && b.type !== 'paragraph' && Boolean(b.children?.length));
    if (isSection) { if (b.children?.length) parseTitles(b.children, joined(null), out, text ? (section ? `${section} · ${text}` : text) : section); continue; }
    if (!text && !(b.children?.length)) continue;
    if (b.type === 'paragraph' && /^\*?\(.*\)\*?$/.test(text)) continue;                    // "(⭐ = top recommended…)" note
    const label = /:\s*$/.test(text) || (isList && b.children?.length);
    if (label && (b.type === 'paragraph' || isList)) {
      const g = joined(text.replace(/:\s*$/, '').trim());
      if (b.children?.length) parseTitles(b.children, g, out, section); else group = g;      // paragraph label: applies to what follows
      continue;
    }
    if (b.type === 'paragraph' || isList) {
      const g = group ?? section;
      const rejected = /reject/i.test(g ?? '');
      const star = !rejected && (/^\s*⭐/.test(text) || /^best\b/i.test((g ?? '').split(' · ').pop()));
      out.push({ text: text.replace(/^\s*⭐\s*/, '').trim(), star, group: g, rejected });
      if (b.children?.length) parseTitles(b.children, g, out, section);
    }
  }
  return out;
}

// Children of the "Thumbnails" heading → [{ url, expiresAt, caption, group }]; images nested in columns
// or list items (attached as `children`) count too. A toggle / heading sub-section ("V1 (Rejected)") names
// the group of the images inside it; images outside any sub-section have group null (the current set).
export function parseThumbnails(blocks, out = [], group = null) {
  for (const b of blocks ?? []) {
    if (b.type === 'image') {
      const img = b.image ?? {};
      const src = (img.type && img[img.type]) || img.file || img.external || null;   // file / external / file_upload…
      const url = src?.url ?? null;
      if (url) out.push({ url, expiresAt: src?.expiry_time ? Date.parse(src.expiry_time) : null, caption: plain(img.caption ?? []) || null, group });
      continue;
    }
    const names = b.type === 'toggle' || headingLevel(b) !== null;
    if (b.children?.length) parseThumbnails(b.children, out, names ? (blockText(b).replace(/\*\*/g, '').trim() || group) : group);
  }
  return out;
}

// Children of the "Description" heading → one text.
export function parseDescription(blocks) {
  return (blocks ?? []).filter((b) => b.type === 'paragraph').map(blockText).map((t) => t.trim()).filter(Boolean).join('\n\n');
}

// Names of the three sub-sections, matched case-insensitively on the heading_3 text.
export const SECTION = { thumbnails: /^thumbnails?$/i, titles: /^titles?$/i, description: /^descriptions?$/i };
export const findSection = (headings, re) => headings.find((h) => headingLevel(h) && re.test(blockText(h).trim())) ?? null;
export const isFinalPackaging = (b) => headingLevel(b) !== null && /^final packaging$/i.test(blockText(b).trim());

// The page's table of contents: every heading in page order, the children the worker attached to toggle
// headings flattened → [{ id, level, text, depth }]. Headings without text are skipped (their children
// still count); non-heading blocks are not descended into.
export function tableOfContents(blocks, depth = 0, out = []) {
  for (const b of blocks ?? []) {
    const level = headingLevel(b);
    if (level === null) continue;
    const text = blockText(b).replace(/\*\*/g, '').trim();
    if (text) out.push({ id: b.id, level: Number(level), text, depth });
    if (b.children?.length) tableOfContents(b.children, depth + 1, out);
  }
  return out;
}
