// Everything captured off the wire on 2026-09-05 (Studio web client 1.20260902.07.02).
// This is the ONLY file to edit when Studio bumps its client. Source: fixtures/get_cards.request.json
// and fixtures/raw/get_cards.headers.txt (gitignored).

// Studio sends this URL relative with no API key — cookies + SAPISIDHASH are the whole auth.
export const ENDPOINT = 'https://studio.youtube.com/youtubei/v1/yta_web/get_cards?alt=json';

export const CLIENT_NAME = '62';                                // X-YouTube-Client-Name (WEB_CREATOR)
export const CLIENT_VERSION = '1.20260902.07.02';               // X-YouTube-Client-Version
export const PAGE_CL = '975280038';                             // X-YouTube-Page-CL
export const PAGE_LABEL = 'youtube.studio.web_20260902_07_RC02'; // X-YouTube-Page-Label

// Index of the Google account within the browser's multi-login session. Captured as 1 — i.e. the
// agency account was the SECOND signed-in account in that profile. If auth fails with 401 after a
// sign-out/sign-in, this is the first thing to check.
export const AUTH_USER = '1';

// Captured role for the channel. The protobuf enum is what serializedDelegationContext carries.
export const DEFAULT_ROLE = { name: 'CREATOR_CHANNEL_ROLE_TYPE_OWNER', enum: 8 };

// How many videos the card returns per-video hourly series for (sparkChartData = HOUR × VIDEO).
// The list is the TOP N BY 48 H VIEWS — not by recency — and Shorts compete for the same slots.
// Which videos get a ROW is decided by list_creator_videos (below); this only decides how many of
// them can carry a series. A listed video outside the top N renders as zero bars, so keep N well
// above RECENT_VIDEOS_LIMIT. Studio asks for 3; 50 and 200 were honoured verbatim on 2026-09-05;
// each extra video costs ~4.5 KB of sideEntities in the response.
export const TOP_VIDEOS_LIMIT = 200;

// Request body minus: enabledExperiments (625 entries) and experimentFlags (722) — 92 KB of the 93 KB
// capture; context.request.eats / sessionInfo.token / clientScreenNonce / clickTracking (per-page
// session nonces). If the gate (plan Task 5) fails with 400, restore those from fixtures/raw first.
// `context.user` and `screenConfig.entity.channelId` are filled per request by innertube.buildRequest().
export const REQUEST_TEMPLATE = {
  screenConfig: {
    entity: { channelId: 'UC_CHANNEL_PLACEHOLDER' },
    timePeriod: { timePeriodType: 'ANALYTICS_TIME_PERIOD_TYPE_FOUR_WEEKS' },
    currency: 'USD',
    timeZoneOffsetSecs: 7200,
  },
  cardConfigs: [
    {
      autoUpdateInterval: 'ANALYTICS_AUTO_UPDATE_INTERVAL_REALTIME',
      latestActivityCardConfig: { tableLimit: TOP_VIDEOS_LIMIT, includeSubsData: true },
      failureMode: 'ANALYTICS_CARD_FAILURE_MODE_HIDE',
    },
  ],
  fetchingType: 'FETCHING_TYPE_BACKGROUND',
  sreDebugId: 'ANALYTICS_TAB_ID_OVERVIEW',
  context: {
    client: {
      clientName: 62,
      clientVersion: CLIENT_VERSION,
      hl: 'en',
      gl: 'FR',
      experimentsToken: '',
      utcOffsetMinutes: 120,
      userInterfaceTheme: 'USER_INTERFACE_THEME_DARK',
      screenWidthPoints: 1280,
      screenHeightPoints: 800,
      screenPixelDensity: 2,
      screenDensityFloat: 2,
    },
    request: { returnLogEntry: true, internalExperimentFlags: [], consistencyTokenJars: [] },
    user: {},
  },
};

// ---- yta_web/get_cards, one video, "since publish" ------------------------------------------------
// Captured 2026-09-10 from a video's Analytics → Overview (the "This video has gotten N views since it was
// published" headline). The key-metric card's EXTERNAL_VIEWS total is Studio's own analytics figure —
// the public counter in list_creator_videos lags it by hours (42,421 vs 43,573 in the capture). Studio
// asks for four metrics and traffic tables; we ask for the views tab only. `screenConfig.entity.videoId`,
// `screenConfig.timePeriod.entity.videoId` and `context.user` are filled by innertube.buildLifetimeRequest().
export const LIFETIME_TEMPLATE = {
  screenConfig: {
    entity: { videoId: 'VIDEO_PLACEHOLDER' },
    timePeriod: { referencePoint: 'TIME_PERIOD_REFERENCE_POINT_SINCE_PUBLISH', timePeriodType: 'ANALYTICS_TIME_PERIOD_TYPE_SINCE_PUBLISH', entity: { videoId: 'VIDEO_PLACEHOLDER' } },
    currency: 'USD',
    timeZoneOffsetSecs: 7200,
  },
  cardConfigs: [
    {
      autoUpdateInterval: 'ANALYTICS_AUTO_UPDATE_INTERVAL_NEVER',
      keyMetricCardConfig: { timePeriod: {}, metricTabConfigs: [{ metric: 'EXTERNAL_VIEWS' }] },
      failureMode: 'ANALYTICS_CARD_FAILURE_MODE_FAIL_PAGE',
    },
  ],
  fetchingType: 'FETCHING_TYPE_BACKGROUND',
  sreDebugId: 'ANALYTICS_TAB_ID_OVERVIEW',
  context: REQUEST_TEMPLATE.context,
};

// ---- creator/list_creator_videos — the channel's upload list, newest first -------------------
// Captured 2026-09-05 from Content → Videos (fixtures/raw/list_creator_videos.request.json). Studio
// filters Shorts, movies and episodes out server-side and orders by display time; we add
// privacyIs PUBLIC because the raw page also lists private drafts (timePublishedSeconds "0").
// The realtime card only knows the top N videos by 48 h views; this list is what decides WHICH
// videos get a row, so a quiet recent upload is never missing. Studio asks for 30 per page.
export const LIST_VIDEOS_ENDPOINT = 'https://studio.youtube.com/youtubei/v1/creator/list_creator_videos?alt=json';
export const RECENT_VIDEOS_LIMIT = 30;

// `filter.and.operands[0].channelIdIs.value` and `context.user` are filled per request by
// innertube.buildListRequest(). The mask is trimmed to what videos.js reads (Studio's own asks for
// ~90 fields and 800 KB of permissions/features per page).
export const LIST_VIDEOS_TEMPLATE = {
  filter: {
    and: {
      operands: [
        { channelIdIs: { value: 'UC_CHANNEL_PLACEHOLDER' } },
        { privacyIs: { value: 'VIDEO_PRIVACY_PUBLIC' } },
        { videoOriginIs: { value: 'VIDEO_ORIGIN_UPLOAD' } },
        { not: { operand: { contentTypeIs: { value: 'CREATOR_CONTENT_TYPE_SHORTS' } } } },
        { not: { operand: { tvfilmTypeIs: { value: 'VIDEO_TVFILM_TYPE_MOVIE' } } } },
        { not: { operand: { tvfilmTypeIs: { value: 'VIDEO_TVFILM_TYPE_EPISODE' } } } },
        { not: { operand: { tvfilmTypeIs: { value: 'VIDEO_TVFILM_TYPE_EVENT' } } } },
      ],
    },
  },
  order: 'VIDEO_ORDER_DISPLAY_TIME_DESC',
  pageSize: RECENT_VIDEOS_LIMIT,
  mask: {
    channelId: true, videoId: true, title: true, privacy: true, status: true, origin: true, contentType: true,
    lengthSeconds: true, timeCreatedSeconds: true, timePublishedSeconds: true, watchUrl: true,
    thumbnailDetails: { all: true }, thumbnailEditorState: { all: true }, publicShorts: { all: true }, publicMetrics: { all: true },
    responseStatus: { all: true },
  },
  context: REQUEST_TEMPLATE.context,
};

// ---- creator/get_creator_videos — "Test & compare" (A/B) state for a batch of videos --------------
// Captured 2026-09-05 from a video's edit page (fixtures/raw/get_creator_videos.experiment.*). Takes a
// LIST of video ids, so one request per channel covers every tracked video. `videoCreatorExperiment`
// carries arms (thumbnails and/or titles), state, start/finish, selected and winner arm.
// `videoIds` and `context.user` are filled per request by innertube.buildExperimentsRequest().
export const GET_VIDEOS_ENDPOINT = 'https://studio.youtube.com/youtubei/v1/creator/get_creator_videos?alt=json';
export const EXPERIMENTS_TEMPLATE = {
  videoIds: [],
  failOnError: false,
  criticalRead: false,
  mask: { videoId: true, title: true, videoCreatorExperiment: { all: true }, responseStatus: { all: true } },
  context: REQUEST_TEMPLATE.context,
};
