// DFM Realtime Studio — "DFM packaging" panel on Studio's video edit page (isolated world, always on).
// Shows the video's Final Packaging from the batch's Notion ideation page: title variations (click = copy),
// thumbnail candidates (click = open full size) and the description (copy). Data comes from the worker
// (PACKAGING_FOR; PACKAGING_TOC lists the page's headings when the lookup fails and the editor picks one
// or more sections by hand); nothing here touches Studio's own fields or writes anywhere.
(() => {
  const EDIT_RE = /^https:\/\/studio\.youtube\.com\/video\/([A-Za-z0-9_-]{11})\/edit/;
  const HOST_ID = 'dfm-packaging-host';
  const SEED = 'M-4.5,0 C-2.5,-1.4 0.5,-3.6 2.4,-3.2 C4.4,-2.8 4.6,1 3,2.6 C1.4,4.2 -1.6,3.6 -3.4,1.6 Z';
  const CSS = `
    :host { all: initial; }
    .card { font: 13px/1.4 system-ui, -apple-system, sans-serif; color: #f1f1f1; background: #0f0f0f; border: 1px solid #303030; border-radius: 10px; padding: 12px 14px; margin: 12px 0 8px; box-sizing: border-box; }
    .rt:not([hidden]) + .card { border-top-left-radius: 0; border-top-right-radius: 0; margin-top: 0; }
    .rt { font: 13px/1.4 system-ui, -apple-system, sans-serif; color: #f1f1f1; box-sizing: border-box; }
    .head { display: flex; align-items: center; gap: 10px; margin-bottom: 8px; }
    .head .seed { width: 14px; height: 14px; flex: 0 0 auto; }
    .head b { font-weight: 600; }
    .head .meta { color: #aaa; font-size: 12px; }
    .head .right { margin-left: auto; display: flex; align-items: center; gap: 10px; flex: 0 0 auto; }
    .head a { color: #3ea6ff; text-decoration: none; font-size: 12px; cursor: pointer; }
    .head a:hover { text-decoration: underline; }
    .head .ib { border: 0; background: none; color: #aaa; cursor: pointer; padding: 0 2px; line-height: 1; }
    .head .ib:hover { color: #fff; }
    .head .close { font-size: 16px; }
    .head .refresh { font-size: 15px; }
    .head .refresh.busy { color: #E94027; animation: spin 0.9s linear infinite; pointer-events: none; }
    @keyframes spin { to { transform: rotate(360deg); } }
    .note { color: #aaa; font-size: 12px; margin-top: 10px; }
    .note a { color: #3ea6ff; cursor: pointer; }
    .note a:hover { text-decoration: underline; }
    .toc { margin-top: 8px; }
    .toc .list { max-height: 320px; overflow: auto; border: 1px solid #303030; border-radius: 6px; padding: 4px 0; }
    .toc .row { border-radius: 0; padding: 4px 8px; font-size: 12px; gap: 6px; }
    .toc .row .lv { color: #666; font-size: 10px; width: 16px; flex: 0 0 auto; }
    .toc .row.deep .t { color: #ccc; }
    .toc .row.match .t { color: #3ea6ff; }
    .toc .row.on .lv { color: #E94027; } .toc .row.on .t { color: #f1f1f1; font-weight: 600; }
    .toc .row.busy .t { color: #E94027; }
    .sec { margin-top: 10px; }
    .sec .lbl { font-size: 10px; letter-spacing: 0.06em; text-transform: uppercase; color: #aaa; margin-bottom: 6px; }
    .group { font-size: 11px; color: #aaa; margin: 8px 0 3px; }
    .row { display: flex; align-items: center; gap: 8px; padding: 5px 8px; border-radius: 6px; cursor: pointer; }
    .row:hover, .row:focus-visible { background: #1f1f1f; outline: none; }
    .row .star { color: #E94027; width: 14px; flex: 0 0 auto; text-align: center; }
    .row.rejected .t { color: #8d8d8d; text-decoration: line-through; }
    .group.rejected { color: #8d8d8d; }
    .row .t { flex: 1; min-width: 0; }
    .row .hint { font-size: 11px; color: #aaa; opacity: 0; }
    .row:hover .hint { opacity: 1; }
    .row.copied .hint { opacity: 1; color: #E94027; }
    .strip { display: grid; grid-template-columns: repeat(auto-fill, minmax(112px, 1fr)); gap: 8px; }
    .strip a { display: block; position: relative; aspect-ratio: 16 / 9; border-radius: 6px; overflow: hidden; background: #1f1f1f; border: 1px solid #303030; }
    .strip a:hover { border-color: #E94027; }
    .strip img { display: block; width: 100%; height: 100%; object-fit: cover; }
    .strip .n { position: absolute; left: 6px; bottom: 4px; font-size: 10px; color: #fff; background: rgba(0,0,0,0.6); padding: 0 5px; border-radius: 3px; }
    .desc { display: flex; gap: 10px; align-items: flex-start; }
    .desc .txt { flex: 1; color: #ccc; font-size: 12px; max-height: 2.8em; overflow: hidden; white-space: pre-line; }
    .desc.open .txt { max-height: none; }
    .btn { border: 1px solid #303030; background: none; color: #f1f1f1; font: inherit; font-size: 12px; border-radius: 999px; padding: 3px 10px; cursor: pointer; }
    .btn:hover { border-color: #E94027; color: #E94027; }
    /* Realtime strip: the popup's row for this video */
    .rt { background: #0f0f0f; border: 1px solid #303030; border-bottom: 0; border-radius: 10px 10px 0 0; padding: 12px 14px 10px; margin: 12px 0 0; display: grid; grid-template-columns: 112px 1fr; column-gap: 12px; align-items: center; padding-bottom: 10px; margin-bottom: 4px; border-bottom: 1px solid #303030; }
    .rt .thumb { width: 112px; height: 63px; border-radius: 4px; overflow: hidden; background: #1f1f1f; }
    .rt .thumb img { width: 100%; height: 100%; object-fit: cover; display: block; }
    .rt .rbody { min-width: 0; }
    .rt .rhead { display: flex; align-items: center; gap: 10px; }
    .rt .rstats .stat { flex-shrink: 0; }
    .rt .rtitle { min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
    .rt .rid { font-weight: 600; white-space: nowrap; }
    .rt .rstats { margin-left: auto; display: flex; gap: 16px; align-items: flex-end; }
    .rt .stat { display: flex; flex-direction: column; align-items: flex-end; line-height: 1.15; min-width: 3.5em; }
    .rt .stat .l { font-size: 9.5px; letter-spacing: 0.05em; text-transform: uppercase; color: #aaa; }
    .rt .stat .v { font-variant-numeric: tabular-nums; font-weight: 600; }
    .rt .stat .v.trend { font-weight: 400; font-size: 12px; color: #aaa; }
    .rt .stat .v.trend.up { color: #1e8e3e; } .rt .stat .v.trend.down { color: #b3261e; } .rt .stat .v.trend.weak { opacity: 0.6; }
    .rt svg { display: block; width: 100%; height: 32px; margin-top: 4px; overflow: visible; }
    .rt rect.bar { fill: #3ea6ff; } .rt rect.bar.night { fill: #1f3d5c; } .rt rect.bar.current { fill: #2a5a86; }
    .rt rect.win { fill: rgba(255,255,255,0.07); } .rt rect.win.up { fill: rgba(30,142,62,0.3); } .rt rect.win.down { fill: rgba(179,38,30,0.28); } .rt rect.win.flat { fill: rgba(62,166,255,0.22); }
    .rt .seed { fill: #E94027; } .rt .seed.Test { fill: #f28c28; } .rt .seed.Test.finished, .rt .seed.Test.stopped, .rt .seed.Test.superseded { fill: #f7c48a; } .rt .seed.Test.gap { filter: drop-shadow(0 0 2px #f28c28) drop-shadow(0 0 1px #f28c28); }
    .rt .rmeta { font-size: 11px; color: #aaa; }
    /* Hover card for a seed: before / after, or the A/B test's variations */
    .pop { position: fixed; z-index: 2147483000; width: 440px; max-width: calc(100vw - 24px); box-sizing: border-box; padding: 10px 12px; border: 1px solid #303030; border-radius: 8px; background: #0f0f0f; color: #f1f1f1; box-shadow: 0 8px 24px rgba(0,0,0,0.5); font: 13px/1.4 system-ui, -apple-system, sans-serif; }
    .pop.Test { width: 560px; }
    .pop .ph { font-size: 12px; color: #aaa; margin-bottom: 8px; } .pop .ph b { color: #f1f1f1; } .pop .pshares { font-size: 11px; color: #aaa; margin-top: 2px; } .pop .pgap { color: #f28c28; font-weight: 600; } .pop .share.lead { color: #f28c28; } .pop .share.trail { color: #aaa; }
    .pop .pimp { margin-top: 4px; color: #f1f1f1; font-variant-numeric: tabular-nums; } .pop .pimp.pos { color: #3ddc84; } .pop .pimp.neg { color: #ff6b6b; } .pop .pimp.muted { color: #aaa; }
    .pop .pg { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; }
    .pop .pc .lab { font-size: 10px; letter-spacing: 0.06em; text-transform: uppercase; color: #aaa; margin-bottom: 4px; }
    .pop img { display: block; width: 100%; aspect-ratio: 16 / 9; object-fit: cover; border-radius: 4px; background: #1f1f1f; border: 2px solid transparent; box-sizing: border-box; }
    .pop img:not([src]) { visibility: hidden; }
    .pop .pt { font-size: 12px; line-height: 1.35; margin-top: 6px; overflow-wrap: anywhere; }
    .pop.Thumbnail img.after { border-color: #E94027; }
    .pop.Title .pt.after { color: #3ea6ff; } .pop.Title .pt.before { text-decoration: line-through; color: #aaa; }
    .pop .share { font-size: 14px; font-weight: 600; font-variant-numeric: tabular-nums; margin-top: 6px; }
    .pop .pc.winner img { border-color: #1e8e3e; } .pop .pc.winner .lab, .pop .pc.winner .share, .pop .pc.winner .pt { color: #1e8e3e; }
    .pop .pc.kept:not(.winner) img { border-color: #3ea6ff; } .pop .pc.kept:not(.winner) .lab { color: #3ea6ff; }
    .rt .colhit { fill: transparent; pointer-events: all; cursor: pointer; }
    .state { color: #aaa; font-size: 12px; }
    .state a { color: #3ea6ff; }
    .skel { height: 12px; border-radius: 4px; background: #1f1f1f; margin: 8px 0; animation: pulse 1.2s ease-in-out infinite; }
    @keyframes pulse { 0%, 100% { opacity: 0.5; } 50% { opacity: 1; } }
  `;

  let current = null;     // videoId the panel shows
  let host = null;
  let pickedHeadings = [];   // headings picked from the page's table of contents (ids, pick order), for this visit only

  const el = (tag, cls, text) => { const e = document.createElement(tag); if (cls) e.className = cls; if (text !== undefined) e.textContent = text; return e; };
  const seedSvg = () => { const s = document.createElementNS('http://www.w3.org/2000/svg', 'svg'); s.setAttribute('viewBox', '-6 -6 12 12'); s.setAttribute('class', 'seed'); const p = document.createElementNS('http://www.w3.org/2000/svg', 'path'); p.setAttribute('d', SEED); p.setAttribute('fill', '#E94027'); p.setAttribute('transform', 'rotate(-90)'); s.append(p); return s; };

  // Where the panel goes: right under the title editor when it exists, else at the top of the metadata editor.
  function anchor() {
    const title = document.querySelector('#title-textarea') ?? document.querySelector('ytcp-social-suggestions-textbox');
    return title?.closest('ytcp-form-input-container, ytcp-video-title, .input-container')
      ?? title
      ?? document.querySelector('ytcp-video-metadata-editor #basics, ytcp-video-metadata-editor');
  }
  const pageTitle = () => document.querySelector('#title-textarea #textbox, ytcp-social-suggestions-textbox #textbox')?.textContent?.trim() ?? null;

  function mount(videoId) {
    unmount();
    const a = anchor();
    if (!a) return false;
    host = el('div'); host.id = HOST_ID;
    const root = host.attachShadow({ mode: 'open' });
    const style = el('style'); style.textContent = CSS;
    const card = el('div', 'card');
    const rt = el('div', 'rt'); rt.hidden = true;
    root.append(style, rt, card);
    a.insertAdjacentElement('afterend', host);
    current = videoId;
    pickedHeadings = [];
    render(card, { loading: true });
    chrome.runtime.sendMessage({ type: 'REALTIME_FOR', videoId }).then((d) => { if (current === videoId && d?.ok) renderRealtime(rt, d); }).catch(() => {});
    load(card, videoId);
    return true;
  }
  function unmount() { host?.remove(); host = null; current = null; pickedHeadings = []; }
  // Ask the worker for the packaging and render the answer (picked headings, when any, stand in for the
  // video's own). The card is redrawn only when the answer arrives, so a refresh keeps what is on screen.
  function load(card, videoId, { force = false } = {}) {
    return chrome.runtime.sendMessage({ type: 'PACKAGING_FOR', videoId, pageTitle: pageTitle(), force, headingIds: pickedHeadings })
      .then((r) => { if (current === videoId) render(card, r ?? { ok: false, reason: 'error', error: 'no answer' }); })
      .catch((e) => { if (current === videoId) render(card, { ok: false, reason: 'error', error: e?.message ?? String(e) }); });
  }

  // Seed hover card (inside the shadow root, fixed-positioned; kept inside the viewport).
  let pop = null;
  const when = (ms) => (ms ? new Date(ms).toLocaleString([], { weekday: 'short', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' }) : '?');
  function showPop(root, m, e, fallbackThumb) {
    if (!pop) { pop = el('div', 'pop'); root.append(pop); }
    pop.className = `pop ${m.type}`; pop.replaceChildren();
    const ph = el('div', 'ph'), pg = el('div', 'pg');
    if (m.type === 'Test' && m.experiment) {
      const x = m.experiment;
      const kind = [x.hasThumbnails ? 'thumbnail' : null, x.hasTitles ? 'title' : null].filter(Boolean).join(' + ') || 'A/B';
      const winner = x.winnerArm !== null && x.winnerArm !== undefined ? x.arms?.[x.winnerArm] : null;
      const STATE = { running: 'running', finished: 'finished', stopped: 'stopped by user', superseded: 'replaced by a new test' };
      const b = el('b', null, `${kind} test ${STATE[x.state] ?? 'finished'}`);
      const ended = x.finishedAt ?? x.endedAt ?? null;
      ph.append(b, document.createTextNode(` · started ${when(x.startedAt)}${ended && x.state !== 'running' ? ` → ${when(ended)}` : ''}${winner ? ` · winner ${winner.label}` : ''} · ${x.arms?.length ?? 0} variations`));
      if (m.gapAlert && m.gap) ph.append(el('span', 'pgap', ` · ${m.gap.gap} pts between ${x.arms?.[m.gap.top]?.label} and ${x.arms?.[m.gap.bottom]?.label}`));
      if (x.sharesAt && (x.arms ?? []).some((a) => a.share !== null && a.share !== undefined)) ph.append(el('div', 'pshares', `watch-time shares as of ${when(x.sharesAt)}`));
      pg.style.gridTemplateColumns = `repeat(${Math.max(2, x.arms?.length ?? 2)}, 1fr)`;
      for (const a of x.arms ?? []) {
        const col = el('div', `pc${a.index === x.winnerArm ? ' winner' : ''}${a.index === x.selectedArm && x.state !== 'running' ? ' kept' : ''}`);
        col.append(el('div', 'lab', `${a.label}${a.index === x.winnerArm ? ' · winner' : a.index === x.selectedArm && x.state !== 'running' ? ' · kept' : ''}`));
        const img = el('img'); img.alt = ''; const src = a.thumbnail ?? fallbackThumb; if (src) img.src = src; col.append(img);
        col.append(el('div', `share${m.gapAlert && m.gap ? (a.index === m.gap.top ? ' lead' : a.index === m.gap.bottom ? ' trail' : '') : ''}`, a.share !== null && a.share !== undefined ? `${a.share}%` : (x.state === 'running' ? '…' : '—')));
        if (a.title) col.append(el('div', 'pt', a.title));
        pg.append(col);
      }
    } else {
      ph.append(el('b', null, m.type === 'Thumbnail' ? 'Thumbnail changed' : 'Title changed'), document.createTextNode(` · ${when(m.at)}${m.by ? ` · by ${m.by}` : ''}`));
      if (m.impactLine) ph.append(el('div', `pimp${m.impact?.deltaPct > 0 ? ' pos' : m.impact?.deltaPct < 0 ? ' neg' : ''}${!m.impact?.hours || m.impact?.weak ? ' muted' : ''}`, m.impactLine));
      for (const [lab, src, txt] of [['Before', m.oldImage ?? fallbackThumb, m.oldTitle], ['After', m.newImage ?? fallbackThumb, m.newTitle]]) {
        const col = el('div', 'pc'); col.append(el('div', 'lab', lab));
        const img = el('img'); img.alt = ''; img.className = lab.toLowerCase(); if (src) img.src = src; col.append(img);
        col.append(el('div', `pt ${lab.toLowerCase()}`, txt ?? ''));
        pg.append(col);
      }
    }
    pop.append(ph, pg); pop.hidden = false; placePop(e);
  }
  function placePop(e) {
    if (!pop || pop.hidden) return;
    const pad = 12, W = window.innerWidth, H = window.innerHeight, w = pop.offsetWidth, h = pop.offsetHeight;
    let x = e.clientX + pad, y = e.clientY + pad;
    if (x + w > W - pad) x = e.clientX - w - pad; x = Math.min(Math.max(pad, x), Math.max(pad, W - w - pad));
    if (y + h > H - pad) y = e.clientY - h - pad; y = Math.min(Math.max(pad, y), Math.max(pad, H - h - pad));
    pop.style.left = `${x}px`; pop.style.top = `${y}px`;
  }
  const hidePop = () => { if (pop) pop.hidden = true; };
  const fmt = new Intl.NumberFormat();
  const HOUR = 3_600_000;
  // The popup's row, compact: thumbnail · title · id · trend / 48 h / total, then 48 bars with the trend
  // window and the change / test seeds above their hour.
  function renderRealtime(rt, d) {
    rt.replaceChildren(); rt.hidden = false;
    const thumb = el('div', 'thumb'); if (d.thumbnail) { const img = el('img'); img.alt = ''; img.src = d.thumbnail; thumb.append(img); }
    const body = el('div', 'rbody');
    const head = el('div', 'rhead');
    head.append(el('span', 'rtitle', d.title ?? d.videoId));
    if (d.label) head.append(el('span', 'rid', d.label));
    const stats = el('div', 'rstats');
    const t = d.trend ?? { direction: null };
    const trendText = t.direction === null ? '·' : t.direction === 'flat' ? '→ flat' : `${t.direction === 'up' ? '↑' : '↓'} ${Math.abs(t.pct)}%`;
    for (const [l, v, cls] of [['trend', trendText, `trend ${t.direction ?? ''}${t.weak ? ' weak' : ''}`], ['48 h', fmt.format(d.views48h ?? 0), ''], ['total', d.lifetimeViews != null ? fmt.format(d.lifetimeViews) : '—', '']]) {
      const st = el('div', 'stat'); st.append(el('span', 'l', l), el('span', `v ${cls}`.trim(), v)); stats.append(st);
    }
    head.append(stats);
    body.append(head);
    // bars
    const bars = d.bars ?? [];
    const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg'); svg.setAttribute('viewBox', '0 0 480 28'); svg.setAttribute('preserveAspectRatio', 'none');
    const n = Math.max(1, bars.length), w = 480 / n, gap = Math.min(2, w * 0.25), H = 28, now = Date.now();
    const max = Math.max(1, ...bars.map((b) => b.views));
    const slotOf = (ms) => bars.findIndex((b) => ms >= b.startTime && ms < b.startTime + HOUR);
    if (t.window?.length) {
      const a = slotOf(t.window[0].startTime), z = slotOf(t.window[t.window.length - 1].startTime);
      if (a !== -1 && z !== -1) { const win = document.createElementNS('http://www.w3.org/2000/svg', 'rect'); win.setAttribute('class', `win ${t.direction ?? ''}`); win.setAttribute('x', (a * w).toFixed(2)); win.setAttribute('y', '0'); win.setAttribute('width', ((z - a + 1) * w).toFixed(2)); win.setAttribute('height', String(H)); svg.append(win); }
    }
    bars.forEach((b, i) => {
      const h = (b.views / max) * (H - 2);
      const r = document.createElementNS('http://www.w3.org/2000/svg', 'rect');
      const current = now >= b.startTime && now < b.startTime + HOUR;
      r.setAttribute('class', `bar${d.night?.[i] ? ' night' : ''}${current ? ' current' : ''}`);
      r.setAttribute('x', (i * w + gap / 2).toFixed(2)); r.setAttribute('y', (H - h).toFixed(2)); r.setAttribute('width', Math.max(0.5, w - gap).toFixed(2)); r.setAttribute('height', h.toFixed(2));
      const title = document.createElementNS('http://www.w3.org/2000/svg', 'title');
      title.textContent = `${new Date(b.startTime).toLocaleString([], { weekday: 'short', hour: '2-digit', minute: '2-digit' })} — ${fmt.format(b.views)} views${current ? ' so far' : ''}`;
      r.append(title); svg.append(r);
    });
    const root = rt.getRootNode();
    // Marks per hour slot; several in one hour (a test stopped and relaunched within the hour) sit side by
    // side, smaller, each hoverable — the hour column opens the latest. Only the latest pre-window test pins left.
    const pinned = (d.marks ?? []).filter((m) => m.type === 'Test' && bars.length && m.at < bars[0].startTime).sort((a, b) => b.at - a.at)[0] ?? null;
    const slots = new Map();
    for (const m of d.marks ?? []) {
      let i = slotOf(m.at); if (i === -1 && m === pinned) i = 0; if (i === -1) continue;
      if (!slots.has(i)) slots.set(i, []); slots.get(i).push(m);
    }
    for (const [i, group] of slots) {
      group.sort((a, b) => a.at - b.at);
      const latest = group[group.length - 1];
      const col = document.createElementNS('http://www.w3.org/2000/svg', 'rect'); col.setAttribute('class', 'colhit'); col.setAttribute('x', (i * w).toFixed(2)); col.setAttribute('y', '0'); col.setAttribute('width', w.toFixed(2)); col.setAttribute('height', String(H));
      col.onmouseenter = (e) => showPop(root, latest, e, d.thumbnail); col.onmousemove = placePop; col.onmouseleave = hidePop; col.onclick = (e) => { e.stopPropagation(); showPop(root, latest, e, d.thumbnail); };
      svg.append(col);
      group.forEach((m, k) => {
        const n = group.length, x = i * w + w / 2 + (k - (n - 1) / 2) * (w / 2);   // half a bar apart, centred on the hour
        const g = document.createElementNS('http://www.w3.org/2000/svg', 'g'); g.setAttribute('transform', `translate(${x.toFixed(2)} 6) rotate(-90) scale(${n > 1 ? 0.6 : 0.8})`); g.style.cursor = 'pointer';
        const pth = document.createElementNS('http://www.w3.org/2000/svg', 'path'); pth.setAttribute('class', `seed ${m.type}${m.state ? ` ${m.state}` : ''}${m.gapAlert ? ' gap' : ''}`); pth.setAttribute('d', SEED);
        g.append(pth);
        g.onmouseenter = (e) => showPop(root, m, e, d.thumbnail); g.onmousemove = placePop; g.onmouseleave = hidePop; g.onclick = (e) => { e.stopPropagation(); showPop(root, m, e, d.thumbnail); };
        svg.append(g);
      });
    }
    body.append(svg);
    if (d.updatedAt) body.append(el('div', 'rmeta', `last 48 hours · views per hour · updated ${Math.max(0, Math.round((Date.now() - d.updatedAt) / 60_000))} min ago`));
    rt.append(thumb, body);
  }
  function header(card, r) {
    const h = el('div', 'head');
    h.append(seedSvg(), el('b', null, 'DFM packaging'));
    if (r?.dfmId) h.append(el('span', 'meta', `LF ${r.dfmId}`));
    if (r?.heading) h.append(el('span', 'meta', `· ${r.heading.replace(/^LF\s*\d+\s*[-–:]\s*/i, '')}${r.picked ? ' (picked)' : ''}`));
    const right = el('div', 'right');
    if (r?.picked) {   // back to the automatic lookup (Final Packaging → LF n → Titles / Thumbnails)
      const a = el('a', 'auto', 'automatic'); a.title = 'Back to the section found by episode number';
      a.onclick = (e) => { e.preventDefault(); pickedHeadings = []; render(card, { loading: true }); load(card, r.videoId); };
      right.append(a);
    }
    const link = r?.pageUrl ?? r?.notionUrl;
    if (link) { const a = el('a', null, 'Notion'); a.href = link; a.target = '_blank'; a.rel = 'noopener'; right.append(a); }
    if (link && !r.loading) {   // re-read from Notion, cache bypassed; the picked section when there is one
      const b = el('button', 'ib refresh', '↻'); b.title = 'Re-read from Notion';
      b.onclick = () => { b.classList.add('busy'); b.disabled = true; load(card, r.videoId ?? current, { force: true }); };
      right.append(b);
    }
    const x = el('button', 'ib close', '×'); x.title = 'Hide for this tab'; x.onclick = () => { sessionStorage.setItem('dfm-packaging-hidden', '1'); unmount(); };
    right.append(x);
    h.append(right);
    card.append(h);
  }
  // The page's headings, in page order, to pick the sections by hand. Clicking a heading adds it to (or
  // removes it from) the picks and the card shows their content merged; picked rows are ticked.
  function picker(card, r) {
    const videoId = r.videoId ?? current;
    const box = el('div', 'toc'); box.append(el('div', 'lbl', 'Sections on this page'));
    const list = el('div', 'list'); box.append(list);
    for (let i = 0; i < 4; i++) { const sk = el('div', 'skel'); sk.style.width = `${40 + i * 12}%`; sk.style.margin = '8px'; list.append(sk); }
    chrome.runtime.sendMessage({ type: 'PACKAGING_TOC', videoId }).then((t) => {
      if (current !== videoId || !box.isConnected) return;
      list.replaceChildren();
      const state = (msg) => { const d = el('div', 'state', msg); d.style.padding = '4px 8px'; list.append(d); };
      if (!t?.ok) { state(`Could not list the page's sections: ${t?.error ?? t?.reason ?? 'unknown'}`); return; }
      if (!t.items?.length) { state('No headings on this page.'); return; }
      for (const it of t.items) {
        const on = pickedHeadings.includes(it.id);
        const row = el('div', `row${it.depth > 0 ? ' deep' : ''}${!r.picked && it.id === r.headingId ? ' match' : ''}${on ? ' on' : ''}`); row.tabIndex = 0;
        row.style.paddingLeft = `${8 + it.depth * 14}px`;
        row.append(el('span', 'lv', on ? '✓' : `H${it.level}`), el('span', 't', it.text), el('span', 'hint', on ? 'remove' : pickedHeadings.length ? 'add' : 'use'));
        const pick = () => {
          row.classList.add('busy');
          pickedHeadings = on ? pickedHeadings.filter((id) => id !== it.id) : [...pickedHeadings, it.id];
          if (!pickedHeadings.length) render(card, { loading: true });   // last pick removed → back to the automatic lookup
          load(card, videoId, { force: true });
        };
        row.onclick = pick; row.onkeydown = (e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); pick(); } };
        list.append(row);
      }
    }).catch((e) => { if (box.isConnected) { list.replaceChildren(el('div', 'state', `Could not list the page's sections: ${e?.message ?? e}`)); } });
    card.append(box);
  }

  function render(card, r) {
    card.replaceChildren();
    header(card, r);
    if (r.loading) { for (let i = 0; i < 3; i++) { const s = el('div', 'skel'); s.style.width = `${60 + i * 12}%`; card.append(s); } return; }
    if (!r.ok) {
      const msg = {
        'not-tracked': 'This video is not followed in DFM Realtime Studio yet — add its channel and, if needed, pick its ClickUp task there.',
        'no-notion-link': 'No Notion link for this video — pick its ClickUp task in DFM Realtime Studio (the task’s 🧠 Ideation Link is used).',
        'no-token': 'Notion token not set in DFM Realtime Studio.',
        'no-final-packaging': 'The ideation page has no “Final Packaging” section.',
        'video-not-in-packaging': `No “LF ${r.dfmId ?? '?'}” under Final Packaging — pick its sections below.`,
        forbidden: 'Not allowed from this page.',
        error: `Could not load: ${r.error ?? 'unknown error'}`,
      }[r.reason] ?? `Could not load (${r.reason ?? 'unknown'}).`;
      const p = el('div', 'state', msg);
      if (r.notionUrl) { p.append(' '); const a = el('a', null, 'Open the page'); a.href = r.notionUrl; a.target = '_blank'; a.rel = 'noopener'; p.append(a); }
      card.append(p);
      if (r.reason === 'no-final-packaging' || r.reason === 'video-not-in-packaging') picker(card, r);
      return;
    }
    // Titles — click copies
    if (r.titles?.length) {
      const sec = el('div', 'sec'); sec.append(el('div', 'lbl', `Titles · ${r.titles.length} · click to copy`));
      let group = undefined;
      for (const t of r.titles) {
        if (t.group !== group) { group = t.group; if (group) sec.append(el('div', `group${t.rejected ? ' rejected' : ''}`, group)); }
        const row = el('div', `row${t.rejected ? ' rejected' : ''}`); row.tabIndex = 0;
        row.append(el('span', 'star', t.star ? '⭐' : ''), el('span', 't', t.text), el('span', 'hint', 'copy'));
        const copy = async () => { try { await navigator.clipboard.writeText(t.text); row.classList.add('copied'); row.querySelector('.hint').textContent = 'copied'; setTimeout(() => { row.classList.remove('copied'); row.querySelector('.hint').textContent = 'copy'; }, 1200); } catch { row.querySelector('.hint').textContent = 'select & copy'; } };
        row.onclick = copy; row.onkeydown = (e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); copy(); } };
        sec.append(row);
      }
      card.append(sec);
    }
    // Thumbnails — click opens full size (signed URLs expire: re-request once when an image fails)
    if (r.thumbnails?.length) {
      const sec = el('div', 'sec'); sec.append(el('div', 'lbl', `Thumbnails · ${r.thumbnails.length} · click to download`));
      const label = `${r.channelInitials ? `${r.channelInitials} ` : ''}LF ${r.dfmId ?? ''}`.trim();
      // Grouped as in Notion: images outside any sub-section first ("current"), then each sub-section (V1, V2…).
      const groups = [];
      for (const t of r.thumbnails) { const g = t.group ?? null; let e = groups.find((x) => x.group === g); if (!e) { e = { group: g, items: [] }; groups.push(e); } e.items.push(t); }
      groups.sort((a, b) => (a.group === null ? -1 : b.group === null ? 1 : 0));
      let n = 0;
      for (const g of groups) {
      if (groups.length > 1 || g.group) sec.append(el('div', 'group', g.group ?? 'current'));
      const strip = el('div', 'strip');
      g.items.forEach((t) => { const i = n++;
        const a = el('a'); a.href = t.url; a.title = t.caption ?? `Thumbnail ${i + 1} — click to download`;
        a.onclick = (e) => {   // the worker downloads it (cross-origin, signed URL) into Downloads/DFM packaging/<video>/
          e.preventDefault();
          const n = a.querySelector('.n'); const was = n.textContent; n.textContent = '…';
          chrome.runtime.sendMessage({ type: 'PACKAGING_DOWNLOAD', url: t.url, label: g.group ? `${label} ${g.group}` : label, index: i + 1 })
            .then((d) => { n.textContent = d?.ok ? '✓' : '!'; if (!d?.ok) a.title = `Download failed: ${d?.error ?? 'unknown'}`; setTimeout(() => { n.textContent = was; }, 1500); })
            .catch(() => { n.textContent = '!'; setTimeout(() => { n.textContent = was; }, 1500); });
        };
        const img = el('img'); img.alt = ''; img.loading = 'lazy'; img.src = t.url;
        img.onerror = () => { if (!card.dataset.refetched) { card.dataset.refetched = '1'; chrome.runtime.sendMessage({ type: 'PACKAGING_FOR', videoId: r.videoId, force: true }).then((n) => { if (n?.ok && current === r.videoId) render(card, n); }).catch(() => {}); } };
        a.append(img, el('span', 'n', String(i + 1)));
        strip.append(a);
      });
      sec.append(strip);
      }
      card.append(sec);
    }
    if (r.description) {
      const sec = el('div', 'sec desc'); sec.append(el('div', 'lbl', 'Description'));
      const row = el('div', 'desc'); const txt = el('div', 'txt', r.description); const b = el('button', 'btn', 'copy');
      b.onclick = async () => { try { await navigator.clipboard.writeText(r.description); b.textContent = 'copied'; setTimeout(() => { b.textContent = 'copy'; }, 1200); } catch { /* ignore */ } };
      txt.onclick = () => row.classList.toggle('open');
      row.append(txt, b); sec.append(row); card.append(sec);
    }
    if (!r.titles?.length && !r.thumbnails?.length && !r.description) card.append(el('div', 'state', r.picked ? 'Nothing to show under this heading.' : 'The Final Packaging section for this video is empty.'));
    // Titles and / or Thumbnails not under the video's heading: offer the page's sections to pick from.
    const gone = (r.missing ?? []).filter((k) => k === 'titles' || k === 'thumbnails');
    if (r.picked || gone.length) {
      const n = r.headingIds?.length ?? 1;
      const note = el('div', 'note', r.picked ? `${n} section${n === 1 ? '' : 's'} picked on the page — ` : `No ${gone.map((k) => k[0].toUpperCase() + k.slice(1)).join(' or ')} section under this video — `);
      const a = el('a', null, r.picked ? 'add or remove sections' : 'pick sections on the page'); let open = false;
      a.onclick = (e) => { e.preventDefault(); if (open) return; open = true; a.textContent += ':'; picker(card, r); };
      note.append(a); card.append(note);
    }
  }

  // Studio is a single-page app: follow the URL, mount when a video edit page is shown, wait for its editor.
  let lastUrl = null, waiting = null;
  const href = () => document.documentElement.dataset.dfmUrl ?? location.href;   // dev/studio-preview.html sets data-dfm-url
  function tick() {
    const url = href();
    if (url === lastUrl) return;
    lastUrl = url;
    const m = EDIT_RE.exec(url);
    if (!m) { unmount(); return; }
    if (sessionStorage.getItem('dfm-packaging-hidden')) return;
    const videoId = m[1];
    if (current === videoId && host?.isConnected) return;
    clearTimeout(waiting);
    const started = Date.now();
    const tryMount = () => { if (EDIT_RE.exec(href())?.[1] !== videoId) return; if (!mount(videoId) && Date.now() - started < 20_000) waiting = setTimeout(tryMount, 500); };
    tryMount();
  }
  setInterval(tick, 500);
  window.addEventListener('yt-navigate-finish', tick);
  tick();
})();
