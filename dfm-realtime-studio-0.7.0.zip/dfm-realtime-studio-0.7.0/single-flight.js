// One run at a time. While `fn` is in flight every caller gets the same promise; once it settles the
// next call starts a fresh run. Used for the worker's fetch: the 15-minute alarm and the popup's
// FETCH_ALL used to overlap, and two runs racing on chrome.storage.local produced duplicate Notion rows
// and dropped change marks. Note: the shared run keeps the FIRST caller's arguments.
export function singleFlight(fn) {
  let inFlight = null;
  return (...args) => {
    if (inFlight) return inFlight;
    inFlight = Promise.resolve().then(() => fn(...args)).finally(() => { inFlight = null; });
    return inFlight;
  };
}
