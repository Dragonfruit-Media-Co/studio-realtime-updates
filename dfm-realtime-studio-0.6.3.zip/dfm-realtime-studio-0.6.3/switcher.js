// YouTube's account switcher (the menu behind the avatar → "Switch account") lists, per signed-in Google
// account, every identity it can act as: the personal channel and each brand-account channel, with the
// brand account's page id — exactly what Studio's delegation needs (innertube.js). Fetching it for each
// account index (?authuser=N) maps every client channel to { authUser, pageId } without opening a tab.
// Pure parsing here; the fetch lives in background.js.
export const SWITCHER_URL = 'https://www.youtube.com/getAccountSwitcherEndpoint';
export const MAX_ACCOUNTS = 4;

const str = (x) => x?.simpleText ?? (Array.isArray(x?.runs) ? x.runs.map((r) => r.text ?? '').join('') : null) ?? (typeof x === 'string' ? x : null);

// Strips the anti-hijacking prefix `)]}'` and parses. Throws on HTML (signed out / consent page).
export function parseSwitcherJson(text) {
  const i = text.indexOf('{');
  if (i === -1 || /^\s*<!doctype html|^\s*<html/i.test(text)) throw new Error('not JSON (signed out or consent page)');
  return JSON.parse(text.slice(i));
}

// Every `accountItem` in the response, grouped by Google account section.
// → [{ email, name, items: [{ name, handle, pageId, selected, thumbnail }] }]
export function parseSwitcher(json) {
  const sections = [];
  walk(json, (o) => {
    if (!o.accountSectionListRenderer) return false;
    const s = o.accountSectionListRenderer;
    const header = s.header?.googleAccountHeaderRenderer ?? {};
    const items = [];
    walk(s.contents, (c) => { if (c.accountItem) { items.push(parseItem(c.accountItem)); return true; } return false; });
    sections.push({ email: str(header.email), name: str(header.name), items });
    return true;
  });
  if (!sections.length) {   // no sections: collect loose items
    const items = [];
    walk(json, (c) => { if (c.accountItem) { items.push(parseItem(c.accountItem)); return true; } return false; });
    if (items.length) sections.push({ email: null, name: null, items });
  }
  return sections;
}

function parseItem(a) {
  let pageId = null;
  const tokens = a.serviceEndpoint?.selectActiveIdentityEndpoint?.supportedTokens ?? [];
  for (const t of tokens) if (t.pageIdToken?.pageId) pageId = String(t.pageIdToken.pageId);
  if (!pageId) { const ds = tokens.find((t) => t.datasyncIdToken)?.datasyncIdToken?.datasyncIdToken; if (ds && ds.includes('||')) { const p = ds.split('||')[1]; if (p) pageId = p; } }
  const thumb = a.accountPhoto?.thumbnails?.at(-1)?.url ?? null;
  return { name: str(a.accountName), handle: normalizeHandle(str(a.channelHandle)), pageId, selected: Boolean(a.isSelected), thumbnail: thumb, byline: str(a.accountByline) };
}

// Depth-first; the visitor returns true to stop descending into that object.
function walk(node, visit, depth = 0) {
  if (!node || typeof node !== 'object' || depth > 40) return;
  if (Array.isArray(node)) { for (const n of node) walk(n, visit, depth + 1); return; }
  if (visit(node)) return;
  for (const v of Object.values(node)) walk(v, visit, depth + 1);
}

// "@Handle", "handle", "https://www.youtube.com/@handle?x" → "handle" (lower-case); null when absent.
export function normalizeHandle(s) {
  if (!s) return null;
  let h = String(s).trim();
  const m = h.match(/youtube\.com\/@([^/?#\s]+)/i);
  if (m) h = m[1];
  h = h.replace(/^@/, '').trim().toLowerCase();
  return h || null;
}

// The identities of account index N = the section holding the selected item (the switcher is fetched
// as that account); with one section, that one. → [{ authUser, name, handle, pageId, email }]
export function identitiesFor(sections, authUser) {
  const own = sections.length === 1 ? sections[0] : sections.find((s) => s.items.some((i) => i.selected));
  if (!own) return [];
  return own.items.map((i) => ({ authUser: String(authUser), name: i.name, handle: i.handle, pageId: i.pageId, email: own.email, thumbnail: i.thumbnail }));
}

// Match client channels (ClickUp: channelUrl is a handle URL) to identities by handle, case-insensitive.
// A personal channel (no page id) links with its account index alone. → [{ channelId, pageId, authUser }]
export function matchIdentities(identities, clients) {
  const byHandle = new Map();
  for (const id of identities) { if (!id.handle) continue; const arr = byHandle.get(id.handle) ?? []; arr.push(id); byHandle.set(id.handle, arr); }
  const links = [];
  for (const c of clients) {
    if (!c.channelId) continue;
    const h = normalizeHandle(c.channelUrl);
    const ids = h ? byHandle.get(h) : null;
    if (!ids?.length) continue;
    // Prefer an identity with a known account index and a page id; one link per channel.
    const best = [...ids].sort((a, b) => (b.authUser !== undefined) - (a.authUser !== undefined) || Boolean(b.pageId) - Boolean(a.pageId))[0];
    links.push({ channelId: c.channelId, authUser: best.authUser, ...(best.pageId ? { pageId: best.pageId } : {}) });
  }
  return links;
}
