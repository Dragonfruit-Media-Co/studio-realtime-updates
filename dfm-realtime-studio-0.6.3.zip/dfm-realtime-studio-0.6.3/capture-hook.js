// Capture mode — MAIN-world content script, registered dynamically at document_start while capture
// mode is on. Records every Studio youtubei call (minus telemetry/attestation) and hands it to the
// isolated-world bridge (capture-bridge.js) via postMessage. Authorization, Cookie and the visitor id
// are redacted BEFORE leaving this function. Nothing here touches chrome.* — MAIN world can't.
(() => {
  if (window.__srHooked) return;
  window.__srHooked = true;

  const SKIP = /\/att\/|log_event|\/feedback|get_web_reauth_url/;
  const isTarget = (u) => /\/youtubei\/v1\//.test(String(u)) && !SKIP.test(String(u));
  const REDACT = new Set(['authorization', 'cookie', 'x-goog-visitor-id']);

  const normHeaders = (h) => {
    const out = {};
    if (!h) return out;
    if (typeof h.forEach === 'function') h.forEach((v, k) => { out[k] = v; });
    else Object.assign(out, h);
    return Object.fromEntries(Object.entries(out).map(([k, v]) => [k, REDACT.has(k.toLowerCase()) ? '[REDACTED]' : v]));
  };
  const asText = async (b) => {
    if (b == null) return null;
    if (typeof b === 'string') return b;
    try { return await new Response(b).text(); } catch { return String(b); }
  };
  const post = async (url, headers, reqBody, respText, status) => {
    const endpoint = String(url).match(/youtubei\/v1\/([^?]+)/)?.[1] ?? 'unknown';
    window.postMessage({
      __sr: 1, endpoint, url: String(url), status, at: Date.now(), page: location.href,
      headers: normHeaders(headers), request: await asText(reqBody), response: respText,
    }, '*');
  };

  // fetch()
  const origFetch = window.fetch;
  window.fetch = async function (input, init) {
    const url = typeof input === 'string' ? input : input?.url ?? '';
    const res = await origFetch.apply(this, arguments);
    if (isTarget(url)) {
      try {
        const headers = init?.headers ?? (typeof input !== 'string' ? input?.headers : undefined);
        const reqBody = init?.body ?? (typeof input !== 'string' ? await input.clone().text() : null);
        post(url, headers, reqBody, await res.clone().text(), res.status);
      } catch (e) { /* never break the page */ }
    }
    return res;
  };

  // XMLHttpRequest (Studio uses both)
  const XHR = window.XMLHttpRequest;
  const origOpen = XHR.prototype.open, origSend = XHR.prototype.send, origSetH = XHR.prototype.setRequestHeader;
  XHR.prototype.open = function (m, u) { this.__srUrl = u; this.__srHdrs = {}; return origOpen.apply(this, arguments); };
  XHR.prototype.setRequestHeader = function (k, v) { (this.__srHdrs ??= {})[k] = v; return origSetH.apply(this, arguments); };
  XHR.prototype.send = function (body) {
    if (isTarget(this.__srUrl)) {
      this.addEventListener('load', () => { try { post(this.__srUrl, this.__srHdrs, body, this.responseText, this.status); } catch { /* ignore */ } });
    }
    return origSend.apply(this, arguments);
  };
})();
