import { NotSignedIn } from './errors.js';

export const ORIGIN = 'https://studio.youtube.com';

// Hash the way Google's web clients do: sha1("<unix seconds> <SAPISID> <origin>"), hex.
export async function sapisidHash(tsSeconds, sapisid, origin) {
  const bytes = new TextEncoder().encode(`${tsSeconds} ${sapisid} ${origin}`);
  const digest = await crypto.subtle.digest('SHA-1', bytes);
  return [...new Uint8Array(digest)].map((b) => b.toString(16).padStart(2, '0')).join('');
}

const VARIANTS = [
  ['SAPISID', 'SAPISIDHASH'],
  ['__Secure-1PAPISID', 'SAPISID1PHASH'],
  ['__Secure-3PAPISID', 'SAPISID3PHASH'],
];

// getCookie(name) → Promise<string|undefined>. Never log the returned header.
// The three cookies normally carry the same value; when the plain SAPISID is missing (some profiles
// only keep the __Secure- variants) the SAPISIDHASH part is computed from the first one present.
export async function getAuthHeader({ getCookie, now = Date.now, origin = ORIGIN }) {
  const ts = Math.floor(now() / 1000);
  const jar = {};
  for (const [cookieName] of VARIANTS) jar[cookieName] = await getCookie(cookieName);
  const found = VARIANTS.map(([c]) => c).filter((c) => jar[c]);
  if (!found.length) throw new NotSignedIn('no youtube.com session cookie (SAPISID) in this Chrome profile');
  const primary = jar.SAPISID ?? jar[found[0]];
  const parts = [`SAPISIDHASH ${ts}_${await sapisidHash(ts, primary, origin)}`];
  for (const [cookieName, scheme] of VARIANTS.slice(1)) if (jar[cookieName]) parts.push(`${scheme} ${ts}_${await sapisidHash(ts, jar[cookieName], origin)}`);
  return parts.join(' ');
}

// The only place chrome.cookies is touched.
export function chromeCookieGetter() {
  return async (name) => (await chrome.cookies.get({ url: `${ORIGIN}/`, name }))?.value;
}
