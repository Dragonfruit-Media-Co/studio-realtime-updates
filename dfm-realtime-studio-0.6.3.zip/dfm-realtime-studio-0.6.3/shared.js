import { NOTION_API, headers, send, text, title, url, date, checkbox, ensureSchema, resolveDatabase } from './notion.js';

// The team's tracked videos, shared through a Notion database ("Tracked videos"). Every install pulls
// it each check and pushes Track / edit / untrack to it, so the whole team sees one list with one set
// of DFM IDs. Pure mapping + thin fetch; the worker caches the pulled map in chrome.storage.local.tracked
// in the same shape tracked.js uses: { [channelId]: { [videoId]: { id, notionUrl, title, publishedAt, thumbnail, addedAt, pageId, client } } }.
export const TRACKED_SCHEMA = {
  'Video ID': { rich_text: {} }, 'Channel ID': { rich_text: {} }, 'Client': { rich_text: {} }, 'Channel': { rich_text: {} },
  'DFM batch': { url: {} }, 'ClickUp task': { url: {} }, 'Video title': { rich_text: {} }, 'Published at': { date: {} }, 'Thumbnail': { url: {} },
  'Active': { checkbox: {} }, 'Added by': { rich_text: {} }, 'Added at': { date: {} },
};
export const ensureTrackedSchema = (o) => ensureSchema({ ...o, schema: TRACKED_SCHEMA });

const plain = (rich) => (rich ?? []).map((t) => t.plain_text ?? t.text?.content ?? '').join('');

// Query result pages → the tracked map (Active rows only).
export function parseTrackedRows(pages) {
  const out = {};
  for (const r of pages ?? []) {
    const p = r.properties ?? {};
    if (p.Active?.checkbox === false) continue;
    const videoId = plain(p['Video ID']?.rich_text), channelId = plain(p['Channel ID']?.rich_text);
    if (!videoId || !channelId) continue;
    (out[channelId] ??= {})[videoId] = {
      id: plain(p.Name?.title) || null, notionUrl: p['DFM batch']?.url ?? null, clickupUrl: p['ClickUp task']?.url ?? null, title: plain(p['Video title']?.rich_text) || null,
      publishedAt: p['Published at']?.date?.start ? Date.parse(p['Published at'].date.start) : null, thumbnail: p.Thumbnail?.url ?? null,
      addedAt: p['Added at']?.date?.start ? Date.parse(p['Added at'].date.start) : null, addedBy: plain(p['Added by']?.rich_text) || null,
      client: plain(p.Client?.rich_text) || null, pageId: r.id,
    };
  }
  return out;
}

async function query({ token, dataSourceId, filter, fetchImpl }) {
  const results = [];
  let cursor;
  do {
    const body = { page_size: 100, ...(filter ? { filter } : {}), ...(cursor ? { start_cursor: cursor } : {}) };
    const page = await send(`${NOTION_API}/data_sources/${dataSourceId}/query`, { method: 'POST', headers: headers(token), body: JSON.stringify(body) }, fetchImpl);
    results.push(...(page.results ?? []));
    cursor = page.has_more ? page.next_cursor : null;
  } while (cursor);
  return results;
}

export async function pullTracked({ token, dataSourceId, fetchImpl = fetch }) {
  if (!dataSourceId) throw new Error('tracked database not resolved — run Test connection');
  return parseTrackedRows(await query({ token, dataSourceId, filter: { property: 'Active', checkbox: { equals: true } }, fetchImpl }));
}

// Properties for one tracked video row. entry = tracked.js entry (+ client initials, channel label).
export function trackedProperties({ channelId, videoId, entry, client = null, channelLabel = null, addedBy = null, active = true }) {
  const p = {
    Name: title(entry.id ?? videoId), 'Video ID': text(videoId), 'Channel ID': text(channelId), Active: checkbox(active),
  };
  if (client) p.Client = text(client);
  if (channelLabel) p.Channel = text(channelLabel);
  if (entry.notionUrl) p['DFM batch'] = url(entry.notionUrl);
  if (entry.clickupUrl) p['ClickUp task'] = url(entry.clickupUrl);
  if (entry.title) p['Video title'] = text(entry.title);
  if (entry.publishedAt) p['Published at'] = date(entry.publishedAt);
  if (entry.thumbnail) p.Thumbnail = url(entry.thumbnail);
  if (addedBy) p['Added by'] = text(addedBy);
  if (entry.addedAt) p['Added at'] = date(entry.addedAt);
  return p;
}

async function findRow({ token, dataSourceId, videoId, fetchImpl }) {
  const rows = await query({ token, dataSourceId, filter: { property: 'Video ID', rich_text: { equals: videoId } }, fetchImpl });
  return rows[0]?.id ?? null;
}

// Create or update the video's row (one row per video; re-tracking reactivates it). Returns the page id.
export async function pushTrack({ token, dataSourceId, channelId, videoId, entry, client, channelLabel, addedBy, fetchImpl = fetch }) {
  if (!dataSourceId) throw new Error('tracked database not resolved — run Test connection');
  const properties = trackedProperties({ channelId, videoId, entry, client, channelLabel, addedBy, active: true });
  const existing = entry.pageId ?? await findRow({ token, dataSourceId, videoId, fetchImpl });
  if (existing) { await send(`${NOTION_API}/pages/${existing}`, { method: 'PATCH', headers: headers(token), body: JSON.stringify({ properties }) }, fetchImpl); return existing; }
  const page = await send(`${NOTION_API}/pages`, { method: 'POST', headers: headers(token), body: JSON.stringify({ parent: { type: 'data_source_id', data_source_id: dataSourceId }, properties }) }, fetchImpl);
  return page.id;
}

// Untrack = Active off (history kept). Returns true when a row was found.
export async function pushUntrack({ token, dataSourceId, videoId, pageId = null, fetchImpl = fetch }) {
  if (!dataSourceId) throw new Error('tracked database not resolved — run Test connection');
  const id = pageId ?? await findRow({ token, dataSourceId, videoId, fetchImpl });
  if (!id) return false;
  await send(`${NOTION_API}/pages/${id}`, { method: 'PATCH', headers: headers(token), body: JSON.stringify({ properties: { Active: checkbox(false) } }) }, fetchImpl);
  return true;
}

// One-click creation of the shared database, as a sibling of the change-log database (same parent page)
// so it lives where the team already looks. Pure body builder + thin fetch.
export const TRACKED_TITLE = 'Tracked videos';
export function trackedDatabaseBody(parentPageId, titleText = TRACKED_TITLE) {
  return {
    parent: { type: 'page_id', page_id: parentPageId },
    title: [{ type: 'text', text: { content: titleText } }],
    icon: { type: 'emoji', emoji: '🎯' },
    initial_data_source: { properties: { Name: { title: {} }, ...TRACKED_SCHEMA } },
  };
}
// → { databaseId, dataSourceId, url }. Throws when the change-log database is not under a page (e.g. workspace root).
export async function createTrackedDatabase({ token, besideDatabaseId, fetchImpl = fetch }) {
  const db = await send(`${NOTION_API}/databases/${besideDatabaseId}`, { method: 'GET', headers: headers(token) }, fetchImpl);
  const parentPageId = db.parent?.page_id;
  if (!parentPageId) throw new Error(`the change-log database's parent is ${db.parent?.type ?? 'unknown'}, not a page — create the database by hand and paste its id`);
  const made = await send(`${NOTION_API}/databases`, { method: 'POST', headers: headers(token), body: JSON.stringify(trackedDatabaseBody(parentPageId)) }, fetchImpl);
  const r = await resolveDatabase({ token, databaseId: made.id, fetchImpl });
  return { databaseId: made.id, dataSourceId: r.dataSourceId, url: made.url ?? null };
}
