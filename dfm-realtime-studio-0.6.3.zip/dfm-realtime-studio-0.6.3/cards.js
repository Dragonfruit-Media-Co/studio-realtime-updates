import { ShapeError } from './errors.js';

// Shape observed in fixtures/get_cards.realtime.json (2026-09-05):
//   cards[].latestActivityCardData.datas[].{timePeriod, mainChartData, topEntitiesData, sparkChartData}
//   mainChartData.dimensionColumns[{dimension.type:"HOUR"}].timestamps.values   → 48 × epoch ms
//   mainChartData.metricColumns[{metric.type:"EXTERNAL_VIEWS"}].counts.values    → 48 × int
//   topEntitiesData.dimensionColumns[0].strings.values → video ids; metricColumns[0].counts.values → views
//   cards[].sideEntities.videos[].entityData.{videoId,title,timePublishedSeconds,thumbnailDetails}
//   latestActivityCardData.lifetimeSubsData.metricColumns[0].counts.values[0]  → subscriber count
// Studio's headline total is the sum of the 48 buckets; there is no separate total field.
// Columns are located by their type tag, not by index, so reordering doesn't break parsing.

const need = (v, path) => { if (v === undefined || v === null) throw new ShapeError(path); return v; };
const toMs = (t) => { const n = Number(typeof t === 'object' && t ? t.seconds : t); return n < 1e12 ? n * 1000 : n; };
const toInt = (v) => Math.round(Number(v));

export function parseRealtime(json) {
  const cards = need(json?.cards, 'cards');
  const card = need(cards.find((c) => c?.latestActivityCardData), 'cards[].latestActivityCardData');
  const lac = card.latestActivityCardData;
  const datas = need(lac.datas, 'latestActivityCardData.datas');
  const data = need(datas.find((d) => /REALTIME_LAST_48/.test(d?.timePeriod ?? '')) ?? datas[0], 'datas[0]');

  const main = need(data.mainChartData, 'datas[].mainChartData');
  const hourCol = need((main.dimensionColumns ?? []).find((c) => c?.dimension?.type === 'HOUR'), 'mainChartData.dimensionColumns[HOUR]');
  const viewCol = need((main.metricColumns ?? []).find((c) => c?.metric?.type === 'EXTERNAL_VIEWS'), 'mainChartData.metricColumns[EXTERNAL_VIEWS]');
  const ts = need(hourCol.timestamps?.values, 'dimensionColumns[HOUR].timestamps.values');
  const ct = need(viewCol.counts?.values, 'metricColumns[EXTERNAL_VIEWS].counts.values');
  if (ts.length !== ct.length || ts.length < 40) throw new ShapeError(`mainChartData length (timestamps=${ts.length}, counts=${ct.length})`);

  const bars = ts.map((t, i) => ({ startTime: toMs(t), views: toInt(ct[i]) })).sort((a, b) => a.startTime - b.startTime);
  const totalViews48h = bars.reduce((s, b) => s + b.views, 0);

  // Top videos — optional: degrade to [] rather than fail the whole card.
  const side = new Map((card.sideEntities?.videos ?? []).map((v) => [v?.entityData?.videoId, v?.entityData ?? {}]));
  const ids = data.topEntitiesData?.dimensionColumns?.[0]?.strings?.values ?? [];
  const tv = data.topEntitiesData?.metricColumns?.[0]?.counts?.values ?? [];
  const topVideos = ids.map((videoId, i) => {
    const e = side.get(videoId) ?? {};
    return {
      videoId,
      title: e.title ?? null,
      views: toInt(tv[i] ?? 0),
      publishedAt: e.timePublishedSeconds ? Number(e.timePublishedSeconds) * 1000 : null,
      thumbnail: e.thumbnailDetails?.thumbnails?.[0]?.url ?? null,
    };
  });

  // Per-video hourly series: sparkChartData is HOUR × VIDEO, one row per (hour, video). Group by
  // video; each gets its own 48 bars. Only videos with views in the window are present.
  const videos = parseVideoSeries(data.sparkChartData, side);

  const subs = lac.lifetimeSubsData?.metricColumns?.[0]?.counts?.values?.[0];
  return { totalViews48h, bars, topVideos, videos, subscribers: subs === undefined ? null : toInt(subs) };
}

function parseVideoSeries(spark, side) {
  if (!spark) return [];
  const hourCol = (spark.dimensionColumns ?? []).find((c) => c?.dimension?.type === 'HOUR');
  const videoCol = (spark.dimensionColumns ?? []).find((c) => c?.dimension?.type === 'VIDEO');
  const viewCol = (spark.metricColumns ?? []).find((c) => c?.metric?.type === 'EXTERNAL_VIEWS');
  const hours = hourCol?.timestamps?.values, ids = videoCol?.strings?.values, counts = viewCol?.counts?.values;
  if (!hours || !ids || !counts) return [];
  if (hours.length !== ids.length || hours.length !== counts.length) throw new ShapeError(`sparkChartData length (hours=${hours.length}, videos=${ids.length}, counts=${counts.length})`);

  const byVideo = new Map();
  ids.forEach((id, i) => {
    if (!byVideo.has(id)) byVideo.set(id, []);
    byVideo.get(id).push({ startTime: toMs(hours[i]), views: toInt(counts[i]) });
  });
  const videos = [...byVideo].map(([videoId, rows]) => {
    const e = side.get(videoId) ?? {};
    const vbars = rows.sort((a, b) => a.startTime - b.startTime);
    return {
      videoId,
      title: e.title ?? null,
      publishedAt: e.timePublishedSeconds ? Number(e.timePublishedSeconds) * 1000 : null,
      thumbnail: e.thumbnailDetails?.thumbnails?.[0]?.url ?? null,
      isShort: e.publicShorts?.isShortsRenderable === true,   // Studio's own flag; no length heuristics
      lengthSeconds: e.lengthSeconds ? Number(e.lengthSeconds) : null,
      views48h: vbars.reduce((s, b) => s + b.views, 0),
      bars: vbars,
    };
  });
  // Newest upload first; unknown publish dates sink to the bottom.
  return videos.sort((a, b) => (b.publishedAt ?? -Infinity) - (a.publishedAt ?? -Infinity));
}
