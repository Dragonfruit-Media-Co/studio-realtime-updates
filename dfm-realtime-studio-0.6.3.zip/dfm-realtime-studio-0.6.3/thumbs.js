import { HttpError } from './errors.js';
import { thumbSignature, thumbParts, thumbChanged } from './changes.js';

// Thumbnail snapshots. YouTube's thumbnail URLs are keyed by video id with a cache-buster, so the
// moment a thumbnail is replaced its old URL serves the NEW image — the "before" picture is gone.
// We therefore keep the bytes of each tracked video's current thumbnail (320 px, ~20 KB) in
// chrome.storage.local.thumbs and, when the signature changes, hand the old and the new image to
// the change event so Notion gets a real before/after. The popup shows the same image per row.
//   thumbs = { [videoId]: { sig, dataUrl, url, at } }
export const CONCURRENCY = 6;

const toBase64 = (buf) => {
  let bin = '';
  for (let i = 0; i < buf.length; i += 0x8000) bin += String.fromCharCode.apply(null, buf.subarray(i, i + 0x8000));
  return btoa(bin);
};
const mimeFromUrl = (url) => (/\.webp(\?|$)/.test(url) ? 'image/webp' : /\.png(\?|$)/.test(url) ? 'image/png' : 'image/jpeg');

export async function fetchThumbnail(url, fetchImpl = fetch) {
  const res = await fetchImpl(url, { credentials: 'omit' });
  if (!res.ok) throw new HttpError(res.status, '');
  const mime = (res.headers.get('content-type') ?? '').split(';')[0].trim() || mimeFromUrl(url);
  const buf = new Uint8Array(await res.arrayBuffer());
  return { dataUrl: `data:${mime};base64,${toBase64(buf)}`, mime, bytes: buf.length };
}

// Bring `thumbs` up to date with the videos in `results` and enrich Thumbnail events in `events`
// with { oldImage, newImage } data URLs. Never throws: a failed fetch leaves that video as it was.
// Returns the new thumbs map (pruned to the videos currently listed, so it cannot grow forever).
export async function snapshotThumbs({ results, events = [], thumbs = {}, fetchImpl = fetch, now = Date.now() }) {
  const listed = [];
  for (const r of results ?? []) if (r.ok) for (const v of r.data.videos ?? []) listed.push(v);
  const next = {};
  const jobs = [];
  for (const v of listed) {
    const sig = thumbSignature(v);
    const prev = thumbs[v.videoId];
    if (!sig || !v.thumbnail) { if (prev) next[v.videoId] = prev; continue; }
    // Re-fetch only on a same-kind change (id vs id, version vs version); a response missing the image
    // id is not a new thumbnail.
    const prevParts = prev ? { id: prev.sig && !prev.sig.startsWith('v:') ? prev.sig : null, ver: prev.sig?.startsWith('v:') ? prev.sig.slice(2) : null } : null;
    if (prev && !thumbChanged(prevParts, thumbParts(v))) { next[v.videoId] = prev; continue; }
    jobs.push(async () => {
      try {
        const { dataUrl } = await fetchThumbnail(v.thumbnail, fetchImpl);
        next[v.videoId] = { sig, dataUrl, url: v.thumbnail, at: now };
        for (const e of events) if (e.type === 'Thumbnail' && e.videoId === v.videoId) { e.oldImage = prev?.dataUrl ?? null; e.newImage = dataUrl; }
      } catch { if (prev) next[v.videoId] = prev; }
    });
  }
  for (let i = 0; i < jobs.length; i += CONCURRENCY) await Promise.all(jobs.slice(i, i + CONCURRENCY).map((j) => j()));
  return next;
}
