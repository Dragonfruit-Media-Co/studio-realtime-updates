// Tracked videos, pure. A channel's rows are the videos the operator chose to track, each with a
// "DFM ID" — Dragonfruit's own id for the video, unique within the channel. The DFM ID is the
// Notion row Name so every row about one video shares one short key.
// Stored in chrome.storage.sync, one item per channel (sync items are capped at 8 KB):
//   "tracked:<channelId>" → { [videoId]: { id, notionUrl, title, publishedAt, thumbnail, addedAt } }
// `notionUrl` = the video's "DFM batch" page in Notion (optional; the row's hover action opens it).
export const KEY_PREFIX = 'tracked:';
export const keyFor = (channelId) => `${KEY_PREFIX}${channelId}`;
export const ID_PATTERN = /^[A-Za-z0-9][A-Za-z0-9._-]{0,31}$/;

// Input text → id string | null (empty) | undefined (not an acceptable id).
export function parseDfmId(text) {
  const t = String(text ?? '').trim();
  if (!t) return null;
  return ID_PATTERN.test(t) ? t : undefined;
}

// The other video on this channel already holding `id` (case-insensitive), or null.
export function conflict(map, videoId, id) {
  const want = id.toLowerCase();
  for (const [vid, t] of Object.entries(map ?? {})) if (vid !== videoId && (t?.id ?? '').toLowerCase() === want) return vid;
  return null;
}

// Start tracking / change the id. meta = { title, publishedAt, thumbnail } (kept so a tracked video
// that drops off the upload list still has a row). Returns { ok: true, map } | { ok: false, conflict }.
export function track(map, videoId, id, meta = {}, now = Date.now()) {
  const c = conflict(map, videoId, id);
  if (c) return { ok: false, conflict: c, map };
  const prev = map?.[videoId];
  const next = { ...(map ?? {}), [videoId]: { ...(prev ?? { addedAt: now }), ...meta, id } };
  return { ok: true, map: next };
}

export function untrack(map, videoId) {
  const next = { ...(map ?? {}) };
  delete next[videoId];
  return next;
}

// { "tracked:UCa": {...}, other keys… } (a storage.sync dump) → { UCa: {...} }
export function trackedFromStorage(all) {
  const out = {};
  for (const [k, v] of Object.entries(all ?? {})) if (k.startsWith(KEY_PREFIX) && k.length > KEY_PREFIX.length && v && typeof v === 'object') out[k.slice(KEY_PREFIX.length)] = v;
  return out;
}

// Tracked videos of a channel, newest first.
export function trackedList(map) {
  return Object.entries(map ?? {}).map(([videoId, t]) => ({ videoId, ...t })).sort((a, b) => (b.publishedAt ?? 0) - (a.publishedAt ?? 0));
}

// What the Notion Name column shows for a video.
export const nameFor = (id, videoId) => (id ? String(id) : videoId);

// Input text → https URL string | null (empty) | undefined (not an acceptable link).
export function parseNotionUrl(text) {
  const t = String(text ?? '').trim();
  if (!t) return null;
  try { const u = new URL(t); return u.protocol === 'https:' ? u.toString() : undefined; } catch { return undefined; }
}
