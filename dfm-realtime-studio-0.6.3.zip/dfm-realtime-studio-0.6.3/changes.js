import { trendOf } from './trend.js';

// Title / thumbnail change detection, pure. Runs in the worker after every fetch (poll or manual).
//
// `known` is the last seen state per video, kept in chrome.storage.local:
//   { [videoId]: { channelId, title, thumb, thumbnail, lastSeen } }
// A video's first sighting only records it — the A/B log wants changes, not baselines. Entries not
// seen for KEEP_DAYS are dropped so the map cannot grow forever.
export const KEEP_DAYS = 30;

// What identifies a thumbnail: Studio's custom-image id when the list gave us one, else the `v=`
// version hash in the thumbnail URL. Null when neither is there (card-only fallback rows).
// The two kinds are NOT comparable with each other: a response that happens to omit the image id
// must not read as "changed" (that once flagged every tracked video in one go). thumbParts() keeps
// them apart; thumbSignature() is the display/cache key.
export function thumbParts(v) {
  const m = /[?&]v=([A-Za-z0-9_-]+)/.exec(v?.thumbnail ?? '');
  return { id: v?.thumbnailId ?? null, ver: m ? m[1] : null };
}
export function thumbSignature(v) {
  const { id, ver } = thumbParts(v);
  return id ?? (ver ? `v:${ver}` : null);
}
// Same-kind comparison only: ids against ids, else versions against versions.
export function thumbChanged(prev, cur) {
  if (cur.id && prev.id) return cur.id !== prev.id;
  if (!cur.id && !prev.id && cur.ver && prev.ver) return cur.ver !== prev.ver;
  return false;
}

// Recent values per video (ids / titles), so a value that comes BACK — an A/B test rotating its arms, or
// an operator reverting — is not logged as a new change. Capped; oldest first.
const HISTORY_MAX = 6;
const remember = (list, value) => (value === null || value === undefined ? list ?? [] : [...(list ?? []).filter((x) => x !== value), value].slice(-HISTORY_MAX));

// results = fetchAll().results. Returns { events, known }.
// event = { type: 'Title'|'Thumbnail', channelId, channelLabel, videoId, title, publishedAt, old, new,
//           oldId?, newId?, views48h, lifetimeViews, trend: { direction, pct }, detectedAt }
export function diffVideos(known, results, now = Date.now()) {
  const next = {};
  for (const [id, k] of Object.entries(known ?? {})) if (now - (k.lastSeen ?? 0) < KEEP_DAYS * 86_400_000) next[id] = k;
  const events = [];

  for (const r of results ?? []) {
    if (!r.ok) continue;
    for (const v of r.data.videos ?? []) {
      const prev = next[v.videoId];
      const cur = thumbParts(v);
      // Known state: `thumb` = image id, `thumbVer` = URL version. Older entries stored a "v:…" fallback in
      // `thumb`; read it as a version.
      const prevParts = prev ? { id: prev.thumb && !prev.thumb.startsWith('v:') ? prev.thumb : null, ver: prev.thumbVer ?? (prev.thumb?.startsWith('v:') ? prev.thumb.slice(2) : null) } : null;
      const t = trendOf(v.bars ?? [], now);
      const base = {
        channelId: r.channelId, channelLabel: r.label, videoId: v.videoId, title: v.title ?? null, publishedAt: v.publishedAt ?? null,
        views48h: v.views48h ?? 0, lifetimeViews: v.lifetimeViews ?? null, trend: { direction: t.direction, pct: t.pct }, detectedAt: now,
      };
      if (prev) {
        const seenTitle = (prev.titles ?? [prev.title]).includes(v.title);
        if (v.title && prev.title && v.title !== prev.title && !seenTitle) events.push({ type: 'Title', ...base, old: prev.title, new: v.title });
        const curKey = cur.id ?? (cur.ver ? `v:${cur.ver}` : null);
        const seenThumb = (prev.thumbs ?? []).includes(curKey);
        if (thumbChanged(prevParts, cur) && !seenThumb) {
          events.push({ type: 'Thumbnail', ...base, old: prev.thumbnail ?? null, new: v.thumbnail ?? null, oldId: prevParts.id ?? `v:${prevParts.ver}`, newId: cur.id ?? `v:${cur.ver}` });
        }
      }
      const seenNow = Boolean(cur.id || cur.ver);
      next[v.videoId] = {
        channelId: r.channelId,
        title: v.title ?? prev?.title ?? null,
        thumb: cur.id ?? prevParts?.id ?? null,
        thumbVer: cur.ver ?? prevParts?.ver ?? null,
        thumbnail: seenNow ? (v.thumbnail ?? prev?.thumbnail ?? null) : (prev?.thumbnail ?? null),
        titles: remember(prev?.titles ?? (prev?.title ? [prev.title] : []), v.title),
        thumbs: remember(prev?.thumbs ?? (prevParts?.id ? [prevParts.id] : prevParts?.ver ? [`v:${prevParts.ver}`] : []), cur.id ?? (cur.ver ? `v:${cur.ver}` : null)),
        lastSeen: now,
      };
    }
  }
  return { events, known: next };
}
