// Accept whatever someone pastes — a bare id, a Studio URL, a youtube.com/channel URL — and return
// the 24-char channel id, or null if there isn't one in there.
const CHANNEL_ID = /UC[A-Za-z0-9_-]{22}/;

export function extractChannelId(text) {
  const m = String(text ?? '').match(CHANNEL_ID);
  return m ? m[0] : null;
}

// ---- @handle → channel id -----------------------------------------------------------------------
// ClickUp stores channels as handle URLs (youtube.com/@name). YouTube's channel page embeds the id;
// read it from the HTML (worker has host permission for www.youtube.com). Pure parse + thin fetch.
const ID = 'UC[A-Za-z0-9_-]{22}';
// Order matters: the page's own identity comes from the canonical link / og:url / browseId. A bare
// "channelId" can belong to a related channel shown on the page, so it is the last resort.
export function channelIdFromHtml(html) {
  const s = String(html ?? '');
  const m = s.match(new RegExp(`<link[^>]*rel="canonical"[^>]*href="https://www\\.youtube\\.com/channel/(${ID})"`))
    ?? s.match(new RegExp(`<link[^>]*href="https://www\\.youtube\\.com/channel/(${ID})"[^>]*rel="canonical"`))
    ?? s.match(new RegExp(`<meta[^>]*property="og:url"[^>]*content="https://www\\.youtube\\.com/channel/(${ID})"`))
    ?? s.match(new RegExp(`"browseId"\\s*:\\s*"(${ID})"`))
    ?? s.match(new RegExp(`<meta[^>]*itemprop="identifier"[^>]*content="(${ID})"`))
    ?? s.match(new RegExp(`"externalId"\\s*:\\s*"(${ID})"`))
    ?? s.match(new RegExp(`"channelId"\\s*:\\s*"(${ID})"`));
  return m ? m[1] : null;
}
// The channel's profile picture from the same page (og:image), for the popup's channel directory.
export function avatarFromHtml(html) {
  const s = String(html ?? '');
  const m = s.match(/<meta[^>]*property="og:image"[^>]*content="(https:\/\/[^"]+)"/) ?? s.match(/"avatar"\s*:\s*\{\s*"thumbnails"\s*:\s*\[\s*\{\s*"url"\s*:\s*"(https:\/\/[^"]+)"/);
  return m ? m[1].replace(/&amp;/g, '&') : null;
}
// url → { channelId, avatar }. A bare id / channel URL still needs the page for the avatar.
export async function resolveChannel(url, fetchImpl = fetch) {
  const direct = extractChannelId(url);
  const u = new URL(direct ? `https://www.youtube.com/channel/${direct}` : url);
  u.searchParams.set('hl', 'en');
  const res = await fetchImpl(u.toString(), { credentials: 'include', redirect: 'follow', headers: { 'Accept-Language': 'en' } });
  if (!res.ok) throw new Error(`YouTube answered HTTP ${res.status} for ${u.pathname}`);
  const html = await res.text();
  const channelId = direct ?? channelIdFromHtml(html);
  if (!channelId) throw new Error(`no channel id found on ${u.pathname} (${html.length} bytes${/consent\.youtube\.com|ucbcb/.test(res.url ?? '') ? ', consent page' : ''})`);
  return { channelId, avatar: avatarFromHtml(html) };
}
export async function resolveHandle(url, fetchImpl = fetch) {
  const direct = extractChannelId(url);
  if (direct) return direct;
  const u = new URL(url);
  u.searchParams.set('hl', 'en');
  // With the profile's cookies: a cookie-less browser request from the EU gets the consent interstitial
  // (no channel markup); the signed-in session has already consented.
  const res = await fetchImpl(u.toString(), { credentials: 'include', redirect: 'follow', headers: { 'Accept-Language': 'en' } });
  if (!res.ok) throw new Error(`YouTube answered HTTP ${res.status} for ${u.pathname}`);
  const html = await res.text();
  const id = channelIdFromHtml(html);
  if (!id) throw new Error(`no channel id found on ${u.pathname} (${html.length} bytes${/consent\.youtube\.com|ucbcb/.test(res.url ?? '') ? ', consent page' : ''})`);
  return id;
}
