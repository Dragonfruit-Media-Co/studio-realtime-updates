import { HttpError } from './errors.js';

// ClickUp "Client Database" list → channels, pure apart from fetch. Fields are addressed by their
// stable ids (the names carry emoji and get renamed). Verified on the live list on 2026-09-06.
// Each teammate uses their own personal API token (ClickUp → Settings → Apps → API Token, "pk_…"),
// stored in chrome.storage.local only.
export const CLICKUP_API = 'https://api.clickup.com/api/v2';
export const DEFAULT_LIST_ID = '901819561698';
export const FIELDS = {
  initials: '3788b143-bdda-4caa-906a-a142ad33f185',      // 👤 Client Initials (short_text)
  channel: '8fd45b80-3f44-45c3-96e1-ae767bacc09a',       // YouTube Channel (short_text, a handle URL)
  channelLegacy: 'cb3ebb66-67fd-4440-ae6f-5d84e486acdf', // ▶️ YouTube Link (Needs Combining) (url)
  pod: '44707c9d-7b38-46da-8854-11267314ee05',           // 👥 Pod (drop_down)
  tier: '8e3a819f-56c7-4e3f-b0e3-c8fa19f83d9a',          // 📈 Tier (drop_down)
};
export const SKIP_STATUSES = new Set(['archived']);

const field = (task, id) => (task?.custom_fields ?? []).find((f) => f?.id === id);
const textOf = (f) => { const v = f?.value; return typeof v === 'string' && v.trim() ? v.trim() : null; };
// Dropdowns carry the option index in `value`; options list their `orderindex`.
const optionOf = (f) => {
  if (!f || f.value === undefined || f.value === null || f.value === '') return null;
  const opts = f.type_config?.options ?? [];
  const o = opts.find((x) => x.orderindex === f.value) ?? opts.find((x) => x.id === f.value) ?? opts[Number(f.value)];
  return o?.name?.trim() ?? null;
};

// tasks = ClickUp task objects. Returns { clients, skipped: { archived, noChannel } }.
export function parseClients(tasks) {
  const clients = [];
  const skipped = { archived: 0, noChannel: 0 };
  for (const t of tasks ?? []) {
    const status = (t?.status?.status ?? '').toLowerCase();
    if (SKIP_STATUSES.has(status)) { skipped.archived++; continue; }
    const channelUrl = textOf(field(t, FIELDS.channel)) ?? textOf(field(t, FIELDS.channelLegacy));
    if (!channelUrl) { skipped.noChannel++; continue; }
    clients.push({
      taskId: t.id, name: (t.name ?? '').trim(), url: t.url ?? null,
      initials: (textOf(field(t, FIELDS.initials)) ?? '').toUpperCase() || null,
      channelUrl, pod: optionOf(field(t, FIELDS.pod)), tier: optionOf(field(t, FIELDS.tier)), status,
    });
  }
  return { clients, skipped };
}

export const clientLabel = (c) => (c.initials ? `${c.initials} · ${c.name}` : c.name);

// Whole list, paged (ClickUp answers 100 tasks per page with `last_page`).
export async function fetchClients({ token, listId = DEFAULT_LIST_ID, fetchImpl = fetch }) {
  if (!token) throw new Error('ClickUp token not set');
  const tasks = [];
  for (let page = 0; page < 50; page++) {
    const res = await fetchImpl(`${CLICKUP_API}/list/${listId}/task?include_closed=true&subtasks=false&page=${page}`, { headers: { Authorization: token } });
    if (!res.ok) throw new HttpError(res.status, await res.text().catch(() => ''));
    const json = await res.json();
    tasks.push(...(json.tasks ?? []));
    if (json.last_page !== false || !(json.tasks ?? []).length) break;
  }
  return { ...parseClients(tasks), total: tasks.length };
}

// ---- Client production lists → video tasks → DFM ID + batch -----------------------------------------
// Every client has one or more "(INITIALS) Name - DFM Task Space" lists under the Client HQ space. A
// long-form video is a task of type VIDEO_TYPE named "ND LF [093]: Title" whose parent is the batch task
// (type BATCH_TYPE, "ND Batch 23"). The DFM ID is the episode number; the batch link is the batch task.
// Published videos carry their YouTube URL in the ▶️ YouTube Link field (LINK_FIELD) — the join key.
export const CLIENT_HQ_SPACE_ID = '38570695';
export const VIDEO_TYPE = 1002, BATCH_TYPE = 1013;
export const LINK_FIELD = FIELDS.channelLegacy;
export const IDEATION_FIELD = '1d4db504-555d-48ea-9460-52efd3d59956';   // 🧠 Ideation Link (url) — the video's Notion page
export const TEAM_ID = '24512108';
export const taskUrl = (id) => `https://app.clickup.com/t/${TEAM_ID}/${id}`;
export const watchUrl = (videoId) => `https://www.youtube.com/watch?v=${videoId}`;

export function videoIdFromUrl(url) {
  if (!url) return null;
  const m = String(url).match(/(?:[?&]v=|youtu\.be\/|\/shorts\/|\/live\/|\/embed\/)([A-Za-z0-9_-]{11})(?![A-Za-z0-9_-])/);
  return m ? m[1] : null;
}

// "ND LF [093]: Title" → { kind: 'LF', dfmId: '093', title: 'Title' }; "ND LF 53 - T" → '053'; "ND 339 - T" → '339'.
// Shorts ("ND SF [641]: …") → kind 'SF'. Workflow subtasks ("ND LF [093]: Edit V4") parse the same way —
// callers keep only tasks of VIDEO_TYPE (or, for older lists, top-level tasks whose title is not a step).
const NAME_RE = /^\s*\[?([A-Za-z0-9]+)\]?\s+(?:(LF|SF)\s*)?\[?(\d{1,4})\]?\s*[:\-–]\s*(.*)$/;
export function parseTaskName(name) {
  const m = String(name ?? '').match(NAME_RE);
  if (!m) return null;
  const n = m[3];
  return { initials: m[1].toUpperCase(), kind: m[2] ? m[2].toUpperCase() : null, dfmId: n.length < 3 ? n.padStart(3, '0') : n, title: m[4].trim() };
}
export const dfmIdFromName = (name) => parseTaskName(name)?.dfmId ?? null;

const BATCH_RE = /^\s*\[?[A-Za-z0-9]+\]?\s+Batch\s*(\d+)\s*$/i;
export const batchLabel = (name) => { const m = String(name ?? '').match(BATCH_RE); return m ? `Batch ${m[1]}` : (name ?? null); };

// videoTasks: tasks of VIDEO_TYPE (with custom_fields). batchTasks: tasks of BATCH_TYPE (may be empty for
// older lists — the parent id is still a valid batch link). → newest first.
export function parseVideoTasks(videoTasks, batchTasks = []) {
  const batches = new Map((batchTasks ?? []).map((b) => [b.id, b]));
  const out = [];
  for (const t of videoTasks ?? []) {
    const p = parseTaskName(t.name);
    if (!p || p.kind === 'SF') continue;
    const type = optionOf(field(t, '9c035e27-85cc-459d-883f-01aeaba66761'));   // ❓ Video Type
    if (type && /^short/i.test(type)) continue;
    const youtubeUrl = textOf(field(t, LINK_FIELD));
    const ideationUrl = textOf(field(t, IDEATION_FIELD));
    const parent = t.parent ?? null;
    const batch = parent ? batches.get(parent) : null;
    out.push({
      taskId: t.id, name: t.name, title: p.title, dfmId: p.dfmId, url: taskUrl(t.id), ideationUrl, status: t.status?.status ?? null,
      created: Number(t.date_created) || 0, listId: t.list?.id ?? null,
      batchId: parent, batchName: batch ? batchLabel(batch.name) : null, batchUrl: parent ? taskUrl(parent) : null,
      youtubeUrl, videoId: videoIdFromUrl(youtubeUrl),
    });
  }
  return out.sort((a, b) => b.created - a.created);
}

// Client HQ hierarchy → the ids of the client's lists. Usually a list named "(INITIALS) Name - DFM Task
// Space" inside a pod folder; some clients have their own folder "(INITIALS) Name - …" holding several
// lists (e.g. "BD Pod Post Pub", "BD - Dragonfruit Task Space") — then every list in that folder counts.
// `folders` = /space/:id/folder response (folders[].lists[]), `lists` = /space/:id/list response (folderless).
const initialsOf = (name) => { const m = String(name ?? '').match(/\(([^)]+)\)/); return m ? m[1].trim().toUpperCase() : null; };
const startsWithInitials = (name, want) => new RegExp(`^[^A-Za-z0-9(]*${want.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}(?![A-Za-z0-9])`, 'i').test(String(name ?? ''));
export function clientListIds(folders, lists, initials) {
  const want = String(initials ?? '').trim().toUpperCase();
  if (!want) return [];
  const ids = [];
  for (const f of folders ?? []) {
    const folderIsClient = initialsOf(f.name) === want;
    for (const l of f.lists ?? []) if (folderIsClient || initialsOf(l.name) === want || startsWithInitials(l.name, want)) ids.push(String(l.id));
  }
  for (const l of lists ?? []) if (initialsOf(l.name) === want || startsWithInitials(l.name, want)) ids.push(String(l.id));
  return [...new Set(ids)];
}

// Title similarity for the picker's suggestion: same normalized title, or one contains the other (≥ 12 chars).
const norm = (s) => String(s ?? '').toLowerCase().replace(/[^a-z0-9]+/g, ' ').trim();
export function suggestTask(videos, title) {
  const t = norm(title);
  if (t.length < 4) return null;
  const exact = videos.find((v) => norm(v.title) === t);
  if (exact) return exact.taskId;
  const near = videos.find((v) => { const n = norm(v.title); return n.length >= 12 && t.length >= 12 && (n.includes(t) || t.includes(n)); });
  return near?.taskId ?? null;
}

async function get(url, token, fetchImpl) {
  const res = await fetchImpl(url, { headers: { Authorization: token } });
  if (!res.ok) throw new HttpError(res.status, await res.text().catch(() => ''));
  return res.json();
}
// → { listIds, seen: { folders, lists } } — the counts make a "no list" result explainable.
export async function fetchClientLists({ token, initials, spaceId = CLIENT_HQ_SPACE_ID, fetchImpl = fetch }) {
  const [f, l] = await Promise.all([get(`${CLICKUP_API}/space/${spaceId}/folder?archived=false`, token, fetchImpl), get(`${CLICKUP_API}/space/${spaceId}/list?archived=false`, token, fetchImpl)]);
  const folders = f.folders ?? [], lists = l.lists ?? [];
  return { listIds: clientListIds(folders, lists, initials), seen: { folders: folders.length, lists: folders.reduce((n, x) => n + (x.lists?.length ?? 0), 0) + lists.length } };
}
// Video tasks (newest first) and batch tasks of the given lists. `maxPages` × 100 videos per list.
export async function fetchVideoTasks({ token, listIds, fetchImpl = fetch, maxPages = 3 }) {
  const videos = [], batches = [];
  for (const listId of listIds) {
    for (let page = 0; page < maxPages; page++) {
      const json = await get(`${CLICKUP_API}/list/${listId}/task?include_closed=true&subtasks=true&order_by=created&reverse=true&custom_items[]=${VIDEO_TYPE}&page=${page}`, token, fetchImpl);
      videos.push(...(json.tasks ?? []));
      if (json.last_page !== false || !(json.tasks ?? []).length) break;
    }
    const b = await get(`${CLICKUP_API}/list/${listId}/task?include_closed=true&subtasks=true&custom_items[]=${BATCH_TYPE}&page=0`, token, fetchImpl);
    batches.push(...(b.tasks ?? []));
  }
  return parseVideoTasks(videos, batches);
}
// Writes the YouTube URL into the video task (POST /task/:id/field/:field). The only ClickUp write.
export async function setTaskField({ token, taskId, fieldId = LINK_FIELD, value, fetchImpl = fetch }) {
  const res = await fetchImpl(`${CLICKUP_API}/task/${taskId}/field/${fieldId}`, { method: 'POST', headers: { Authorization: token, 'Content-Type': 'application/json' }, body: JSON.stringify({ value }) });
  if (!res.ok) throw new HttpError(res.status, await res.text().catch(() => ''));
  return res.json().catch(() => ({}));
}
