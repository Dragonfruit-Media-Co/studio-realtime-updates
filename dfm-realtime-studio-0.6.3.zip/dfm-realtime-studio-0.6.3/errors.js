export class NotSignedIn extends Error {
  // detail: what the cookie lookup found, so the popup can say why (cookies are per Chrome profile).
  constructor(detail = '') { super(detail ? `Not signed in — ${detail}` : 'Not signed in'); this.name = 'NotSignedIn'; this.detail = detail; }
}
export class HttpError extends Error {
  // body: response text, kept so a rejection can be diagnosed from the popup ("Copy raw response").
  constructor(status, body = '') { super(`HTTP ${status}`); this.name = 'HttpError'; this.status = status; this.body = body; }
}
export class ShapeError extends Error {
  constructor(path) {
    super(`Captured shape no longer matches (${path})`); this.name = 'ShapeError'; this.path = path;
  }
}
export function classify(err) {
  if (err instanceof NotSignedIn) return { kind: 'not_signed_in', message: err.message };
  if (err instanceof HttpError) return { kind: 'http', status: err.status, message: err.message };
  if (err instanceof ShapeError) return { kind: 'shape', path: err.path, message: err.message };
  return { kind: 'network', message: err?.message ?? String(err) };
}
