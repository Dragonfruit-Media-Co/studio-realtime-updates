import { HttpError } from './errors.js';
import { ENDPOINT, LIST_VIDEOS_ENDPOINT, CLIENT_NAME, CLIENT_VERSION, PAGE_CL, PAGE_LABEL, AUTH_USER, DEFAULT_ROLE, REQUEST_TEMPLATE, LIST_VIDEOS_TEMPLATE, EXPERIMENTS_TEMPLATE, GET_VIDEOS_ENDPOINT } from './constants.js';
import { ORIGIN } from './auth.js';

// Studio's serializedDelegationContext is a 30-byte protobuf:
//   field 2 (string)  = channel id
//   field 5 (message) = { field 1 (varint) = role enum }
// Decoded from the capture; rebuilt here so any channel id can be addressed without a Studio tab.
export function delegationToken(channelId, roleEnum = DEFAULT_ROLE.enum) {
  const id = [...new TextEncoder().encode(channelId)];
  if (id.length > 127) throw new RangeError('channel id too long for single-byte length prefix');
  const bytes = [0x12, id.length, ...id, 0x2a, 0x02, 0x08, roleEnum];
  return btoa(String.fromCharCode(...bytes));
}

// Everything that addresses a channel, shared by every Studio call. Pure.
// channel = { channelId, pageId?, authUser?, role? }
//   pageId   — brand-account user id Studio sends as onBehalfOfUser / X-Goog-PageId. Required for
//              brand-account channels (403 PERMISSION_DENIED without).
//   authUser — index of the Google account in the browser's multi-login session (ytcfg SESSION_INDEX,
//              sent as X-Goog-AuthUser). SAPISID is shared across signed-in accounts; this picks one.
//              Wrong index → 401 UNAUTHENTICATED. Falls back to the captured AUTH_USER.
function addressing({ channel, authHeader }) {
  const { channelId, pageId, authUser = AUTH_USER, role = DEFAULT_ROLE } = channel;
  const token = delegationToken(channelId, role.enum);
  const user = {
    ...(pageId ? { onBehalfOfUser: pageId } : {}),
    delegationContext: { externalChannelId: channelId, roleType: { channelRoleType: role.name } },
    serializedDelegationContext: token,
  };
  const headers = {
    'Content-Type': 'application/json',
    'Authorization': authHeader,
    'X-Origin': ORIGIN,
    'X-Goog-AuthUser': String(authUser),
    'X-YouTube-Client-Name': CLIENT_NAME,
    'X-YouTube-Client-Version': CLIENT_VERSION,
    'X-YouTube-Page-CL': PAGE_CL,
    'X-YouTube-Page-Label': PAGE_LABEL,
    'X-YouTube-Delegation-Context': token,
  };
  if (pageId) headers['X-Goog-PageId'] = pageId;
  return { channelId, user, headers };
}

const post = (url, headers, body) => ({ url, init: { method: 'POST', credentials: 'include', headers, body: JSON.stringify(body) } });

// yta_web/get_cards — the realtime card. template + channel + auth → { url, init }. Nothing here
// touches chrome.* or fetch.
export function buildRequest({ channel, authHeader }) {
  const { channelId, user, headers } = addressing({ channel, authHeader });
  const body = structuredClone(REQUEST_TEMPLATE);
  body.screenConfig.entity.channelId = channelId;
  body.context.user = user;
  return post(ENDPOINT, headers, body);
}

// creator/list_creator_videos — the channel's public long-form uploads, newest first.
export function buildListRequest({ channel, authHeader }) {
  const { channelId, user, headers } = addressing({ channel, authHeader });
  const body = structuredClone(LIST_VIDEOS_TEMPLATE);
  body.filter.and.operands[0].channelIdIs.value = channelId;
  body.context.user = user;
  return post(LIST_VIDEOS_ENDPOINT, headers, body);
}

// creator/get_creator_videos — Test & compare state for a batch of the channel's videos.
export function buildExperimentsRequest({ channel, videoIds, authHeader }) {
  const { user, headers } = addressing({ channel, authHeader });
  const body = structuredClone(EXPERIMENTS_TEMPLATE);
  body.videoIds = [...videoIds];
  body.context.user = user;
  return post(GET_VIDEOS_ENDPOINT, headers, body);
}

async function send({ url, init }, fetchImpl) {
  const res = await fetchImpl(url, init);
  if (!res.ok) throw new HttpError(res.status, await res.text().catch(() => ''));
  return res.json();
}

export function getCards({ channel, authHeader, fetchImpl = fetch }) {
  return send(buildRequest({ channel, authHeader }), fetchImpl);
}

export function listVideos({ channel, authHeader, fetchImpl = fetch }) {
  return send(buildListRequest({ channel, authHeader }), fetchImpl);
}

export function getExperiments({ channel, videoIds, authHeader, fetchImpl = fetch }) {
  return send(buildExperimentsRequest({ channel, videoIds, authHeader }), fetchImpl);
}
