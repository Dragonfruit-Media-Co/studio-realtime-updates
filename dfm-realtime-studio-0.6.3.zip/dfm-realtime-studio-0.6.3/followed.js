// Per-person following, pure. Every channel is on "auto": its latest AUTO_LIMIT long-form uploads with at
// least AUTO_MIN_VIEWS views in the last 48 h (a live filter, not a decision — computed from each fetch), minus the videos this person excluded (× on a row; the picker
// restores them). Excludes live in storage.sync ("exclude:<channelId>"), per install, never shared.
// The DFM ID and links are TEAM data in the shared Notion registry (shared.js); this module only says
// which video ids are followed.
export const AUTO_LIMIT = 10;
export const AUTO_MIN_VIEWS = 50;   // fewer views in 48 h → nothing to watch there. Re-evaluated on every check, so a video
                                    // that spikes back above it reappears by itself (nothing is remembered about it).
export const excludeKey = (channelId) => `exclude:${channelId}`;

// videos = the channel's upload list (newest first, Shorts flagged) as joined by videos.js.
export function followedIds({ videos = [], excludes = [] }) {
  const ex = new Set(excludes);
  return videos.filter((v) => !v.isShort && !ex.has(v.videoId) && (v.views48h ?? 0) >= AUTO_MIN_VIEWS).slice(0, AUTO_LIMIT).map((v) => v.videoId);
}

// storage.sync dump → { excludes: { [channelId]: [videoId] } }
export function perUserFromStorage(all) {
  const excludes = {};
  for (const [k, v] of Object.entries(all ?? {})) if (k.startsWith('exclude:') && Array.isArray(v)) excludes[k.slice(8)] = v;
  return { excludes };
}

// Rows for one channel: followed ids joined with the live list (title, series) and the shared registry
// (DFM ID, links).
export function rowsFor({ videos = [], excludes = [], registry = {}, bars = [] }) {
  const live = new Map(videos.map((v) => [v.videoId, v]));
  const zero = () => bars.map((b) => ({ startTime: b.startTime, views: 0 }));
  return followedIds({ videos, excludes }).map((videoId) => {
    const v = live.get(videoId), r = registry[videoId] ?? {};
    return {
      videoId, title: v?.title ?? r.title ?? null, publishedAt: v?.publishedAt ?? r.publishedAt ?? null, thumbnail: v?.thumbnail ?? r.thumbnail ?? null,
      inRealtime: Boolean(v?.inRealtime), views48h: v?.views48h ?? 0, lifetimeViews: v?.lifetimeViews ?? null, bars: v?.bars ?? zero(), isShort: Boolean(v?.isShort),
      dfmId: r.id ?? null, notionUrl: r.notionUrl ?? null,
    };
  }).sort((a, b) => (b.publishedAt ?? 0) - (a.publishedAt ?? 0));
}
