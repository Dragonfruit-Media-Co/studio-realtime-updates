// The last realtime bucket is the hour in progress. Studio draws it muted; we also project where it
// will land by the end of the hour with a straight rate extrapolation: views ÷ fraction elapsed.
export const HOUR_MS = 3_600_000;
export const MIN_ELAPSED_MS = 5 * 60_000;   // below this the extrapolation is noise — show the count only

// bar = { startTime (epoch ms), views }. Returns null unless `now` falls inside that bar's hour.
export function projectHour(bar, now = Date.now()) {
  const elapsed = now - bar.startTime;
  if (elapsed < 0 || elapsed >= HOUR_MS) return null;
  const fraction = elapsed / HOUR_MS;
  return {
    fraction,
    elapsedMinutes: Math.floor(elapsed / 60_000),
    current: bar.views,
    projected: elapsed >= MIN_ELAPSED_MS ? Math.round(bar.views / fraction) : null,
  };
}
