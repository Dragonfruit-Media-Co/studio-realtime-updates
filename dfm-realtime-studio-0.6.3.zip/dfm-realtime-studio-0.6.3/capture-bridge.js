// Capture mode — ISOLATED-world content script. Receives redacted exchanges from capture-hook.js
// (MAIN world) via postMessage and appends them to chrome.storage.local.captures. Keeps the latest
// exchange per (endpoint, page) and bounds total size so storage can't fill up.
const MAX_BYTES = 6_000_000;
let queue = Promise.resolve();

window.addEventListener('message', (e) => {
  if (e.source !== window || e.data?.__sr !== 1) return;
  const c = { ...e.data }; delete c.__sr;
  queue = queue.then(async () => {
    const { captures = [] } = await chrome.storage.local.get('captures');
    const next = captures.filter((x) => !(x.endpoint === c.endpoint && x.page === c.page));
    next.push(c);
    while (next.length > 1 && JSON.stringify(next).length > MAX_BYTES) next.shift();
    await chrome.storage.local.set({ captures: next });
  }).catch(() => {});
});
