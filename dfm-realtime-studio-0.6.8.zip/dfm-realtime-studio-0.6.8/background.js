// DFM Realtime Studio — service worker. Popup sends FETCH_ALL; per channel we fan out one get_cards
// (realtime card) and one list_creator_videos (recent uploads) and join them.
// Also: a 15-minute alarm re-runs the same fetch so the popup opens on a warm snapshot, and the
// icon badge shows how many videos are trending down (trend.js) — the extension's only alert.
// Every fetch also diffs titles/thumbnails against the last seen state (changes.js) and logs each
// change as a page in the Notion A/B database (notion.js) — the only host besides Studio.
// Also owns capture mode: registers/unregisters the two capture content scripts on demand.
import { getAuthHeader, chromeCookieGetter } from './auth.js';
import { getCards, listVideos, getExperiments } from './innertube.js';
import { parseRealtime } from './cards.js';
import { parseVideoList } from './videos.js';
import { fetchAll, probeOrder, PROBE_ACCOUNTS } from './fetch-all.js';
import { countDown, trendOf, isNightHour } from './trend.js';
import { diffVideos } from './changes.js';
import { snapshotThumbs } from './thumbs.js';
import { parseExperiments, diffExperiments } from './experiments.js';
import { postChangeSafely, resolveDatabase, ensureSchema, renameRows, listRows, archiveRows, missingEvents, eventFromMark, changeKey, testEvent, describeError, studioEditUrl, switchUrl, DEFAULT_DATABASE_ID, DEFAULT_TRACKED_DATABASE_ID, SCHEMA, relationSchema, RELATION_COLUMN, linkRows, blockChildren, listRecentChanges } from './notion.js';
import { trackedFromStorage } from './tracked.js';
import { fetchClients, clientLabel, DEFAULT_LIST_ID, fetchClientLists, fetchVideoTasks, setTaskField, suggestTask, watchUrl } from './clickup.js';
import { resolveChannel } from './channel-id.js';
import { pullTracked, pushTrack, ensureTrackedSchema, createTrackedDatabase } from './shared.js';
import { followedIds, perUserFromStorage, excludeKey } from './followed.js';
import { SWITCHER_URL, MAX_ACCOUNTS, parseSwitcherJson, parseSwitcher, identitiesFor, matchIdentities } from './switcher.js';
import { notionPageIdFromUrl, blockText, headingLevel, findVideoHeading, parseTitles, parseThumbnails, parseDescription, isFinalPackaging, findSection, SECTION } from './packaging.js';

const deps = {
  getAuthHeader: () => getAuthHeader({ getCookie: chromeCookieGetter() }),
  getCards,
  parseRealtime,
  listVideos,
  parseVideoList,
};

// ---- fetch + snapshot -------------------------------------------------------------------------
// The snapshot is the last reply minus each channel's raw JSON (~300 KB per channel; raw stays in
// popup memory only, per the design). The popup renders it instantly, then refreshes behind it.
export const POLL_ALARM = 'poll';
export const POLL_MINUTES = 15;

async function runFetch({ forceLink = false } = {}) {
  await refreshClients().catch(() => {});          // channels from ClickUp (kept from last time on failure)
  await refreshTracked().catch(() => {});          // shared tracked videos from Notion (same)
  await discoverLinks({ force: forceLink }).catch(() => {});   // page ids from the account switcher (brand channels)
  await autoLink(await channelList()).catch(() => {});   // every client channel, so the directory's tags are right
  let channels = await channelList({ activeOnly: true });
  let reply = await fetchAll(channels, deps);
  // A linked channel that answers 403: the account index was wrong (or moved). Re-probe now and retry once.
  const denied = reply.results.filter((r) => !r.ok && r.error?.kind === 'http' && (r.error.status === 401 || r.error.status === 403)).map((r) => r.channelId);
  const { relinkAt = {} } = await chrome.storage.local.get('relinkAt');
  const due = denied.filter((id) => forceLink || Date.now() - (relinkAt[id] ?? 0) > DISCOVER_MS);   // Refresh, or hourly per channel
  if (reply.signedIn && due.length) {
    for (const id of due) relinkAt[id] = Date.now();
    await chrome.storage.local.set({ relinkAt });
    // Re-discover page ids, then try THE REAL FETCH with every account index (with the page id, then
    // without) and keep the first that works. Every attempt is recorded on the result for the popup.
    await discoverLinks({ force: true }).catch(() => {});
    const { linkDiag } = await chrome.storage.local.get('linkDiag');
    channels = await channelList({ activeOnly: true });
    for (const channelId of due) {
      const ch = channels.find((c) => c.channelId === channelId);
      if (!ch) continue;
      const { result, attempts, link } = await relinkByFetch(ch, linkDiag);
      if (link) await saveLink(link);
      reply = { ...reply, results: reply.results.map((r) => r.channelId === channelId ? { ...result, attempts } : r) };
    }
  }
  const results = reply.results.map(({ raw, ...rest }) => rest);
  await chrome.storage.local.set({ snapshot: { at: Date.now(), reply: { ...reply, results } } });
  if (reply.signedIn) await refreshClickupVideos(channels, { force: forceLink }).then(() => autoFillRegistry(reply)).catch(() => {});   // DFM IDs + batch links from ClickUp
  if (reply.signedIn) await trackChanges(reply).catch(() => {});   // never let the log break the fetch
  if (reply.signedIn) await trackExperiments(reply).catch(() => {});
  if (reply.signedIn) await refreshSharedMarks().catch(() => {});      // changes other installs logged
  await updateBadge(reply);                                          // after tracking: a change just found starts its grace period now
  return reply;
}

// A denied channel: try every (account index, page id) combination through the normal fetch path.
// Candidates: the stored link, each account with the switcher's page id, each account without one.
async function relinkByFetch(ch, linkDiag) {
  const pageIds = [...new Set([ch.pageId, ...(linkDiag?.pages?.[ch.channelId] ?? [])].filter(Boolean))];
  const accounts = probeOrder((await chrome.storage.sync.get('channels')).channels ?? [], PROBE_ACCOUNTS);
  const candidates = [];
  for (const pageId of pageIds) for (const authUser of accounts) candidates.push({ pageId, authUser });
  for (const authUser of accounts) candidates.push({ pageId: undefined, authUser });
  const attempts = [];
  let last = null;
  for (const cand of candidates) {
    const { pageId, ...rest } = ch;
    const trial = { ...rest, authUser: cand.authUser, ...(cand.pageId ? { pageId: cand.pageId } : {}) };
    const r = await fetchAll([trial], deps);
    if (!r.signedIn) break;
    const result = r.results[0];
    attempts.push(`account ${cand.authUser}${cand.pageId ? ` + page …${cand.pageId.slice(-6)}` : ''}: ${result.ok ? 'OK' : (result.error?.kind === 'http' ? `HTTP ${result.error.status}` : result.error?.message)}`);
    last = result;
    if (result.ok) return { result, attempts, link: { channelId: ch.channelId, authUser: cand.authUser, verified: true, ...(cand.pageId ? { pageId: cand.pageId } : {}) } };
  }
  return { result: last ?? { label: ch.label, channelId: ch.channelId, ok: false, error: { kind: 'http', status: 401, message: 'HTTP 401' } }, attempts, link: null };
}
async function saveLink(link) {
  const { channels: links = [] } = await chrome.storage.sync.get('channels');
  const i = links.findIndex((l) => l.channelId === link.channelId);
  if (i === -1) links.push(link); else links[i] = { ...links[i], ...link };
  await chrome.storage.sync.set({ channels: links });
}

// ---- shared change marks: what OTHER installs logged ----------------------------------------------
// Each check pulls the last 7 days of the change log and keeps, as `sharedMarks`, the rows this install did
// not detect itself (same video + type within 2 min of a local mark = the same change). The popup and the
// Studio strip draw local + shared marks alike; the badge's grace period counts both.
const SAME_CHANGE_MS = 2 * 60_000;
async function refreshSharedMarks() {
  let cfg;
  try { cfg = await notionTarget(); } catch { return; }
  const { changeMarks = [] } = await chrome.storage.local.get('changeMarks');
  const since = Date.now() - MARKS_KEEP_MS;
  const rows = await listRecentChanges({ ...cfg, since });
  const local = changeMarks.filter((m) => m.at >= since);
  const shared = rows.filter((r) => !local.some((m) => m.videoId === r.videoId && m.type === r.type && Math.abs(m.at - r.at) < SAME_CHANGE_MS));
  await chrome.storage.local.set({ sharedMarks: shared, sharedMarksAt: Date.now() });
}
async function allMarks() {
  const { changeMarks = [], sharedMarks = [] } = await chrome.storage.local.get(['changeMarks', 'sharedMarks']);
  return [...changeMarks, ...sharedMarks];
}

// ---- title / thumbnail change log → Notion ---------------------------------------------------
// known: last seen state per video. changeQueue: events not yet accepted by Notion (retried on the
// next fetch; capped). changeLog: { logged, lastError, lastAt } for the popup's status line.
const QUEUE_MAX = 100;   // events may carry two ~20 KB images each
// Policy-pushed configuration (chrome.storage.managed) wins over local settings; tokens are always local.
async function managed() { try { return (await chrome.storage.managed?.get?.()) ?? {}; } catch { return {}; } }
async function notionConfig() {
  const [{ notion = {} }, m] = await Promise.all([chrome.storage.local.get('notion'), managed()]);
  const databaseId = m.changesDatabaseId || notion.databaseId || DEFAULT_DATABASE_ID;
  const trackedDatabaseId = m.trackedDatabaseId || notion.trackedDatabaseId || DEFAULT_TRACKED_DATABASE_ID;
  return {
    token: notion.token ?? '', databaseId, dataSourceId: notion.databaseId === databaseId || !notion.databaseId ? notion.dataSourceId ?? null : null, types: notion.types ?? null,
    trackedDatabaseId, trackedDataSourceId: (notion.trackedDatabaseId ?? DEFAULT_TRACKED_DATABASE_ID) === trackedDatabaseId ? notion.trackedDataSourceId ?? null : null,
    managed: { changes: Boolean(m.changesDatabaseId), tracked: Boolean(m.trackedDatabaseId) },
  };
}
async function clickupConfig() {
  const [{ clickup = {} }, m] = await Promise.all([chrome.storage.local.get('clickup'), managed()]);
  return { token: clickup.token ?? '', listId: m.clickupListId || clickup.listId || DEFAULT_LIST_ID, managed: Boolean(m.clickupListId) };
}
// Remember the data source's real column types so writes are shaped to them (url vs files, missing columns).
async function rememberTypes(types) {
  if (!types) return;
  const { notion = {} } = await chrome.storage.local.get('notion');
  await chrome.storage.local.set({ notion: { ...notion, types } });
}
// Pages are created under a data source (API 2025-09-03); resolve it from the database id once and
// cache it alongside the token. Re-resolved whenever the database id changes (NOTION_SAVE clears it).
async function notionTarget() {
  const cfg = await notionConfig();
  if (!cfg.token) throw new Error('Notion token not set');
  if (cfg.dataSourceId) return cfg;
  const r = await resolveDatabase(cfg);
  const { notion = {} } = await chrome.storage.local.get('notion');
  await chrome.storage.local.set({ notion: { ...notion, dataSourceId: r.dataSourceId } });
  const schema = await ensureSchema({ ...cfg, dataSourceId: r.dataSourceId }).catch(() => null);   // best effort; postChangeSafely retries on a schema 400 anyway
  if (schema) await rememberTypes(schema.types);
  return { ...cfg, dataSourceId: r.dataSourceId, types: schema?.types ?? null };
}
// Who is this install? The Chrome profile's e-mail (identity.email permission; managed profiles always have
// one), else the ClickUp token's user — kept as the part before "@" since the whole team shares one domain.
// Cached a day. Stamped on every change this install logs ("Logged by").
const WHOAMI_MS = 86_400_000;
async function whoAmI() {
  const { whoami } = await chrome.storage.local.get('whoami');
  if (whoami && Date.now() - whoami.at < WHOAMI_MS && whoami.email) return whoami.email;
  let email = null;
  try { const info = await chrome.identity.getProfileUserInfo({ accountStatus: 'ANY' }); email = info?.email || null; } catch { /* no identity API */ }
  if (!email) {
    try {
      const cfg = await clickupConfig();
      if (cfg.token) { const r = await fetch('https://api.clickup.com/api/v2/user', { headers: { Authorization: cfg.token } }); if (r.ok) email = (await r.json())?.user?.email ?? null; }
    } catch { /* offline */ }
  }
  email = email ? email.split('@')[0] : null;
  await chrome.storage.local.set({ whoami: { email, at: Date.now() } });
  return email;
}
const MARKS_KEEP_MS = 7 * 86_400_000;   // the popup draws a * on the hour a change was detected (48 h visible)
async function trackChanges(reply) {
  const { known = {}, changeQueue = [], changeMarks = [], changeHistory = [], thumbs = {} } = await chrome.storage.local.get(['known', 'changeQueue', 'changeMarks', 'changeHistory', 'thumbs']);
  const now = Date.now();
  // Baselines (known) cover every listed video, so a video tracked later already has one; only
  // TRACKED videos produce events, thumbnails and Notion rows. The DFM ID becomes the Notion Name.
  const tracked = await followedMap(reply.results);
  const chans = await channelList();
  const accountOf = Object.fromEntries(chans.map((c) => [c.channelId, c.authUser]));
  const initialsOf = Object.fromEntries(chans.map((c) => [c.channelId, c.initials ?? null]));
  const { events: all, known: next } = diffVideos(known, reply.results, now);
  // While a Test & compare of that kind runs, YouTube rotates the arms — that is the test (marked ~),
  // not a change to log.
  const { experiments = {} } = await chrome.storage.local.get('experiments');
  const underTest = (e) => { const x = experiments[e.videoId]; return x?.state === 'running' && (e.type === 'Thumbnail' ? x.hasThumbnails : x.hasTitles); };
  const events = all.filter((e) => e.videoId in (tracked[e.channelId] ?? {}) && !underTest(e));
  const me = await whoAmI().catch(() => null);
  for (const e of events) { e.loggedBy = me; const t = tracked[e.channelId][e.videoId]; e.dfmId = t.id ?? null; e.notionUrl = t.notionUrl ?? null; e.authUser = accountOf[e.channelId] ?? null; e.clientInitials = initialsOf[e.channelId] ?? t.client ?? null; }   // Notion Name, DFM batch, Studio URL, Client
  // Keep the current thumbnail bytes per tracked video; Thumbnail events get oldImage/newImage for Notion.
  const nextThumbs = await snapshotThumbs({ results: onlyTracked(reply.results, tracked), events, thumbs, now });
  await chrome.storage.local.set({ thumbs: nextThumbs });
  const queue = [...changeQueue, ...events].slice(-QUEUE_MAX);
  // Marks feed the popup's hover card: before/after title and thumbnail for each change. For a
  // title change both thumbnails are the current snapshot; for a thumbnail change both titles are
  // the current title.
  const current = (id) => nextThumbs[id]?.dataUrl ?? null;
  const marks = [...changeMarks.filter((m) => now - m.at < MARKS_KEEP_MS), ...events.map((e) => ({
    videoId: e.videoId, type: e.type, at: e.detectedAt, dfmId: e.dfmId ?? null, by: e.loggedBy ?? null,
    oldId: e.oldId ?? null, newId: e.newId ?? null,                        // thumbnail identity compared (diagnostics in the hover card)
    oldTitle: e.type === 'Title' ? e.old : e.title, newTitle: e.type === 'Title' ? e.new : e.title,
    oldImage: e.type === 'Thumbnail' ? (e.oldImage ?? null) : current(e.videoId),
    newImage: e.type === 'Thumbnail' ? (e.newImage ?? current(e.videoId)) : current(e.videoId),
  }))];
  // History: every change we ever detected (no images — those live in marks for 7 days), so a row
  // deleted in Notion can be restored by Re-sync. 90 days, capped.
  const history = [...changeHistory.filter((e) => now - e.detectedAt < HISTORY_KEEP_MS), ...events.map(({ oldImage, newImage, ...e }) => e)].slice(-HISTORY_MAX);
  await chrome.storage.local.set({ known: next, changeQueue: queue, changeMarks: marks, changeHistory: history });
  if (queue.length) await flushQueue();
}
const HISTORY_KEEP_MS = 90 * 86_400_000, HISTORY_MAX = 2000;

// Re-sync: push anything still queued, then compare the 90-day history with the rows Notion holds
// and post the missing ones (images re-attached from marks when still there). Returns the count.
async function resync() {
  await flushQueue();
  const cfg = await notionTarget();
  const { changeHistory = [], changeMarks = [], changeQueue = [], changeLog = {} } = await chrome.storage.local.get(['changeHistory', 'changeMarks', 'changeQueue', 'changeLog']);
  const rows = await listRows(cfg);
  // Backfill the change → video relation on rows written before the column existed (or before the video's row).
  let linked = 0;
  try {
    await ensureRelation({ force: true });
    const reg = await loadRegistry();
    const pageOf = new Map(Object.values(reg).flatMap((m) => Object.entries(m)).filter(([, e]) => e.pageId).map(([videoId, e]) => [videoId, e.pageId]));
    const todo = rows.filter((r) => !r.linked && r.videoId && pageOf.has(r.videoId)).map((r) => ({ id: r.id, trackedPageId: pageOf.get(r.videoId) }));
    linked = await linkRows({ token: cfg.token, links: todo });
  } catch { /* relation is best effort */ }
  // Marks recorded before the history store existed are folded into the history (without images).
  const sync = await chrome.storage.sync.get(null);
  const { snapshot } = await chrome.storage.local.get('snapshot');
  const bars = {};
  for (const r of snapshot?.reply?.results ?? []) if (r.ok) for (const v of r.data.videos ?? []) bars[v.videoId] = v.bars;
  const known = new Set(changeHistory.map((e) => changeKey(e.videoId, e.type, e.detectedAt)));
  const chans = await channelList();
  const trackedNow = await loadRegistry();
  const fromMarks = changeMarks.filter((m) => !known.has(changeKey(m.videoId, m.type, m.at)))
    .map((m) => eventFromMark(m, { tracked: trackedNow, channels: chans, bars }));
  const history = [...changeHistory, ...fromMarks.map(({ oldImage, newImage, ...e }) => e)].sort((a, b) => a.detectedAt - b.detectedAt).slice(-HISTORY_MAX);
  const queuedKeys = new Set(changeQueue.map((e) => changeKey(e.videoId, e.type, e.detectedAt)));
  const missing = missingEvents(history, rows).filter((e) => !queuedKeys.has(changeKey(e.videoId, e.type, e.detectedAt)));
  const withImages = missing.map((e) => {
    const m = changeMarks.find((x) => x.videoId === e.videoId && x.type === e.type && x.at === e.detectedAt);
    return m?.oldImage || m?.newImage ? { ...e, oldImage: m.oldImage ?? null, newImage: m.newImage ?? null } : e;
  });
  await chrome.storage.local.set({ changeHistory: history, changeQueue: [...changeQueue, ...withImages].slice(-QUEUE_MAX), changeLog: { ...changeLog, lastResync: { at: Date.now(), rows: rows.length, restored: withImages.length, linked } } });
  if (withImages.length) await flushQueue();
  return withImages.length;
}
// renameQueue: [{ videoId, name }] — Name updates for existing rows after a DFM ID changed. Only the
// latest name per video is kept; processed after the change events so new rows already carry it.
// The change log ↔ registry relation column ("Video"). Created once both databases are reachable, then
// re-checked daily; `force` for Test connection. Remembers the resulting column types.
const RELATION_MS = 86_400_000;
async function ensureRelation({ force = false } = {}) {
  const { relationAt = 0 } = await chrome.storage.local.get('relationAt');
  if (!force && Date.now() - relationAt < RELATION_MS) return null;
  const [cfg, tracked] = await Promise.all([notionTarget(), trackedTarget()]);
  const { added, types } = await ensureSchema({ ...cfg, schema: { ...SCHEMA, ...relationSchema(tracked.dataSourceId) } });
  await rememberTypes(types);
  await chrome.storage.local.set({ relationAt: Date.now() });
  return { added, types };
}
// pageId of the video's registry row (after the shared list was pulled / pushed), for the relation.
async function trackedPageIdOf(channelId, videoId) {
  const reg = await loadRegistry();
  return reg[channelId]?.[videoId]?.pageId ?? null;
}
async function flushQueue() {
  const { changeQueue = [], renameQueue = [], changeLog = { logged: 0 } } = await chrome.storage.local.get(['changeQueue', 'renameQueue', 'changeLog']);
  let cfg;
  try { cfg = await notionTarget(); }
  catch (e) { await chrome.storage.local.set({ changeLog: { ...changeLog, lastError: describeError(e), lastAt: Date.now() } }); return; }
  const remaining = [];
  let logged = changeLog.logged ?? 0, lastError = null, lastWarning = null;
  if (changeQueue.length) await ensureRelation().catch(() => {});
  for (const event of changeQueue) {
    if (lastError) { remaining.push(event); continue; }          // stop at the first failure, keep order
    try { const trackedPageId = await trackedPageIdOf(event.channelId, event.videoId); const r = await postChangeSafely({ ...cfg, event: { ...event, ...(trackedPageId ? { trackedPageId } : {}) } }); logged++; if (r.warning) lastWarning = r.warning; if (r.types && r.types !== cfg.types) { cfg.types = r.types; await rememberTypes(r.types); } }
    catch (e) { lastError = describeError(e); remaining.push(event); }
  }
  const renamesLeft = [];
  let renamed = changeLog.renamed ?? 0;
  for (const job of renameQueue) {
    if (lastError) { renamesLeft.push(job); continue; }
    try { renamed += await renameRows({ ...cfg, ...job }); }
    catch (e) { lastError = describeError(e); renamesLeft.push(job); }
  }
  await chrome.storage.local.set({ changeQueue: remaining, renameQueue: renamesLeft, changeLog: { logged, renamed, lastError, lastWarning: lastWarning ?? (lastError ? changeLog.lastWarning ?? null : null), lastAt: Date.now() } });
}
async function queueRename(videoId, name) {
  const { renameQueue = [] } = await chrome.storage.local.get('renameQueue');
  await chrome.storage.local.set({ renameQueue: [...renameQueue.filter((j) => j.videoId !== videoId), { videoId, name }] });
  await flushQueue();
}
async function changeStatus() {
  const cfg = await notionConfig();
  const { changeQueue = [], renameQueue = [], changeLog = { logged: 0 } } = await chrome.storage.local.get(['changeQueue', 'renameQueue', 'changeLog']);
  const tracked = Object.values(await loadRegistry()).reduce((n, m) => n + Object.keys(m).length, 0);
  const { trackedPulledAt = null, pendingShared = [], sharedError = null } = await chrome.storage.local.get(['trackedPulledAt', 'pendingShared', 'sharedError']);
  return { configured: Boolean(cfg.token), databaseId: cfg.databaseId, trackedDatabaseId: cfg.trackedDatabaseId, managed: cfg.managed, tracked, trackedPulledAt, pendingShared: pendingShared.length, sharedError,
    queued: changeQueue.length + renameQueue.length, ...changeLog };
}

// ---- channels from the ClickUp Client Database ----------------------------------------------------
// clients: [{ taskId, name, initials, channelUrl, pod, tier, status, channelId|null, resolveError? }] in
// storage.local; handleCache: { [url]: { channelId, at } } (30 days). The per-install fields (pageId /
// authUser, learned from the channel's Studio tab) stay in storage.sync `channels`, keyed by channelId.
const HANDLE_CACHE_MS = 30 * 86_400_000, RESOLVE_CONCURRENCY = 3;
async function refreshClients() {
  const cfg = await clickupConfig();
  if (!cfg.token) return null;
  const { clients, skipped, total } = await fetchClients(cfg);
  const { handleCache = {} } = await chrome.storage.local.get('handleCache');
  const now = Date.now();
  const jobs = clients.map((c) => async () => {
    const cached = handleCache[c.channelUrl];
    if (cached?.channelId && 'avatar' in cached && now - cached.at < HANDLE_CACHE_MS) { c.channelId = cached.channelId; c.avatar = cached.avatar; return; }
    try { const r = await resolveChannel(c.channelUrl); c.channelId = r.channelId; c.avatar = r.avatar; handleCache[c.channelUrl] = { channelId: r.channelId, avatar: r.avatar, at: now }; }
    catch (e) { c.channelId = cached?.channelId ?? null; c.avatar = cached?.avatar ?? null; c.resolveError = e?.message ?? String(e); }
  });
  for (let i = 0; i < jobs.length; i += RESOLVE_CONCURRENCY) await Promise.all(jobs.slice(i, i + RESOLVE_CONCURRENCY).map((j) => j()));
  const errors = {};
  for (const c of clients) if (!c.channelId && c.resolveError) errors[c.resolveError] = (errors[c.resolveError] ?? 0) + 1;
  const status = { lastPull: now, total, withChannel: clients.length, resolved: clients.filter((c) => c.channelId).length,
    unresolved: clients.filter((c) => !c.channelId).length, skippedArchived: skipped.archived, noChannel: skipped.noChannel, error: null,
    resolveErrors: Object.entries(errors).sort((a, b) => b[1] - a[1]).slice(0, 3).map(([message, count]) => `${count}× ${message}`),
    unresolvedNames: clients.filter((c) => !c.channelId).map((c) => c.name).slice(0, 8) };
  await chrome.storage.local.set({ clients, handleCache, clickupStatus: status });
  return status;
}
// Popup/fetch channel list: ClickUp clients with a resolved id, joined with this install's page id /
// account index (storage.sync `channels`, learned from Studio tabs). Nothing else — ClickUp is the
// only source of channels.
// `active` = added to THIS install's popup (storage.sync `activeChannels`, opt-in). Only active channels
// are fetched, badged and offered for tracking; the shared tracked list is per video and untouched.
async function channelList({ activeOnly = false } = {}) {
  const [{ clients = [] }, sync] = await Promise.all([chrome.storage.local.get('clients'), chrome.storage.sync.get(null)]);
  const { channels: links = [], activeChannels = [] } = sync;
  const { excludes } = perUserFromStorage(sync);
  const mine = Object.fromEntries(links.map((c) => [c.channelId, c]));
  const active = new Set(activeChannels);
  return clients.filter((c) => c.channelId).map((c) => ({
    label: clientLabel(c), channelId: c.channelId, initials: c.initials, clientName: c.name, pod: c.pod, tier: c.tier, status: c.status, clickupUrl: c.url, avatar: c.avatar ?? null, active: active.has(c.channelId),
    excludes: excludes[c.channelId] ?? [],
    ...(mine[c.channelId]?.pageId ? { pageId: mine[c.channelId].pageId } : {}), ...(mine[c.channelId]?.authUser !== undefined ? { authUser: mine[c.channelId].authUser } : {}), verified: Boolean(mine[c.channelId]?.verified),
  })).filter((c) => !activeOnly || c.active);
}

// Link discovery: YouTube's account switcher, fetched once per signed-in account index, lists every
// identity that account can act as — brand-account channels with their page id. Client channels are
// matched by handle (switcher.js) and the links written to storage.sync `channels` for this install.
// Hourly, or forced by the popup's Refresh. Diagnostics in storage.local `linkDiag` (popup tooltip).
const DISCOVER_MS = 3_600_000;
async function discoverLinks({ force = false } = {}) {
  const { linkDiag, clients = [] } = await chrome.storage.local.get(['linkDiag', 'clients']);
  if (!force && linkDiag?.at && Date.now() - linkDiag.at < DISCOVER_MS) return;
  const diag = { at: Date.now(), accounts: [], identities: 0, matched: 0, linked: 0, rejected: [], errors: [], pages: {}, probes: [] };
  let authHeader = null;
  try { authHeader = await deps.getAuthHeader(); } catch (e) { diag.errors.push(`not signed in: ${e?.message ?? e}`); }
  // 1. Every identity the switcher lists for each signed-in account index. The selected section belongs
  //    to index n; other sections (other Google accounts) are kept with no index — the probe below finds it.
  const identities = [];
  const seen = new Set();
  for (let n = 0; n < MAX_ACCOUNTS; n++) {
    let text;
    try {
      const headers = { 'X-Goog-AuthUser': String(n), 'X-Origin': 'https://www.youtube.com', ...(authHeader ? { Authorization: authHeader } : {}) };
      const res = await fetch(`${SWITCHER_URL}?authuser=${n}`, { credentials: 'include', headers });
      text = await res.text();
      if (!res.ok) { diag.errors.push(`switcher account ${n}: HTTP ${res.status}`); if (res.status === 401 || res.status === 403) break; continue; }
    } catch (e) { diag.errors.push(`switcher account ${n}: ${e?.message ?? e}`); break; }
    let sections;
    try { sections = parseSwitcher(parseSwitcherJson(text)); } catch (e) { diag.errors.push(`switcher account ${n}: ${e?.message ?? e}`); break; }
    const own = identitiesFor(sections, n);
    const key = own[0]?.email ?? own.map((i) => i.handle ?? i.name).join(',');
    if (!own.length || seen.has(key)) break;           // past the last signed-in account (YouTube falls back to the default one)
    seen.add(key);
    diag.accounts.push(own[0]?.email ?? `account ${n}`);
    identities.push(...own);
    for (const sec of sections) if (!sec.items.some((i) => i.selected)) for (const i of sec.items) identities.push({ authUser: undefined, name: i.name, handle: i.handle, pageId: i.pageId, email: sec.email });
  }
  diag.identities = identities.length;
  // 2. Match client channels by handle, then VERIFY each link against Studio (the switcher's account index
  //    is a hint; a brand channel under another account answers 401/403 until the right index is used).
  const found = matchIdentities(identities, clients);
  diag.matched = found.length;
  for (const f of found) if (f.pageId) diag.pages[f.channelId] = [...new Set([...(diag.pages[f.channelId] ?? []), f.pageId])];
  const { channels: links = [] } = await chrome.storage.sync.get('channels');
  let changed = false;
  for (const f of found) {
    const cur = links.find((l) => l.channelId === f.channelId);
    if (cur?.verified && cur.pageId === (f.pageId ?? cur.pageId)) { diag.linked++; continue; }
    if (!authHeader) break;
    const order = [f.authUser, ...PROBE_ACCOUNTS].filter((a, i, arr) => a !== undefined && arr.indexOf(a) === i);
    let ok = null, last = null;
    for (const authUser of order) {
      try { await getCards({ channel: { channelId: f.channelId, pageId: f.pageId, authUser }, authHeader }); ok = authUser; diag.probes.push(`${f.channelId} account ${authUser}: OK`); break; }
      catch (e) { last = e?.status ? `HTTP ${e.status}` : (e?.message ?? String(e)); diag.probes.push(`${f.channelId} account ${authUser}: ${last}`); }
    }
    if (ok === null) { diag.rejected.push(`${f.channelId}${f.pageId ? ` page ${f.pageId}` : ''}: ${last}`); continue; }
    const entry = { channelId: f.channelId, authUser: ok, verified: true, ...(f.pageId ? { pageId: f.pageId } : {}) };
    const i = links.findIndex((l) => l.channelId === f.channelId);
    if (i === -1) links.push(entry); else links[i] = { ...links[i], ...entry };
    changed = true; diag.linked++;
  }
  if (changed) await chrome.storage.sync.set({ channels: links });
  await chrome.storage.local.set({ linkDiag: diag });
  return diag;
}

// Auto-link: for a channel this install has not linked, try the signed-in account indexes without a
// page id; the first one Studio accepts is the link (personal channels). The team's channels live on a
// couple of Google accounts, so indexes that already link other channels are tried first. Brand-account
// channels need the page id and still want one click on their Studio tab. Hourly per channel; `force`
// ignores that (used after a 403). Returns the channel ids linked this time.
const LINK_PROBE_MS = 3_600_000;
async function autoLink(channels, { force = false } = {}) {
  const unlinked = channels.filter((c) => !c.pageId && c.authUser === undefined);
  if (!unlinked.length) return [];
  const { linkProbes = {} } = await chrome.storage.local.get('linkProbes');
  const now = Date.now();
  let authHeader;
  try { authHeader = await deps.getAuthHeader(); } catch { return []; }
  const linked = [];
  for (const c of unlinked) {
    if (!force && now - (linkProbes[c.channelId] ?? 0) < LINK_PROBE_MS) continue;
    linkProbes[c.channelId] = now;
    const { channels: links = [] } = await chrome.storage.sync.get('channels');
    for (const authUser of probeOrder(links, PROBE_ACCOUNTS)) {
      try {
        await getCards({ channel: { channelId: c.channelId, authUser }, authHeader });
        const i = links.findIndex((l) => l.channelId === c.channelId);
        if (i === -1) links.push({ channelId: c.channelId, authUser }); else links[i] = { ...links[i], authUser };
        await chrome.storage.sync.set({ channels: links });
        c.authUser = authUser;
        linked.push(c.channelId);
        break;
      } catch { /* next account */ }
    }
  }
  await chrome.storage.local.set({ linkProbes });
  return linked;
}

// ---- ClickUp video tasks → DFM ID + batch link ------------------------------------------------------
// Per active channel: the client's "(INITIALS) … - DFM Task Space" lists (cached a day), then their
// long-form video tasks (cached an hour; Refresh forces). storage.local: cuLists { initials: { at, listIds } },
// cuVideos { channelId: { at, videos, error } }. A video whose YouTube URL sits in a task's ▶️ YouTube Link
// field gets that task's episode number as DFM ID and the batch task as DFM batch link, automatically.
const CU_LISTS_MS = 86_400_000, CU_VIDEOS_MS = 3_600_000;
async function refreshClickupVideos(channels, { force = false } = {}) {
  const cfg = await clickupConfig();
  if (!cfg.token) return;
  const { cuLists = {}, cuVideos = {} } = await chrome.storage.local.get(['cuLists', 'cuVideos']);
  const now = Date.now();
  for (const ch of channels) {
    if (!ch.initials) continue;
    if (!force && now - (cuVideos[ch.channelId]?.at ?? 0) < CU_VIDEOS_MS) continue;
    try {
      let lists = cuLists[ch.initials];
      if (!lists || now - lists.at > CU_LISTS_MS || !lists.listIds.length) {
        const r = await fetchClientLists({ token: cfg.token, initials: ch.initials });
        lists = { at: now, listIds: r.listIds, seen: r.seen };
        cuLists[ch.initials] = lists;
      }
      const videos = lists.listIds.length ? await fetchVideoTasks({ token: cfg.token, listIds: lists.listIds }) : [];
      const seen = lists.seen ? ` (saw ${lists.seen.folders} folders, ${lists.seen.lists} lists — v${chrome.runtime.getManifest().version})` : '';
      cuVideos[ch.channelId] = { at: now, videos, listIds: lists.listIds, error: lists.listIds.length ? null : `no "(${ch.initials})" list in Client HQ${seen}` };
    } catch (e) {
      cuVideos[ch.channelId] = { ...(cuVideos[ch.channelId] ?? { videos: [] }), at: now, error: e?.message ?? String(e) };
    }
  }
  await chrome.storage.local.set({ cuLists, cuVideos });
}
// Followed videos without a DFM ID whose id appears in a ClickUp task's YouTube link → registry entry.
async function autoFillRegistry(reply) {
  const { cuVideos = {} } = await chrome.storage.local.get('cuVideos');
  const followed = await followedMap(reply.results);
  const registry = await loadRegistry();
  for (const r of reply.results) {
    if (!r.ok) continue;
    const tasks = cuVideos[r.channelId]?.videos ?? [];
    if (!tasks.length) continue;
    const byVideo = new Map(tasks.filter((t) => t.videoId).map((t) => [t.videoId, t]));
    for (const videoId of Object.keys(followed[r.channelId] ?? {})) {
      const cur = registry[r.channelId]?.[videoId];
      // A "DFM batch" that points at ClickUp is a leftover from before the Ideation Link was used: replace it.
      const staleNotion = !cur?.notionUrl || /app\.clickup\.com/i.test(cur.notionUrl);
      if (cur?.id && !staleNotion && cur?.clickupUrl) continue;
      const t = byVideo.get(videoId);
      if (!t) continue;
      const v = r.data.videos?.find((x) => x.videoId === videoId);
      await setRegistry({ channelId: r.channelId, videoId, entry: { id: cur?.id ?? t.dfmId, notionUrl: staleNotion ? (t.ideationUrl ?? null) : cur.notionUrl, clickupUrl: t.url, batchUrl: t.batchUrl, batchName: t.batchName, clickupTaskId: t.taskId, title: v?.title ?? cur?.title ?? t.title, publishedAt: v?.publishedAt ?? cur?.publishedAt ?? null, thumbnail: v?.thumbnail ?? cur?.thumbnail ?? null } });
    }
  }
}
// Popup: the client's video tasks for one channel (for the picker), with a title-based suggestion.
async function clickupTasksFor({ channelId, title }) {
  const { cuVideos = {} } = await chrome.storage.local.get('cuVideos');
  const entry = cuVideos[channelId];
  const videos = entry?.videos ?? [];
  return { videos, at: entry?.at ?? null, error: entry?.error ?? null, suggested: suggestTask(videos.filter((v) => !v.videoId), title) };
}
// Popup picked a task for a video: write the YouTube URL into the task (the one ClickUp write), then fill
// the registry from the task. Refuses a task already linked to another video.
async function linkClickupTask({ channelId, videoId, taskId, title, publishedAt, thumbnail }) {
  const cfg = await clickupConfig();
  if (!cfg.token) throw new Error('ClickUp token not set');
  const { cuVideos = {} } = await chrome.storage.local.get('cuVideos');
  const t = (cuVideos[channelId]?.videos ?? []).find((x) => x.taskId === taskId);
  if (!t) throw new Error('task not in the cached list — press Refresh');
  if (t.videoId && t.videoId !== videoId) throw new Error(`that task is already linked to video ${t.videoId}`);
  if (t.videoId !== videoId) await setTaskField({ token: cfg.token, taskId, value: watchUrl(videoId) });
  t.youtubeUrl = watchUrl(videoId); t.videoId = videoId;
  await chrome.storage.local.set({ cuVideos });
  const tracked = await setRegistry({ channelId, videoId, entry: { id: t.dfmId, notionUrl: t.ideationUrl ?? null, clickupUrl: t.url, batchUrl: t.batchUrl, batchName: t.batchName, clickupTaskId: taskId, title: title ?? t.title, publishedAt: publishedAt ?? null, thumbnail: thumbnail ?? null } });
  return { tracked, task: t };
}

// ---- shared tracked videos (Notion "Tracked videos") -------------------------------------------------
async function trackedTarget() {
  const cfg = await notionConfig();
  if (!cfg.token) throw new Error('Notion token not set');
  if (!cfg.trackedDatabaseId) throw new Error('Tracked videos database not set');
  let dsId = cfg.trackedDataSourceId;
  if (!dsId) {
    const r = await resolveDatabase({ token: cfg.token, databaseId: cfg.trackedDatabaseId });
    dsId = r.dataSourceId;
    await ensureTrackedSchema({ token: cfg.token, dataSourceId: dsId }).catch(() => {});
    const { notion = {} } = await chrome.storage.local.get('notion');
    await chrome.storage.local.set({ notion: { ...notion, trackedDatabaseId: cfg.trackedDatabaseId, trackedDataSourceId: dsId } });
  }
  return { token: cfg.token, dataSourceId: dsId };
}
// Pull the shared map into storage.local.tracked. First time: migrate this install's legacy per-channel
// storage.sync entries into the shared database, then drop them.
async function refreshTracked() {
  const target = await trackedTarget();
  const sync = await chrome.storage.sync.get(null);
  const legacy = trackedFromStorage(sync);
  let shared = await pullTracked(target);
  if (Object.keys(legacy).length) {
    // One-time: the DFM IDs / links of the old per-person "tracked:<channel>" lists go to the shared registry.
    const channels = await channelList();
    for (const [channelId, map] of Object.entries(legacy)) {
      const ch = channels.find((c) => c.channelId === channelId);
      for (const [videoId, entry] of Object.entries(map)) {
        if (shared[channelId]?.[videoId]) continue;
        try { await pushTrack({ ...target, channelId, videoId, entry, client: ch?.initials ?? null, channelLabel: ch?.label ?? null, addedBy: 'migration' }); } catch { /* next time */ }
      }
    }
    await chrome.storage.sync.remove(Object.keys(sync).filter((k) => k.startsWith('tracked:') || k.startsWith('mode:') || k.startsWith('follow:')));
    shared = await pullTracked(target);
  }
  await chrome.storage.local.set({ tracked: shared, trackedPulledAt: Date.now() });
  return shared;
}
// Popup actions. Following is per person (storage.sync); the DFM ID / batch link go to the shared
// registry (optimistic local update, push queued if Notion is unreachable).
// × on a row excludes a video for this person; Add in the picker restores it. The DFM ID / links, when
// given, go to the shared registry.
async function followVideo({ channelId, videoId, entry }) {
  const { [excludeKey(channelId)]: excludes = [] } = await chrome.storage.sync.get(excludeKey(channelId));
  const nextExcludes = excludes.filter((id) => id !== videoId);
  await chrome.storage.sync.set({ [excludeKey(channelId)]: nextExcludes });
  if (entry && (entry.id || entry.notionUrl || entry.title)) await setRegistry({ channelId, videoId, entry });
  return { excludes: nextExcludes, tracked: await loadRegistry() };
}
async function unfollowVideo({ channelId, videoId }) {
  const { [excludeKey(channelId)]: excludes = [] } = await chrome.storage.sync.get(excludeKey(channelId));
  const nextExcludes = excludes.includes(videoId) ? excludes : [...excludes, videoId];
  await chrome.storage.sync.set({ [excludeKey(channelId)]: nextExcludes });
  return { excludes: nextExcludes };
}
async function setRegistry({ channelId, videoId, entry }) {
  const tracked = await loadRegistry();
  const prev = tracked[channelId]?.[videoId];
  const next = { ...tracked, [channelId]: { ...(tracked[channelId] ?? {}), [videoId]: { ...(prev ?? { addedAt: Date.now() }), ...entry } } };
  await chrome.storage.local.set({ tracked: next });
  const ch = (await channelList()).find((c) => c.channelId === channelId);
  await sharedPush({ op: 'track', channelId, videoId, entry: next[channelId][videoId], client: ch?.initials ?? null, channelLabel: ch?.label ?? null });
  return next;
}
async function sharedPush(job) {
  const { pendingShared = [] } = await chrome.storage.local.get('pendingShared');
  const queue = [...pendingShared.filter((j) => !(j.videoId === job.videoId)), job];
  await chrome.storage.local.set({ pendingShared: queue });
  await flushShared();
}
async function flushShared() {
  const { pendingShared = [] } = await chrome.storage.local.get('pendingShared');
  if (!pendingShared.length) { await chrome.storage.local.set({ sharedError: null }); return; }
  let target;
  try { target = await trackedTarget(); } catch (e) { await chrome.storage.local.set({ sharedError: e?.message ?? String(e) }); return; }   // not configured yet: keep the queue
  const left = [];
  let lastError = null, schemaFixed = false;
  for (const job of pendingShared) {
    for (let attempt = 0; attempt < 2; attempt++) {
      try {
        if (job.op === 'track') {
          const pageId = await pushTrack({ ...target, channelId: job.channelId, videoId: job.videoId, entry: job.entry, client: job.client, channelLabel: job.channelLabel, addedBy: (await whoAmI().catch(() => null)) ?? 'extension' });
          const { tracked = {} } = await chrome.storage.local.get('tracked');
          if (tracked[job.channelId]?.[job.videoId]) { tracked[job.channelId][job.videoId].pageId = pageId; await chrome.storage.local.set({ tracked }); }
        }
        break;
      } catch (e) {
        lastError = describeError(e);
        // A column this version writes (e.g. "ClickUp task") is missing in the shared database: add it, retry once.
        if (attempt === 0 && !schemaFixed && /property|schema|does not exist|not a property/i.test(lastError)) { schemaFixed = true; await ensureTrackedSchema(target).catch(() => {}); continue; }
        left.push(job); break;
      }
    }
  }
  await chrome.storage.local.set({ pendingShared: left, sharedError: left.length ? lastError : null });
}

// Badge: // RED = number of tracked videos going down (last 3 completed hours vs the 3 before), skipping videos
// changed in the last 3 h. Empty when nothing to say, when signed out, and during night hours.
const BADGE_DOWN = '#d93025';
async function updateBadge(reply) {
  const changeMarks = await allMarks();
  let n = 0;
  if (reply?.signedIn && !reply.fatal) n = countDown(reply.results, { tracked: await followedMap(reply.results), marks: changeMarks });
  await chrome.action.setBadgeBackgroundColor({ color: BADGE_DOWN });
  await chrome.action.setBadgeText({ text: n ? String(n) : '' });
}
// The shared registry (Notion "Tracked videos"): DFM IDs and batch links per video — team data.
const loadRegistry = async () => (await chrome.storage.local.get('tracked')).tracked ?? {};
// What THIS person follows, per channel, given the latest fetch: the latest 10 long-form with views, minus excludes.
// Shaped like the old tracked map ({ channelId: { videoId: entry } }) so detection/badge code is unchanged.
async function followedMap(results) {
  const { excludes } = perUserFromStorage(await chrome.storage.sync.get(null));
  const registry = await loadRegistry();
  const out = {};
  for (const r of results ?? []) {
    if (!r.ok) continue;
    const ids = followedIds({ videos: r.data.videos ?? [], excludes: excludes[r.channelId] ?? [] });
    out[r.channelId] = Object.fromEntries(ids.map((id) => [id, registry[r.channelId]?.[id] ?? {}]));
  }
  return out;
}
const loadTracked = async () => { const { snapshot } = await chrome.storage.local.get('snapshot'); return followedMap(snapshot?.reply?.results ?? []); };
// Only tracked videos are logged and snapshotted: results reduced to them.
const onlyTracked = (results, tracked) => results.map((r) => (r.ok ? { ...r, data: { ...r.data, videos: (r.data.videos ?? []).filter((v) => v.videoId in (tracked[r.channelId] ?? {})) } } : r));

async function ensureAlarm() {
  const existing = await chrome.alarms.get(POLL_ALARM);
  if (!existing || existing.periodInMinutes !== POLL_MINUTES) await chrome.alarms.create(POLL_ALARM, { periodInMinutes: POLL_MINUTES });
}
chrome.runtime.onInstalled.addListener(ensureAlarm);
chrome.runtime.onStartup.addListener(ensureAlarm);

// ---- background poll ---------------------------------------------------------------------------
async function poll() {
  try { await runFetch(); }
  catch (e) {
    // No popup to show it in; the popup reads this off the snapshot.
    const { snapshot = {} } = await chrome.storage.local.get('snapshot');
    await chrome.storage.local.set({ snapshot: { ...snapshot, error: e?.message ?? String(e), errorAt: Date.now() } });
  }
}
chrome.alarms.onAlarm.addListener((alarm) => { if (alarm.name === POLL_ALARM) poll(); });

// ---- A/B tests ("Test & compare") on tracked videos --------------------------------------------
// One creator/get_creator_videos per channel with all its tracked video ids (chunks of 50).
// experiments: { [videoId]: experiment | null } (+ fetchedAt) for the popup's ~ marker and hover card;
// testMarks: [{ type: 'TestStarted'|'TestFinished', videoId, at }] for 90 days.
const EXPERIMENT_CHUNK = 50;
async function trackExperiments(reply) {
  const tracked = await followedMap(reply.results);
  const channels = await channelList({ activeOnly: true });
  const { experiments = {}, testMarks = [] } = await chrome.storage.local.get(['experiments', 'testMarks']);
  const authHeader = await deps.getAuthHeader();
  const current = {};
  for (const r of reply.results) {
    if (!r.ok) continue;
    const ch = channels.find((c) => c.channelId === r.channelId) ?? { channelId: r.channelId };
    const ids = Object.keys(tracked[r.channelId] ?? {});
    for (let i = 0; i < ids.length; i += EXPERIMENT_CHUNK) {
      const chunk = ids.slice(i, i + EXPERIMENT_CHUNK);
      try { Object.assign(current, parseExperiments(await getExperiments({ channel: ch, videoIds: chunk, authHeader }))); }
      catch { for (const id of chunk) if (id in experiments) current[id] = experiments[id]; }   // keep what we knew
    }
  }
  const now = Date.now();
  const { fetchedAt, ...known } = experiments;
  const { events } = diffExperiments(known, current, now);
  let marks = [...testMarks.filter((m) => now - m.at < HISTORY_KEEP_MS), ...events.map((e) => ({ type: e.type, videoId: e.videoId, at: e.at, startedAt: e.startedAt }))];
  // Backfill: a running test without a detection mark (recorded by an older version, or missed) gets
  // one now, so the popup can draw its ~ above the hour it was first seen. Legacy marks without
  // `startedAt` (they carried YouTube's start time as `at`) are dropped for that video.
  for (const [videoId, x] of Object.entries(current)) {
    if (!x || x.state !== 'running') continue;
    if (!marks.some((m) => m.type === 'TestStarted' && m.videoId === videoId && 'startedAt' in m && (m.startedAt ?? null) === (x.startedAt ?? null))) {
      marks = marks.filter((m) => !(m.type === 'TestStarted' && m.videoId === videoId && !('startedAt' in m)));
      marks.push({ type: 'TestStarted', videoId, at: now, startedAt: x.startedAt ?? null });
    }
  }
  await chrome.storage.local.set({ experiments: { ...current, fetchedAt: now }, testMarks: marks });
}

// ---- purge false thumbnail detections ------------------------------------------------------------
// The first detector compared Studio's image id with the URL version hash when a response omitted the
// ids — every video "changed" at once. Such events are recognisable: old and new identity are of
// different kinds. Remove them from history, marks and the queue, and archive their Notion rows.
const idKind = (x) => (x === null || x === undefined ? null : String(x).startsWith('v:') ? 'ver' : 'id');
const isFalseThumb = (e) => e.type === 'Thumbnail' && idKind(e.oldId) && idKind(e.newId) && idKind(e.oldId) !== idKind(e.newId);
async function purgeFalseThumbnails() {
  const { changeHistory = [], changeMarks = [], changeQueue = [] } = await chrome.storage.local.get(['changeHistory', 'changeMarks', 'changeQueue']);
  const bad = changeHistory.filter(isFalseThumb);
  const badKeys = new Set(bad.map((e) => changeKey(e.videoId, e.type, e.detectedAt)));
  const marksLeft = changeMarks.filter((m) => !(m.type === 'Thumbnail' && (isFalseThumb({ type: 'Thumbnail', oldId: m.oldId, newId: m.newId }) || badKeys.has(changeKey(m.videoId, m.type, m.at)))));
  await chrome.storage.local.set({
    changeHistory: changeHistory.filter((e) => !isFalseThumb(e)),
    changeMarks: marksLeft,
    changeQueue: changeQueue.filter((e) => !isFalseThumb(e)),
  });
  let archived = 0, archiveError = null;
  try {
    const cfg = await notionTarget();
    for (const e of bad) archived += await archiveRows({ ...cfg, videoId: e.videoId, at: e.detectedAt });
  } catch (e) { archiveError = describeError(e); }
  return { events: bad.length, marks: changeMarks.length - marksLeft.length, archived, archiveError };
}

// ---- open a video in Studio under the right account ---------------------------------------------
// Studio opens under whatever Google account / brand channel it last used and errors ("Oops") on a
// video from another one; its URLs ignore `authuser`. YouTube's own switcher URL does switch both, so:
// hop 1 = the switcher (lands on youtube.com as that channel), hop 2 = the video's Studio edit page in
// the same tab. Channels without a stored page id / account index open the edit page directly.
// Opening a video in Studio under the right identity. Strategies, tried in order until Studio shows the
// editor rather than "Oops, something went wrong" (checked in the tab):
//   switch   — YouTube's account switcher with the page id + account index, then the edit page (brand accounts)
//   channel  — switcher with the account index, Studio's channel page (sets the channel context for channels
//              shared through Channel permissions, which have no page id), then the edit page
//   authuser — the edit page with ?authuser=N, no switch
//   direct   — the edit page as is
// The strategy that worked is remembered per channel (storage.sync link `openMode`) and tried first next time.
const OPEN_WAIT_MS = 15_000;
const studioChannelUrl = (channelId) => `https://studio.youtube.com/channel/${channelId}/videos/upload`;
async function waitForLoad(tabId, urlRe, timeoutMs = OPEN_WAIT_MS) {
  return new Promise((resolve) => {
    let done = false;
    const finish = (timedOut, url) => { if (done) return; done = true; chrome.tabs.onUpdated.removeListener(onUpdated); clearTimeout(timer); resolve({ timedOut, url: url ?? null }); };
    const onUpdated = (id, info, t) => { if (id === tabId && info.status === 'complete' && urlRe.test(t?.url ?? '')) finish(false, t.url); };
    chrome.tabs.onUpdated.addListener(onUpdated);
    const timer = setTimeout(() => chrome.tabs.get(tabId).then((t) => finish(true, t?.url), () => finish(true, null)), timeoutMs);
  });
}
// Did Studio render the editor? Looks at the loaded page: the error screen, or a channel id that is not ours.
async function studioOk(tabId, channelId) {
  await new Promise((r) => setTimeout(r, 1200));   // Studio renders after load
  try {
    const [r] = await chrome.scripting.executeScript({ target: { tabId }, world: 'MAIN', args: [channelId], func: (want) => {
      const text = document.body?.innerText ?? '';
      if (/oops, something went wrong|something went wrong/i.test(text) && !document.querySelector('ytcp-video-metadata-editor, #video-title, ytcp-video-title')) return { ok: false, why: 'error screen' };
      const cfg = globalThis.ytcfg?.data_ ?? {};
      const cid = cfg.CHANNEL_ID ?? cfg.DELEGATED_CHANNEL_ID ?? null;
      if (cid && want && cid !== want) return { ok: false, why: `Studio is on channel ${cid}` };
      return { ok: true, why: null };
    } });
    return r?.result ?? { ok: true, why: 'no result' };
  } catch (e) { return { ok: true, why: `could not inspect: ${e?.message ?? e}` }; }
}
async function openVideo({ videoId, channelId }) {
  const ch = (await channelList()).find((c) => c.channelId === channelId);
  const edit = studioEditUrl(videoId);
  const hasAcct = ch?.authUser !== undefined && ch?.authUser !== null && ch?.authUser !== '';
  const { channels: links = [] } = await chrome.storage.sync.get('channels');
  const link = links.find((l) => l.channelId === channelId);
  const all = [
    ch?.pageId ? 'switch' : null,
    hasAcct ? 'channel' : null,
    hasAcct ? 'authuser' : null,
    'direct',
  ].filter(Boolean);
  const order = link?.openMode && all.includes(link.openMode) ? [link.openMode, ...all.filter((m) => m !== link.openMode)] : all;
  const diag = { at: Date.now(), channelId, videoId, pageId: ch?.pageId ?? null, authUser: ch?.authUser ?? null, verified: Boolean(ch?.verified), attempts: [], mode: null };
  const tab = await chrome.tabs.create({ url: 'about:blank' });
  for (const mode of order) {
    const t0 = Date.now();
    let landed = null;
    if (mode === 'switch') {
      await chrome.tabs.update(tab.id, { url: switchUrl(ch) });
      landed = await waitForLoad(tab.id, /^https:\/\/www\.youtube\.com\//);
      await new Promise((r) => setTimeout(r, 500));
      await chrome.tabs.update(tab.id, { url: edit });
    } else if (mode === 'channel') {
      await chrome.tabs.update(tab.id, { url: switchUrl({ authUser: ch.authUser }) });
      landed = await waitForLoad(tab.id, /^https:\/\/www\.youtube\.com\//);
      await chrome.tabs.update(tab.id, { url: studioChannelUrl(channelId) });
      await waitForLoad(tab.id, /^https:\/\/studio\.youtube\.com\//);
      await chrome.tabs.update(tab.id, { url: edit });
    } else if (mode === 'authuser') {
      await chrome.tabs.update(tab.id, { url: `${edit}&authuser=${encodeURIComponent(ch.authUser)}` });
    } else {
      await chrome.tabs.update(tab.id, { url: edit });
    }
    const final = await waitForLoad(tab.id, /^https:\/\/studio\.youtube\.com\//);
    const check = mode === 'direct' ? { ok: true, why: 'last resort' } : await studioOk(tab.id, channelId);
    diag.attempts.push(`${mode}: ${check.ok ? 'OK' : check.why}${landed?.timedOut || final.timedOut ? ' (a load timed out)' : ''} in ${((Date.now() - t0) / 1000).toFixed(1)} s`);
    if (check.ok) {
      diag.mode = mode;
      if (link && link.openMode !== mode) { link.openMode = mode; await chrome.storage.sync.set({ channels: links }); }
      break;
    }
  }
  await chrome.storage.local.set({ lastOpen: diag });
  return { switched: diag.mode !== 'direct', ...diag };
}

// ---- Studio packaging panel: "Final Packaging" of the video's Notion ideation page ------------------
// The content script (studio-packaging.js) asks for a video by id; the answer is the parsed section, cached
// 10 minutes (the image URLs Notion signs expire after ~1 h, so also refetched when one is about to).
const PACKAGING_MS = 10 * 60_000, PACKAGING_IMG_MARGIN_MS = 5 * 60_000, PACKAGING_VERSION = 5;   // bump when the parser changes → cached results are dropped
async function packagingFor({ videoId, pageTitle = null, force = false }) {
  const registry = await loadRegistry();
  let entry = null, channelId = null;
  for (const [cid, m] of Object.entries(registry)) if (m[videoId]) { entry = m[videoId]; channelId = cid; break; }
  if (!entry) {   // not in the shared registry: maybe the ClickUp task already carries this video's URL
    const { cuVideos = {} } = await chrome.storage.local.get('cuVideos');
    for (const [cid, v] of Object.entries(cuVideos)) { const t = (v.videos ?? []).find((x) => x.videoId === videoId); if (t) { entry = { id: t.dfmId, notionUrl: t.ideationUrl, title: t.title }; channelId = cid; break; } }
  }
  if (!entry) return { ok: false, reason: 'not-tracked' };
  if (!entry.notionUrl || !notionPageIdFromUrl(entry.notionUrl)) return { ok: false, reason: 'no-notion-link', dfmId: entry.id ?? null };
  const cfg = await notionConfig();
  if (!cfg.token) return { ok: false, reason: 'no-token' };
  const { packaging = {} } = await chrome.storage.local.get('packaging');
  const cached = packaging[videoId];
  const soon = Date.now() + PACKAGING_IMG_MARGIN_MS;
  if (!force && cached && cached.v === PACKAGING_VERSION && Date.now() - cached.at < PACKAGING_MS && !(cached.data.thumbnails ?? []).some((t) => t.expiresAt && t.expiresAt < soon)) return cached.data;
  const token = cfg.token, pageId = notionPageIdFromUrl(entry.notionUrl);
  const top = await blockChildren({ token, blockId: pageId });
  const fp = top.find(isFinalPackaging);
  if (!fp) return { ok: false, reason: 'no-final-packaging', notionUrl: entry.notionUrl, dfmId: entry.id ?? null };
  const videos = (await blockChildren({ token, blockId: fp.id })).filter((b) => headingLevel(b));
  const head = findVideoHeading(videos, { dfmId: entry.id, title: pageTitle ?? entry.title });
  if (!head) return { ok: false, reason: 'video-not-in-packaging', notionUrl: entry.notionUrl, dfmId: entry.id ?? null, available: videos.map(blockText).slice(0, 12) };
  const parts = (await blockChildren({ token, blockId: head.id })).filter((b) => headingLevel(b));
  // Children, with nested blocks attached (grouped title lists, images inside columns/toggles), two levels deep.
  const NESTABLE = new Set(['bulleted_list_item', 'numbered_list_item', 'toggle', 'column_list', 'column', 'callout', 'quote', 'paragraph', 'heading_1', 'heading_2', 'heading_3']);
  const deep = async (blockId, depth) => {
    const blocks = await blockChildren({ token, blockId });
    if (depth > 0) await Promise.all(blocks.map(async (b) => { if (b.has_children && NESTABLE.has(b.type)) b.children = await deep(b.id, depth - 1); }));
    return blocks;
  };
  const kids = async (h) => (h ? deep(h.id, 3) : []);
  const [thumbs, titles, desc] = await Promise.all([kids(findSection(parts, SECTION.thumbnails)), kids(findSection(parts, SECTION.titles)), kids(findSection(parts, SECTION.description))]);
  const data = {
    ok: true, videoId, channelId, channelInitials: (await channelList()).find((c) => c.channelId === channelId)?.initials ?? null, dfmId: entry.id ?? null, heading: blockText(head).replace(/\*\*/g, '').trim(), notionUrl: entry.notionUrl,
    pageUrl: `${entry.notionUrl.split('#')[0].split('?')[0]}#${head.id.replace(/-/g, '')}`,
    titles: parseTitles(titles), thumbnails: parseThumbnails(thumbs), description: parseDescription(desc), at: Date.now(),
  };
  packaging[videoId] = { at: Date.now(), v: PACKAGING_VERSION, data };
  for (const [k, v] of Object.entries(packaging)) if (Date.now() - v.at > 6 * 3_600_000) delete packaging[k];   // keep the cache small
  await chrome.storage.local.set({ packaging });
  return data;
}
// The popup row for one video (thumbnail, id label, trend / 48 h / total, bars and marks) from the last
// snapshot — the Studio card shows it above the packaging so the editor sees the video's evolution.
async function realtimeFor({ videoId }) {
  const { snapshot, thumbs = {}, changeMarks: localMarks = [], sharedMarks = [], testMarks = [], experiments = {} } = await chrome.storage.local.get(['snapshot', 'thumbs', 'changeMarks', 'sharedMarks', 'testMarks', 'experiments']);
  const changeMarks = [...localMarks, ...sharedMarks];
  const reply = snapshot?.reply;
  if (!reply?.signedIn) return { ok: false, reason: 'no-snapshot' };
  for (const r of reply.results ?? []) {
    if (!r.ok) continue;
    const v = (r.data.videos ?? []).find((x) => x.videoId === videoId);
    if (!v) continue;
    const registry = await loadRegistry();
    const entry = registry[r.channelId]?.[videoId] ?? null;
    const ch = (await channelList()).find((c) => c.channelId === r.channelId);
    const now = Date.now();
    const marks = [
      ...changeMarks.filter((m) => m.videoId === videoId).map((m) => ({ type: m.type, at: m.at, by: m.by ?? null, oldTitle: m.oldTitle ?? null, newTitle: m.newTitle ?? null, oldImage: m.oldImage ?? null, newImage: m.newImage ?? null })),
      ...testMarks.filter((m) => m.videoId === videoId && m.type === 'TestStarted').map((m) => ({ type: 'Test', at: m.at, state: experiments[videoId]?.state === 'running' ? 'running' : 'finished', experiment: experiments[videoId] ?? null })),
    ];
    const label = entry?.id && /^\d{1,4}$/.test(entry.id) && ch?.initials ? `${ch.initials} LF ${entry.id}` : (entry?.id ?? null);
    return {
      ok: true, videoId, channelLabel: ch?.label ?? r.label, label, title: v.title ?? null, thumbnail: thumbs[videoId]?.dataUrl ?? v.thumbnail ?? null,
      views48h: v.views48h ?? 0, lifetimeViews: v.lifetimeViews ?? null, bars: v.bars ?? [], trend: trendOf(v.bars ?? [], now), marks,
      night: (v.bars ?? []).map((b) => isNightHour(b.startTime)), updatedAt: snapshot.at ?? null,
    };
  }
  return { ok: false, reason: 'not-in-snapshot' };
}
// The panel's content script is always on (independent of Capture mode); registered idempotently.
const PACKAGING_SCRIPT = { id: 'sr-packaging', js: ['studio-packaging.js'], matches: ['https://studio.youtube.com/*'], runAt: 'document_idle', world: 'ISOLATED', persistAcrossSessions: true };
async function ensurePackagingScript() {
  try {
    const regs = await chrome.scripting.getRegisteredContentScripts({ ids: [PACKAGING_SCRIPT.id] });
    if (!regs.length) await chrome.scripting.registerContentScripts([PACKAGING_SCRIPT]);
    else await chrome.scripting.updateContentScripts([PACKAGING_SCRIPT]);
  } catch { /* older Chrome without the API: the panel is simply absent */ }
}
chrome.runtime.onInstalled.addListener(ensurePackagingScript);
chrome.runtime.onStartup.addListener(ensurePackagingScript);

// ---- capture mode ----------------------------------------------------------------------------
const CAPTURE_SCRIPTS = [
  { id: 'sr-capture-hook', js: ['capture-hook.js'], matches: ['https://studio.youtube.com/*'], runAt: 'document_start', world: 'MAIN', persistAcrossSessions: true },
  { id: 'sr-capture-bridge', js: ['capture-bridge.js'], matches: ['https://studio.youtube.com/*'], runAt: 'document_start', world: 'ISOLATED', persistAcrossSessions: true },
];
const CAPTURE_IDS = CAPTURE_SCRIPTS.map((s) => s.id);

async function captureEnabled() {
  const regs = await chrome.scripting.getRegisteredContentScripts({ ids: CAPTURE_IDS });
  return regs.length === CAPTURE_SCRIPTS.length;
}
async function setCaptureMode(enabled) {
  const on = await captureEnabled();
  if (enabled && !on) await chrome.scripting.registerContentScripts(CAPTURE_SCRIPTS);
  if (!enabled && on) await chrome.scripting.unregisterContentScripts({ ids: CAPTURE_IDS });
  return captureEnabled();
}
async function captureStatus() {
  const { captures = [] } = await chrome.storage.local.get('captures');
  const byEndpoint = {};
  for (const c of captures) byEndpoint[c.endpoint] = (byEndpoint[c.endpoint] ?? 0) + 1;
  return { enabled: await captureEnabled(), count: captures.length, byEndpoint };
}

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg?.type === 'PING') { sendResponse({ ok: true }); return false; }
  (async () => {
    try {
      switch (msg?.type) {
        case 'FETCH_ALL': { await ensureAlarm().catch(() => {}); sendResponse(await runFetch({ forceLink: true })); break; }
        case 'PRIME': {   // popup with no channel added yet: clients, shared list and account links, no video fetch
          await ensureAlarm().catch(() => {});
          await refreshClients().catch(() => {});
          await refreshTracked().catch(() => {});
          await discoverLinks({ force: true }).catch(() => {});
          await autoLink(await channelList()).catch(() => {});
          await refreshSharedMarks().catch(() => {});
          sendResponse({ ok: true }); break;
        }
        case 'CAPTURE_STATUS': sendResponse(await captureStatus()); break;
        case 'CHANGES_STATUS': sendResponse(await changeStatus()); break;
        case 'NOTION_CREATE_TRACKED': {
          const cfg = await notionConfig();
          if (!cfg.token) { sendResponse({ ok: false, error: 'Notion token not set' }); break; }
          if (cfg.trackedDatabaseId && cfg.trackedDatabaseId !== DEFAULT_TRACKED_DATABASE_ID) { sendResponse({ ok: false, error: 'a Tracked videos database id is already set — clear it first to create a new one' }); break; }
          try {
            const made = await createTrackedDatabase({ token: cfg.token, besideDatabaseId: cfg.databaseId || DEFAULT_DATABASE_ID });
            const { notion = {} } = await chrome.storage.local.get('notion');
            await chrome.storage.local.set({ notion: { ...notion, trackedDatabaseId: made.databaseId, trackedDataSourceId: made.dataSourceId } });
            await flushShared().catch(() => {});
            await refreshTracked().catch(() => {});
            sendResponse({ ok: true, ...made });
          } catch (e) { sendResponse({ ok: false, error: describeError(e) }); }
          break;
        }
        case 'NOTION_SAVE': {
          const { notion = {} } = await chrome.storage.local.get('notion');
          const dbChanged = msg.databaseId !== undefined && msg.databaseId !== notion.databaseId;
          const trackedChanged = msg.trackedDatabaseId !== undefined && msg.trackedDatabaseId !== notion.trackedDatabaseId;
          await chrome.storage.local.set({ notion: { ...notion, ...(msg.token !== undefined ? { token: msg.token } : {}), ...(msg.databaseId !== undefined ? { databaseId: msg.databaseId } : {}), ...(dbChanged ? { dataSourceId: null, types: null } : {}),
            ...(msg.trackedDatabaseId !== undefined ? { trackedDatabaseId: msg.trackedDatabaseId || null } : {}), ...(trackedChanged ? { trackedDataSourceId: null } : {}) } });
          sendResponse(await changeStatus()); break;
        }
        case 'NOTION_TEST': {
          try {
            const cfg = await notionConfig();
            if (!cfg.token) throw new Error('Notion token not set');
            const r = await resolveDatabase(cfg);
            const { notion = {} } = await chrome.storage.local.get('notion');
            await chrome.storage.local.set({ notion: { ...notion, dataSourceId: r.dataSourceId } });
            const { added, types, legacy } = await ensureSchema({ ...cfg, dataSourceId: r.dataSourceId });   // fresh database → create the columns; remember the real types
            await rememberTypes(types);
            const rel = await ensureRelation({ force: true }).catch(() => null);
            if (rel?.added?.length) added.push(...rel.added);
            sendResponse({ ...r, added, legacy });
          } catch (e) { sendResponse({ ok: false, error: describeError(e) }); }
          break;
        }
        case 'NOTION_TEST_ROW': {
          try { const { page, warning } = await postChangeSafely({ ...(await notionTarget()), event: testEvent() }); sendResponse({ ok: true, url: page.url ?? null, warning: warning ?? null }); }
          catch (e) { sendResponse({ ok: false, error: describeError(e) }); }
          break;
        }
        case 'PURGE_FALSE': {
          try { sendResponse(await purgeFalseThumbnails()); }
          catch (e) { sendResponse({ error: describeError(e) }); }
          break;
        }
        case 'NOTION_RESYNC': {
          try { await resync(); sendResponse(await changeStatus()); }
          catch (e) { sendResponse({ ...(await changeStatus()), error: describeError(e) }); }
          break;
        }
        case 'RENAME': await queueRename(String(msg.videoId), String(msg.name)); sendResponse(await changeStatus()); break;
        case 'CHANNELS': { const { linkDiag = null, lastOpen = null } = await chrome.storage.local.get(['linkDiag', 'lastOpen']); sendResponse({ channels: await channelList(), linkDiag, lastOpen }); break; }
        case 'TRACKED': { await refreshTracked().catch(() => {}); const { tracked = {} } = await chrome.storage.local.get('tracked'); sendResponse({ tracked }); break; }
        case 'TRACK': sendResponse(await followVideo(msg)); break;                 // follow (manual) + registry entry
        case 'UNTRACK': sendResponse(await unfollowVideo(msg)); break;
        case 'REGISTRY': sendResponse({ tracked: await setRegistry(msg) }); break;   // DFM ID / batch link only (both modes)
        case 'CLICKUP_TASKS': sendResponse(await clickupTasksFor(msg)); break;
        case 'CLICKUP_LINK': sendResponse(await linkClickupTask(msg)); break;
        case 'CLICKUP_SAVE': {
          const { clickup = {} } = await chrome.storage.local.get('clickup');
          await chrome.storage.local.set({ clickup: { ...clickup, ...(msg.token !== undefined ? { token: msg.token } : {}), ...(msg.listId !== undefined ? { listId: msg.listId } : {}) } });
          sendResponse({ ok: true }); break;
        }
        case 'CLICKUP_STATUS': {
          const cfg = await clickupConfig();
          const { clickupStatus = null } = await chrome.storage.local.get('clickupStatus');
          sendResponse({ configured: Boolean(cfg.token), listId: cfg.listId, managed: cfg.managed, ...(clickupStatus ?? {}) }); break;
        }
        case 'CLICKUP_TEST': {
          try { const st = await refreshClients(); sendResponse(st ? { ok: true, ...st } : { ok: false, error: 'ClickUp token not set' }); }
          catch (e) { const { clickupStatus = {} } = await chrome.storage.local.get('clickupStatus'); await chrome.storage.local.set({ clickupStatus: { ...clickupStatus, error: describeError(e) } }); sendResponse({ ok: false, error: describeError(e) }); }
          break;
        }
        case 'REALTIME_FOR': {   // Studio card: the video's row from the last snapshot
          try { sendResponse(await realtimeFor({ videoId: String(msg.videoId) })); } catch (e) { sendResponse({ ok: false, reason: 'error', error: e?.message ?? String(e) }); }
          break;
        }
        case 'PACKAGING_DOWNLOAD': {   // a thumbnail candidate → the Downloads folder, named after the video
          try {
            const url = String(msg.url); const u = new URL(url);
            const ext = (/\.(png|jpe?g|webp|gif)$/i.exec(u.pathname) ?? [])[1] ?? 'png';
            const safe = (x) => String(x ?? '').replace(/[^\w.-]+/g, '_').replace(/^_+|_+$/g, '');
            const filename = `DFM packaging/${safe(msg.label ?? 'video')}/thumbnail-${String(msg.index ?? 1).padStart(2, '0')}.${ext}`;
            const id = await chrome.downloads.download({ url, filename, saveAs: false, conflictAction: 'uniquify' });
            sendResponse({ ok: true, id, filename });
          } catch (e) { sendResponse({ ok: false, error: e?.message ?? String(e) }); }
          break;
        }
        case 'PACKAGING_FOR': {   // from the Studio content script (or the popup)
          const fromStudio = /^https:\/\/studio\.youtube\.com\//.test(_sender?.tab?.url ?? '') || !_sender?.tab;
          if (!fromStudio) { sendResponse({ ok: false, reason: 'forbidden' }); break; }
          try { sendResponse(await packagingFor({ videoId: String(msg.videoId), pageTitle: msg.pageTitle ?? null, force: Boolean(msg.force) })); }
          catch (e) { sendResponse({ ok: false, reason: 'error', error: describeError(e) }); }
          break;
        }
        case 'OPEN_VIDEO': sendResponse(await openVideo({ videoId: String(msg.videoId), channelId: String(msg.channelId) })); break;
        case 'CAPTURE_MODE': sendResponse({ enabled: await setCaptureMode(!!msg.enabled) }); break;
        case 'CAPTURE_CLEAR': await chrome.storage.local.remove('captures'); sendResponse(await captureStatus()); break;
        default: sendResponse({ error: `unknown message ${msg?.type}` });
      }
    } catch (e) {
      sendResponse(msg?.type === 'FETCH_ALL' ? { signedIn: true, results: [], fatal: e?.message ?? String(e) } : { error: e?.message ?? String(e) });
    }
  })();
  return true; // async sendResponse
});
