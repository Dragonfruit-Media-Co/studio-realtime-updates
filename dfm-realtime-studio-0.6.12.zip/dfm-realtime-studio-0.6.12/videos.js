import { ShapeError } from './errors.js';

// Shape observed in fixtures/list_creator_videos.json (2026-09-05):
//   videos[].{videoId, title, privacy, status, timePublishedSeconds, lengthSeconds, publicShorts, thumbnailDetails, thumbnailEditorState, publicMetrics}
//   videosTotalSize.size → estimated count of videos matching the filter (string)
// The request already filters to public uploads without Shorts; the parser re-checks privacy and a
// real publish time so a draft or scheduled video slipping through the filter can't produce a row.

// The 320 px variant (mqdefault): big enough for the popup and the Notion attachment, ~20 KB.
export function pickThumbnail(thumbnails, minWidth = 320) {
  const list = (thumbnails ?? []).filter((t) => t?.url);
  if (!list.length) return null;
  const fit = list.filter((t) => (t.width ?? 0) >= minWidth).sort((a, b) => a.width - b.width)[0];
  return (fit ?? list.sort((a, b) => (b.width ?? 0) - (a.width ?? 0))[0]).url;
}

const need = (v, path) => { if (v === undefined || v === null) throw new ShapeError(path); return v; };
const num = (v) => (v === undefined || v === null || v === '' ? null : Number(v));

export function parseVideoList(json) {
  const rows = need(json?.videos, 'videos');
  const videos = rows
    .map((v) => ({
      videoId: v?.videoId,
      title: v?.title ?? null,
      publishedAt: num(v?.timePublishedSeconds) ? Number(v.timePublishedSeconds) * 1000 : null,
      lengthSeconds: num(v?.lengthSeconds),
      isShort: v?.publicShorts?.isShortsRenderable === true,
      // publicMetrics carries two counters: externalViewCount is the public one (youtube.com, same
      // EXTERNAL_VIEWS metric as the realtime bars); viewCount is Studio's internal figure, which lags
      // by days (12,535 vs 28,858 on the same video in the 2026-09-05 capture).
      lifetimeViews: num(v?.publicMetrics?.externalViewCount) ?? num(v?.publicMetrics?.viewCount) ?? 0,
      thumbnail: pickThumbnail(v?.thumbnailDetails?.thumbnails),
      // Stable id of the custom thumbnail image; changes when a new thumbnail is uploaded. The URL's
      // `v=` hash changes too, but this is the direct signal. Null for auto-generated stills.
      thumbnailId: v?.thumbnailEditorState?.customThumbnail?.externalImageId ?? null,
      privacy: v?.privacy ?? null,
    }))
    .filter((v) => v.videoId && v.publishedAt && (v.privacy === null || v.privacy === 'VIDEO_PRIVACY_PUBLIC'))
    .sort((a, b) => b.publishedAt - a.publishedAt);
  const total = num(json.videosTotalSize?.size);
  return { videos, total };
}

// The upload list decides WHICH videos get a row; the realtime card (cards.parseRealtime) supplies
// the 48 h series for those it knows about. A listed video the card doesn't mention had no views
// in the window — it gets zero bars on the channel's hour grid so every row shares one x-axis.
// list = parseVideoList() output; realtime = parseRealtime() output.
export function joinRealtime(list, realtime) {
  const byId = new Map(realtime.videos.map((v) => [v.videoId, v]));
  const zeroBars = () => realtime.bars.map((b) => ({ startTime: b.startTime, views: 0 }));

  const videos = list.videos.map((v) => {
    const rt = byId.get(v.videoId);
    return {
      videoId: v.videoId,
      title: v.title ?? rt?.title ?? null,
      publishedAt: v.publishedAt ?? rt?.publishedAt ?? null,
      thumbnail: v.thumbnail ?? rt?.thumbnail ?? null,
      thumbnailId: v.thumbnailId ?? null,
      lengthSeconds: v.lengthSeconds ?? rt?.lengthSeconds ?? null,
      lifetimeViews: v.lifetimeViews,
      isShort: v.isShort,
      inRealtime: Boolean(rt),
      views48h: rt?.views48h ?? 0,
      bars: rt?.bars ?? zeroBars(),
    };
  });

  const listed = new Set(list.videos.map((v) => v.videoId));
  const unlisted = realtime.videos.filter((v) => !listed.has(v.videoId));
  return {
    videos,
    listTotal: list.total,
    notListed: unlisted.filter((v) => !v.isShort).length,   // older long-form uploads with views
    shortsWithViews: unlisted.filter((v) => v.isShort).length,
  };
}
