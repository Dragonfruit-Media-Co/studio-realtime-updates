// Impact of a title / thumbnail change on views, pure. The worker keeps an hourly view history per
// followed video (merged from the 48 h realtime bars each check, 30 days deep) and scores every change
// against it: the completed hours AFTER the change, in 3-hour steps, versus the SAME number of hours
// BEFORE it. A change 3 days old is compared with the 3 days before it (when the history reaches that
// far). Scoring stops at the next change on the same video — from then on the score is final.
import { MIN_HOURLY_VIEWS } from './trend.js';

export const HOUR_MS = 3_600_000;
export const STEP_HOURS = 3;                       // same rhythm as the grace period after a change
export const HISTORY_KEEP_MS = 30 * 86_400_000;
export const MAX_HOURS = 30 * 24;

// history: [[startTime, views], …] sorted ascending, one entry per hour. bars: [{ startTime, views }].
// Later bars win (the hour in progress is re-read every check until it completes).
export function mergeHistory(history = [], bars = [], now = Date.now()) {
  const map = new Map(history);
  for (const b of bars ?? []) if (b && Number.isFinite(b.startTime) && Number.isFinite(b.views)) map.set(b.startTime, b.views);
  return [...map.entries()].filter(([t]) => now - t < HISTORY_KEEP_MS).sort((a, b) => a[0] - b[0]);
}

// The next change on the same video after `m` (any type) — it ends m's measuring window. null if none.
export function nextChangeAt(marks, m) {
  let next = null;
  for (const o of marks ?? []) {
    if (o.videoId !== m.videoId || !(o.type === 'Title' || o.type === 'Thumbnail') || o.at <= m.at) continue;
    if (next === null || o.at < next) next = o.at;
  }
  return next;
}

const floorHour = (ms) => Math.floor(ms / HOUR_MS) * HOUR_MS;
const sum = (history, from, to) => {   // hours with startTime in [from, to)
  let views = 0, hours = 0;
  for (const [t, v] of history) if (t >= from && t < to) { views += v; hours++; }
  return { views, hours };
};

// at: when the change was detected. until: the next change on the video (null = none yet).
// Returns null when there is no history for the video at all. Otherwise:
//   { hours, pending, hoursSoFar, before, after, beforeHours, afterHours, perHourBefore, perHourAfter,
//     deltaPct, partial, weak, final }
//   hours       completed hours scored after the change, a multiple of 3 (0 while pending)
//   before/after  views in the two windows; beforeHours/afterHours the hours the history actually had
//   deltaPct    change in views PER HOUR, after vs before (null when nothing before)
//   partial     the before window is shorter than the after window (video too young / history too short)
//   weak        under MIN_HOURLY_VIEWS per hour before the change — shown, not to be ranked
//   final       another change followed: this score will not grow any more
export function scoreImpact(history, { at, now = Date.now(), until = null, minViewsPerHour = MIN_HOURLY_VIEWS } = {}) {
  if (!history?.length || !Number.isFinite(at)) return null;
  const changeHour = floorHour(at);
  const afterStart = changeHour + HOUR_MS;                       // the hour of the change itself is mixed: skipped
  const end = Math.min(floorHour(now), until !== null ? floorHour(until) : Infinity);
  const hoursSoFar = Math.max(0, Math.round((end - afterStart) / HOUR_MS));
  const final = until !== null && until <= now;
  const hours = Math.min(MAX_HOURS, Math.floor(hoursSoFar / STEP_HOURS) * STEP_HOURS);
  if (hours === 0) return { hours: 0, pending: !final, hoursSoFar, final, before: null, after: null, beforeHours: 0, afterHours: 0, perHourBefore: null, perHourAfter: null, deltaPct: null, partial: false, weak: false };
  const after = sum(history, afterStart, afterStart + hours * HOUR_MS);
  const before = sum(history, changeHour - hours * HOUR_MS, changeHour);
  const perHourAfter = after.hours ? after.views / after.hours : null;
  const perHourBefore = before.hours ? before.views / before.hours : null;
  const deltaPct = perHourBefore && perHourAfter !== null ? Math.round(((perHourAfter - perHourBefore) / perHourBefore) * 100) : null;
  return {
    hours, pending: false, hoursSoFar, final,
    before: before.views, after: after.views, beforeHours: before.hours, afterHours: after.hours,
    perHourBefore, perHourAfter, deltaPct,
    partial: before.hours < hours,
    weak: perHourBefore === null || perHourBefore < minViewsPerHour,
  };
}

// One line for the hover cards (popup and Studio strip). fmt: number formatter.
export function impactText(imp, fmt = new Intl.NumberFormat()) {
  if (!imp) return null;
  if (imp.hours === 0) return imp.final ? 'Impact · another change followed within 3 h — not measurable' : `Impact · measuring, first read 3 h after the change (${imp.hoursSoFar} h so far)`;
  const span = imp.hours % 24 === 0 ? `${imp.hours / 24} d` : `${imp.hours} h`;
  const delta = imp.deltaPct === null ? 'no views before to compare' : `${imp.deltaPct > 0 ? '+' : ''}${imp.deltaPct}% per hour`;
  const notes = [imp.partial ? `only ${imp.beforeHours} h of history before` : null, imp.weak ? 'low volume' : null, imp.final ? 'final — another change followed' : null].filter(Boolean);
  return `Impact · ${span} after: ${fmt.format(imp.after)} views vs ${fmt.format(imp.before)} in the ${span} before · ${delta}${notes.length ? ` (${notes.join(', ')})` : ''}`;
}
