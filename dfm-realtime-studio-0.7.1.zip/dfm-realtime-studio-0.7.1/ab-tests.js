// YouTube "Test & compare" (A/B tests) history, pure apart from the Notion/fetch functions at the end.
//
// experiments.js normalises what Studio returns for a video — ONE test per video, the current one. This
// module keeps every test we have seen, so a test that was stopped and replaced between two polls keeps
// its arms and its last watch-time shares:
//   chrome.storage.local.testHistory = { [key]: record }, key = testKey(videoId, startedAt)
//   record = { key, videoId, channelId, state, rawState, finishedReason, resultState, hasTitles, hasThumbnails,
//              startedAt, finishedAt, expectedFinishAt, detectedAt, lastSeenAt, endedAt,
//              arms: [{ index, label, title, thumbnail, share, image }], imageTries, sharesAt,
//              winnerArm, selectedArm, pageId, written: { state, sharesAt } | null }
// state: running | finished (ran its course) | stopped (the user ended it) | superseded (vanished
// between polls — replaced by a new test or deleted; its last shares are kept).
// Shares: a fresh payload overwrites `share` only when it carries at least one number; YouTube dropping
// the numbers for a check (or for the stopped state) never erases the last ones seen. `sharesAt` says when.
// Each record is also a row in the Notion change log (`Change = Test`), created once with the arm images
// and updated in place when its state or `sharesAt` changes — `pageId` / `written` remember what the row holds.

import { fetchThumbnail } from './thumbs.js';
import { NOTION_API, headers, send, text, title, url, date, number, select, externalFile, uploadedFile, shapeToTypes, findByKey, uploadImage, studioEditUrl, RELATION_COLUMN } from './notion.js';

export const TEST_KEEP_MS = 90 * 86_400_000;   // after the last sighting, like testMarks
const ARM_LETTERS = ['A', 'B', 'C'];

export const testKey = (videoId, startedAt) => `Test:${videoId}:${startedAt ?? 'na'}`;

// running | finished | stopped from a normalised experiment. An unknown live state ('other') is still live.
export function stateOf(x) {
  if (x?.state !== 'finished') return 'running';
  return /STOPPED_BY_USER$/.test(x.finishedReason ?? '') ? 'stopped' : 'finished';
}

const hasNumber = (arms) => (arms ?? []).some((a) => a?.share !== null && a?.share !== undefined);
const sameShares = (a, b) => a.length === b.length && a.every((x, i) => (x?.share ?? null) === (b[i]?.share ?? null));

// history: the stored map. current: { [videoId]: experiment | null } from this check. queried: the video
// ids this check actually got an answer for (a failed chunk keeps the old slot and must not read as "the
// test vanished"). channelOf: { [videoId]: channelId }. seeds: testMarks, to keep the detection time a
// TestStarted mark recorded before this store existed. Returns a new map.
export function updateTestHistory(history, current, { queried = new Set(), channelOf = {}, now = Date.now(), seeds = [] } = {}) {
  const next = {};
  for (const [k, r] of Object.entries(history ?? {})) if (now - (r.lastSeenAt ?? 0) < TEST_KEEP_MS) next[k] = r;

  for (const [videoId, x] of Object.entries(current ?? {})) {
    if (!x) continue;
    const key = testKey(videoId, x.startedAt);
    const prev = next[key];
    const fresh = x.arms ?? [];
    const numbers = hasNumber(fresh);
    const arms = fresh.map((a, i) => ({
      index: a.index ?? i, label: a.label ?? ARM_LETTERS[i] ?? String(i + 1), title: a.title ?? null,
      thumbnail: a.thumbnail ?? prev?.arms?.[i]?.thumbnail ?? null,
      share: numbers ? (a.share ?? null) : (prev?.arms?.[i]?.share ?? null),
      image: prev?.arms?.[i]?.image ?? null,
    }));
    const state = stateOf(x);
    const seed = seeds.find((m) => m.type === 'TestStarted' && m.videoId === videoId && (m.startedAt ?? null) === (x.startedAt ?? null));
    next[key] = {
      key, videoId, channelId: channelOf[videoId] ?? prev?.channelId ?? null,
      state, rawState: x.rawState ?? null, finishedReason: x.finishedReason ?? null, resultState: x.resultState ?? null,
      hasTitles: Boolean(x.hasTitles), hasThumbnails: Boolean(x.hasThumbnails),
      startedAt: x.startedAt ?? null, finishedAt: x.finishedAt ?? prev?.finishedAt ?? null, expectedFinishAt: x.expectedFinishAt ?? prev?.expectedFinishAt ?? null,
      detectedAt: prev?.detectedAt ?? seed?.at ?? now, lastSeenAt: now,
      endedAt: state === 'running' ? null : (prev?.endedAt ?? x.finishedAt ?? now),
      arms, imageTries: prev?.imageTries ?? 0,
      sharesAt: numbers && !(prev && sameShares(prev.arms ?? [], arms)) ? now : (prev?.sharesAt ?? null),   // moves only when the numbers do
      winnerArm: x.winnerArm ?? null, selectedArm: x.selectedArm ?? null,
      pageId: prev?.pageId ?? null, written: prev?.written ?? null,
    };
  }
  // A running test whose video answered this check with a different test (or none) is over.
  for (const r of Object.values(next)) {
    if (r.state !== 'running' || !queried.has(r.videoId)) continue;
    const x = current?.[r.videoId] ?? null;
    if (x && testKey(r.videoId, x.startedAt) === r.key) continue;
    next[r.key] = { ...r, state: 'superseded', endedAt: now };
  }
  return next;
}

// Does the Notion row lag the record? No row yet; its state or shares are older; it was written by an older
// writer (WRITE_VERSION bumps when the row layout changes, e.g. columns that a stale column map dropped);
// or its arm pictures never made it (written.images).
export const WRITE_VERSION = 2;
const wantsImages = (r) => (r.arms ?? []).some((a) => a.image || a.thumbnail);
export const needsWrite = (r) => !r.pageId || !r.written || r.written.v !== WRITE_VERSION || r.written.state !== r.state || r.written.sharesAt !== r.sharesAt || (!r.written.images && wantsImages(r));

// Marks for one video's sparkline: { type: 'Test', videoId, at, experiment } per test, oldest first — a
// running test above the hour it was first seen, an ended one above its end. `experiment` is the record
// with the stored snapshot standing in for each arm's URL. `fallback` = { at, experiment } drawn from the
// single-slot `experiments` store when the history knows nothing about the video (first check after upgrade).
export function testMarksFor(history, videoId, { fallback = null } = {}) {
  const marks = Object.values(history ?? {})
    .filter((r) => r.videoId === videoId)
    .map((r) => ({ type: 'Test', videoId, at: r.state === 'running' ? r.detectedAt : (r.finishedAt ?? r.endedAt ?? r.detectedAt),
      experiment: { ...r, arms: (r.arms ?? []).map((a) => ({ ...a, thumbnail: a.image ?? a.thumbnail ?? null })) } }))
    .sort((a, b) => a.at - b.at);
  if (!marks.length && fallback?.experiment) return [{ type: 'Test', videoId, at: fallback.at, experiment: fallback.experiment }];
  return marks;
}

// ---- Notion: one change-log row per test -------------------------------------------------------------

// Arm thumbnails are served from signed YouTube URLs that stop working after the test, so each arm's
// picture is fetched once (320 px, ~20 KB) and kept on the record as a data URL — the Notion file and the
// hover card come from it. Arms without a picture (title tests) are skipped. A record gives up after
// `maxTries` checks with an arm still missing. Never throws; returns a new map.
export async function snapshotArmImages(history, { fetchImpl = fetch, concurrency = 6, maxTries = 3 } = {}) {
  const next = { ...history };
  const pending = [], jobs = [];
  for (const [key, r] of Object.entries(history ?? {})) {
    const missing = (r.arms ?? []).map((a, i) => (a.thumbnail && a.image === null ? i : -1)).filter((i) => i >= 0);
    if (!missing.length || (r.imageTries ?? 0) >= maxTries) continue;
    const arms = r.arms.map((a) => ({ ...a }));
    pending.push({ key, r, arms });
    for (const i of missing) jobs.push(async () => { try { arms[i].image = (await fetchThumbnail(arms[i].thumbnail, fetchImpl)).dataUrl; } catch { /* next check */ } });
  }
  for (let i = 0; i < jobs.length; i += concurrency) await Promise.all(jobs.slice(i, i + concurrency).map((j) => j()));
  for (const { key, r, arms } of pending) next[key] = { ...r, arms, imageTries: (r.imageTries ?? 0) + 1 };
  return next;
}

const cap = (s) => s.charAt(0).toUpperCase() + s.slice(1);
const kindOf = (r) => (r.hasThumbnails && r.hasTitles ? 'Thumbnail + Title' : r.hasTitles ? 'Title' : 'Thumbnail');
const resultOf = (raw) => (/NOT_ENOUGH_DATA/.test(raw ?? '') ? 'Not enough data' : /NOT_CONCLUSIVE/.test(raw ?? '') ? 'Not conclusive yet' : /NO_WINNER/.test(raw ?? '') ? 'No winner' : /WINNER/.test(raw ?? '') ? 'Winner' : null);
const letter = (i, arms) => (i === null || i === undefined ? 'None' : arms[i]?.label ?? 'None');
const IMAGE_COLUMNS = ARM_LETTERS.map((l) => `Arm ${l} image`);
const IDENTITY_COLUMNS = ['Name', 'Change', 'Change key', 'Detected at', ...IMAGE_COLUMNS];   // written once, never rewritten

// ctx = { dfmId, channelLabel, clientInitials, title, notionUrl, publishedAt, loggedBy, trackedPageId } — the same
// enrichment change events get. uploads = { [armIndex]: fileUploadId } for freshly uploaded arm pictures.
export function testProperties(r, ctx = {}, { types = null, uploads = {} } = {}) {
  const p = {
    Name: title(ctx.dfmId ? String(ctx.dfmId) : r.videoId),
    Change: select('Test'),
    Channel: text(ctx.channelLabel ?? r.channelId ?? ''),
    ...(ctx.clientInitials ? { Client: text(ctx.clientInitials) } : {}),
    'Video ID': text(r.videoId),
    'Change key': text(r.key),
    'Video title': text(ctx.title ?? ''),
    'Video URL': url(`https://www.youtube.com/watch?v=${r.videoId}`),
    'Studio URL': url(studioEditUrl(r.videoId)),
    ...(ctx.notionUrl ? { 'DFM batch': url(ctx.notionUrl) } : {}),
    'Detected at': date(r.detectedAt),
    ...(ctx.publishedAt ? { 'Published at': date(ctx.publishedAt) } : {}),
    ...(ctx.loggedBy ? { 'Logged by': text(ctx.loggedBy) } : {}),
    ...(ctx.trackedPageId ? { [RELATION_COLUMN]: { relation: [{ id: ctx.trackedPageId }] } } : {}),
    'Test kind': select(kindOf(r)),
    'Test state': select(cap(r.state)),
    ...(r.startedAt ? { 'Test started': date(r.startedAt) } : {}),
    ...(r.state !== 'running' && r.endedAt ? { 'Test ended': date(r.endedAt) } : {}),
    Arms: number((r.arms ?? []).length),
    Winner: select(letter(r.winnerArm, r.arms ?? [])),
    Kept: select(letter(r.selectedArm, r.arms ?? [])),
    ...(r.sharesAt ? { 'Shares at': date(r.sharesAt) } : {}),
  };
  const result = resultOf(r.resultState);
  if (result) p.Result = select(result);
  (r.arms ?? []).forEach((a, i) => {
    const l = ARM_LETTERS[i]; if (!l) return;
    if (uploads[i]) p[`Arm ${l} image`] = { files: [uploadedFile(uploads[i], l)] };
    else if (a.thumbnail) p[`Arm ${l} image`] = { files: [externalFile(a.thumbnail, l)] };
    if (a.title) p[`Arm ${l} title`] = text(a.title);
    if (a.share !== null && a.share !== undefined) p[`Arm ${l} share %`] = number(a.share);
  });
  return shapeToTypes(p, types);
}

const takesImage = (types, col) => types === null || types[col]?.type === 'files';

// Create the test's row (arm pictures uploaded) or update the one that exists — the record's own pageId,
// else a row another install wrote with the same key. Updates leave the identity columns alone; the arm
// pictures are added on an update only to repair our own row that got none (older writer, or the image
// columns did not exist yet). Returns { pageId, images } — images: the row now holds every picture it can
// (true too when the test has none). Throws on HTTP errors so the caller keeps the record dirty.
export async function postTest({ token, dataSourceId, record, ctx = {}, types = null, fetchImpl = fetch }) {
  if (!dataSourceId) throw new Error('data source not resolved — run Test connection');
  let pageId = record.pageId ?? null;
  if (!pageId) { try { pageId = await findByKey({ token, dataSourceId, key: record.key, fetchImpl }); } catch { pageId = null; } }
  const withPictures = !pageId || (record.pageId && !record.written?.images && wantsImages(record));
  const uploads = {};
  if (withPictures) {
    for (const [i, a] of (record.arms ?? []).entries()) {
      if (a.image && takesImage(types, IMAGE_COLUMNS[i])) uploads[i] = await uploadImage({ token, dataUrl: a.image, filename: `${record.videoId}-arm-${ARM_LETTERS[i] ?? i}.${/^data:image\/webp/.test(a.image) ? 'webp' : /^data:image\/png/.test(a.image) ? 'png' : 'jpg'}`, fetchImpl });
    }
  }
  const props = testProperties(record, ctx, { types, uploads });
  if (pageId) {
    for (const k of IDENTITY_COLUMNS) if (!(withPictures && IMAGE_COLUMNS.includes(k))) delete props[k];
    await send(`${NOTION_API}/pages/${pageId}`, { method: 'PATCH', headers: headers(token), body: JSON.stringify({ properties: props }) }, fetchImpl);
    return { pageId, images: withPictures ? !wantsImages(record) || IMAGE_COLUMNS.some((c) => c in props) : Boolean(record.written?.images) };
  }
  const page = await send(`${NOTION_API}/pages`, { method: 'POST', headers: headers(token), body: JSON.stringify({ parent: { type: 'data_source_id', data_source_id: dataSourceId }, properties: props }) }, fetchImpl);
  return { pageId: page.id, images: !wantsImages(record) || IMAGE_COLUMNS.some((c) => c in props) };
}
